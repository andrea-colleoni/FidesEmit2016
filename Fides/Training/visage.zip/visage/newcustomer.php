<?php include_once("include/header.php"); ?>

<div style="height:60px;">
	<div class="col-md-12" style="position:fixed;background:white;">
		<h1 class="page-header" style="width:970px;">NUOVO CLIENTE</h1>
	</div>
</div>
   
<div class="appcontainer">

<div style="width:832px; float:left; margin-left:15px;">
	<div class="stepblock" id="dm">
	   <div class="stepblock-title">1. Dati Anagrafici</div>
	   <table>
	   <tr>
		<td colspan="3">
		<fieldset>
		<legend style="color:black">Inizia il censimento del nuovo cliente inserendo i suoi dati qui di seguito. Premi il pulsante per proseguire</legend>
		</fieldset>
		</td>
		</tr>
			<tr>
				<td>
				   <fieldset>
					  <legend>Tipo ID Locale *</legend>
					  <select id="tipo_ndg" style="width:150px">
							<option value="">---</option>
							<option value="PF">PF - Persona fisica</option>
							<option value="PFBAS">PFBAS - Persona fisica benef.ammin.sost.</option>
							<option value="PFE">PFE - Persona fisica estera</option>
							<option value="PFI" selected>PFI - Persona fisica interdetta</option>
							<option value="PFIE">PFIE - Persona fisica interdetta estera</option>
							<option value="PFINB">PFINB - Persona fisica inabilitata</option>
					  </select>
				   </fieldset>
				</td>
				<td>
				    <fieldset>
					  <legend>Nome *</legend>
					  <input type="text" style="width:180px">
				   </fieldset>
				</td>
				<td>
				    <fieldset>
					  <legend>Cognome *</legend>
					  <input type="text" style="width:180px">
				   </fieldset>
				</td>
			</tr>
			<tr>
				
				<td>
				   <fieldset style="clear:both">
					  <legend>Luogo di Nascita *</legend>
					  <input type="text" style="width:180px">
				   </fieldset>
				</td>
				<td>
				   <fieldset>
					  <legend>Data di Nascita *</legend>
					  <input type="date" style="width:180px">
				   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
				   <fieldset style="clear:both">
					  <legend>Genere *</legend>
					  <table style="width:100px"><tr>
						<td class="radio-input"><input type="radio" name="genere" /></td><td class="label">M</td>
						<td class="radio-input"><input type="radio" name="genere" /></td><td class="label">F</td>
					  </tr></table>
				   </fieldset>
				</td>
				<td>
				   <fieldset>
					  <legend>Codice Fiscale *</legend>
					  <input type="text" style="width:180px"/>
				   </fieldset>
				</td>
				<td>
				</td>
			</tr>	   
			<tr>
			<td>
				   <fieldset style="clear:both">
					  <legend>Nazionalità</legend>
					  <input type="text"  value="Italiana" style="width:180px"/>
				   </fieldset>
				</td>
				<td>
				    <fieldset>
					  <legend>Cittadinanza  <i id="plusButton" style="cursor:pointer" class="fa fa-plus-circle"  onclick="newCittadinanza(this, 'minusButton','textArea')"></i></legend>
					  <input type="text" style="width:180px"/>
				   </fieldset>
				</td>
				
			</tr>
			<tr>
			<td></td>
			<td>
				  <fieldset>
						<legend><i id="minusButton" style="cursor:pointer; display:none" class="fa fa-minus-circle"  onclick="lessCittadinanza(this, 'plusButton','textArea')"></i></legend>
                       <input id="textArea" type="text" style="width:180px; display:none" placeholder="Altra Cittadinanza" />
					  </fieldset>
				</td>
			</tr>
		</table>
		
	   <hr/>
	   
	   <legend style="margin-left:22px;">I campi contrassegnati con * sono obbligatori.</legend>
	   
		<div class="buttons-box">
		   <button id="mod" class="btn btn-add mod" style="display:none;" onclick="resetStepBlock(this, document.getElementById('next'), 'dm','da',116);"><i class="fa fa-gear"></i>MODIFICA</button>
		   <button id="next" class="btn btn-add next" onclick="changeStepBlock2(this, document.getElementById('mod'), 'dm','da',116);"><i class="fa fa-chevron-down"></i>SUCCESSIVA</button>
		</div>
	</div>
	
	<div class="stepblock disabled hidden" id="da_pfi">
	   <div class="stepblock-title">2. Dati Anagrafici Aggiuntivi</div>
	   
	   <table style="float:left; clear:both">
	   <tr>
		<td colspan="3">
		<fieldset>
		<legend style="color:black">Compila in questa sezione i dati del cliente dipendenti dalle precedenti impostazioni</legend>
		</fieldset>
		</td>
		</tr>
			<tr>
				<td colspan="2">	   
				   <fieldset style="clear:both">
					  <legend>CDN Amministratore di sostegno *</legend>		
					  <input id="amministratore_id" type="text" style="width:200px">
					  <i style="cursor:pointer; margin-left:15px" class="fa fa-search" onclick="MM_showHideLayers('ManageCustomer','','show')"></i>
					  <br/>
					  <legend style="cursor:pointer; color:#000; margin-left:207px; margin-top: -9px;" onclick="show_ultimi_cdn('ultimi_cdn')"><u>Vedi lista ultimi CDN elaborati</u></legend>
					  
					
				   </fieldset>
				</td>	
			
				<td>
				<fieldset id="amministratore_name" style="display:none;margin-top: -20px;">
					<legend>Intestazione Amministratore di Sostegno</legend>
					<input  type="text" value="Giovanni Bianchi" style="width:180px;" disabled />
				</fieldset>
				</td>
				
			</tr>
		<tr id = "ultimi_cdn" style="display:none;">
		
		<td style="padding-left:215px">
		<fieldset>
		
			<legend>CDN: 4152677 Mario Rossi</legend>
			<legend>CDN: 5514332 Luca Grilli</legend>
			<legend>CDN: 4162523 Paolo Ferrari</legend>

			</fieldset>
		</td>
	
		</tr>
		</table>
		<table>
			<tr>				
				   <td>
				   <fieldset style="margin-top:15px">
						<legend>Secondo Nome</legend>
					  <input type="text" style="width:180px"/>
					  
				   </fieldset>
				   </td>
				   <td>
				   <fieldset style="margin-top:15px">
						<legend>Ulteriore Intestazione</legend>
					  <input type="text" style="width:180px"/>
					  
				   </fieldset>
				   </td>
				    <td>
				   <fieldset style="margin-top:15px">
						<legend>Codice Identificativo della Nazione di Nascita</legend>
					  <input type="text" style="width:300px"/>
					  
				   </fieldset>
				   </td>
				
			</tr>
			
			<tr>
			<td>
			<fieldset>
				<legend>Sei una persona politicamente esposta? *</legend>
			
				<table>
					<tr>
					<td class="radiosearch"><input type="radio" name="politico" value="pulsante di scelta" id="RadioGroupA1"></td>
					<td style="width:30px" class="radioname">Si'</td>
					<td class="radiosearch"><input type="radio" name="politico" value="pulsante di scelta" id="RadioGroupA2"></td>
					<td style="width:30px" class="radioname">No</td>
					
					</tr>
				</table>
			</fieldset>
			</td>
			
			<td>
			<fieldset>
				<legend>Hai residenza fiscale negli USA? *</legend>
				<table>
					<tr>
					<td class="radiosearch"><input type="radio" name="usa" value="pulsante di scelta" id="RadioGroupA1"></td>
					<td style="width:30px" class="radioname">Si'</td>
					<td class="radiosearch"><input type="radio" name="usa" value="pulsante di scelta" id="RadioGroupA2"></td>
					<td style="width:30px" class="radioname">No</td>
					
					</tr>
				</table>
			</fieldset>
			</td>
			
			
			</tr>
			
		</table>

	   <hr />
	    <legend style="margin-left:22px;">I campi contrassegnati con * sono obbligatori.</legend>
		<div class="buttons-box">
		   <button class="btn btn-add" onclick="changeStepBlock('dm','da_pfi','ccdd_pfi',116); showAmministratore('amministratore_id','amministratore_name')"><i class="fa fa-chevron-down"></i>SUCCESSIVA</button>
		</div>
	</div>
	
		
	<div class="stepblock disabled hidden" id="da_pf">
	   <div class="stepblock-title">2. Dati Anagrafici Aggiuntivi</div>
	   
	   <table>
	   <tr>
		<td colspan="3">
		<fieldset>
		<legend style="color:black">Compila in questa sezione i dati del cliente dipendenti dalle precedenti impostazioni</legend>
		</fieldset>
		</td>
		</tr>
			
			<tr>
			
				   <td>
				   <fieldset>
						<legend>Secondo Nome</legend>
					  <input type="text" style="width:180px"/>
					  
				   </fieldset>
				   </td>
				   <td>
				   <fieldset>
						<legend>Ulteriore Intestazione</legend>
					  <input type="text" style="width:180px"/>
					  
				   </fieldset>
				   </td>
				    <td>
				   <fieldset>
						<legend>Codice Identificativo della Nazione di Nascita</legend>
					  <input type="text" style="width:300px""/>
					  
				   </fieldset>
				   </td>
				
			</tr>
			
			<tr>
			<td>
			<fieldset>
				<legend>Sei una persona politicamente esposta? *</legend>
			
				<table>
					<tr>
					<td class="radiosearch"><input type="radio" name="politico" value="pulsante di scelta" id="RadioGroupA1"></td>
					<td style="width:30px" class="radioname">Si'</td>
					<td class="radiosearch"><input type="radio" name="politico" value="pulsante di scelta" id="RadioGroupA2"></td>
					<td style="width:30px" class="radioname">No</td>
					
					</tr>
				</table>
			</fieldset>
			</td>
			
			<td>
			<fieldset>
				<legend>Hai residenza fiscale negli USA? *</legend>
				<table>
					<tr>
					<td class="radiosearch"><input type="radio" name="usa" value="pulsante di scelta" id="RadioGroupA1"></td>
					<td style="width:30px" class="radioname">Si'</td>
					<td class="radiosearch"><input type="radio" name="usa" value="pulsante di scelta" id="RadioGroupA2"></td>
					<td style="width:30px" class="radioname">No</td>
					
					</tr>
				</table>
			</fieldset>
			</td>
			
			
			</tr>
		</table>

	   <hr />
		<div class="buttons-box">
		   <button id="btn-Save" class="btn btn-add" onclick="MM_showHideLayers('ConfermaOmonimo','','show')"><i class="fa fa-chevron-down"></i>SUCCESSIVA</button>
		</div>
	</div>
	
	<div class="stepblock hidden" style="margin-top:0;" id="lom">
		<ul class="results-list">
			<li class="selectable">
				<div class="clearfix">
					<div style="float:left;width:178px;margin-right:30px;">
						CDN: 12365477<br>
						Tipo: PF
					</div>
					<div style="float:left;width:158px;margin-right:30px;">
						Mario Rossi<br>
						09/07/1959
					</div>
					<div style="float:left;width:168px;">
						Via Carlo Cattaneo 6<br>
						25125 Brescia (BS)
					</div>
					<input type="hidden" name="tipo_id" value="PF">
				</div>
				<div>
				<img style="width:60px;border-radius:8px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/1.jpg">
					<div style="padding-left:15px;float:left;margin-top:3px;"><i>Persona Fisica</i><h3 style="margin:0">Mario Rossi</h3><div style="font-family:LatoWeb;weight:normal;font-size:12px;margin-top:2px;">Cod. Azienda: 1010    ID: 12365477    CDN: 12365477</div></div>
					<div style="float:right;">
						<button id="btn-Save" class="btn btn-add" onclick="MM_showHideLayers('ConfermaOmonimo','','show')" style="border:1px solid #175600">
							<i class="fa fa-plus" style="float:left;"></i><span style="float:left;font-size:11px;">SELEZIONA</span>
						</button>
					</div>				
					<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
						<li>Indirizzo di residenza: Via Carlo Cattaneo 6</li>
						<li>CAP/Comune: 25125 Brescia</li>
						<li>Provincia: Brescia</li>
						<li>Codice Fiscale: MRARSS59G09H871J</li>
						<li>Sesso: M</li>
						<br>
						<li>Ruolo: Prospect</li>
						
					</ul>
								
					<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
						<li>Luogo di nascita: Brescia</li>
						<li>Data di nascita: 09/07/1959</li>
						<li>Telefono: +39 0307867145</li>
						<li>Cellulare: +39 3334022678</li>
						<li>E-Mail: mario.rossi@gmail.com</li>
						<br>
						<li>Professione: Impiegato</li>
						<li>Settore: Famiglie Consumatrici</li>
						<br>
						<br>
						<a href="./customerdetails.php" target="_blank"><u>Mostra tutti i dati della controparte</u></a>
						
					</ul>
				</div>
			</li>
			<li class="selectable">
				<div class="clearfix">
					<div style="float:left;width:178px;margin-right:30px;">
						CDN: 88623478<br>
						Tipo: PF
					</div>
					<div style="float:left;width:158px;margin-right:30px;">
						Mario Rossi<br>
						09/07/1959
					</div>
					<div style="float:left;width:168px;">
						Via Tito Speri 18A<br>
						25125 Brescia (BS)
					</div>
					<input type="hidden" name="tipo_id" value="PF">
				</div>
				<div>
				<img style="width:60px;border-radius:8px;float:left;" src="Assets/img/customers/2.jpg">
					<div style="padding-left:15px;float:left;margin-top:3px;"><i>Persona Fisica</i><h3 style="margin:0">Mario Rossi</h3><div style="font-family:LatoWeb;weight:normal;font-size:12px;margin-top:2px;">Cod. Azienda: 1010    ID: 88623478    CDN: 88623478</div></div>
					<div style="float:right;">
						<button id="btn-Save" class="btn btn-add" onclick="MM_showHideLayers('ConfermaOmonimo','','show')" style="border:1px solid #175600">
							<i class="fa fa-plus" style="float:left;"></i><span style="float:left;font-size:11px;">SELEZIONA</span>
						</button>
					</div>					
					<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
						<li>Indirizzo di residenza: Via Tito Speri 18A</li>
						<li>CAP/Comune: 25125 Brescia</li>
						<li>Provincia: Brescia</li>
						<li>Codice Fiscale: MRARSS71A010H449Q</li>
						<li>Sesso: M</li>
						<br>
						<li>Ruolo: Cliente</li>
						
					</ul>
								
					<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
						<li>Luogo di nascita: Brescia</li>
						<li>Data di nascita: 10/01/1971</li>
						<li>Telefono: +39 0307867145</li>
						<li>Cellulare: +39 3934022678</li>
						<li>E-Mail: mario.rossi71@gmail.com</li>
						<br>
						<li>Professione: Impiegato</li>
						<li>Settore: Famiglie Consumatrici</li>
						<br>
						<br>
						<a href="#"><u>Mostra tutti i dati della controparte</u></a>
						
					</ul>
				</div>
			</li>
		</ul>
	</div>
	
	<div class="stepblock disabled hidden" id="ccdd_pf">
	   <div class="stepblock-title">3. Dati Dinamici</div>
	   
			 <table style="float:left;clear:both">
			    <tr>
			<td colspan="2">
			<fieldset>
				<legend style="color:#000">Prosegui nel censimento con le informazioni principali del cliente.<br/>Eventuali aggiunte le potrai fare successivamente.</legend>
			</fieldset>
			</td>
			</tr>
			<tr>
				<td>
				   <fieldset>
					  <legend>Toponimo</legend>
					  <select style="width:120px">
						 <option value="">Via</option>
						 <option value="">Piazza</option>
						 <option value="">Vicolo</option>
					  </select>
				   </fieldset>
				</td>
				<td>
				   <fieldset>
					  <legend>Via/Piazza/Vicolo *</legend>		
					  <input type="text" style="width:150px" value="Carlo Cattaneo"/>
				   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
				   <fieldset>
					  <legend>Num Civico *</legend>		
					  <input type="text" style="width:50px" value="6">
				   </fieldset>
				</td>
				<td>
				<fieldset>
				  <legend>Presso</legend>		
				  <input type="text" style="width:150px">
			   </fieldset>
				</td>
			</tr>
			<tr>
			
				<td>
				<fieldset>
				  <legend>Comune *</legend>
				   <input type="text" style="width:150px" value="Brescia">
			   </fieldset>
				</td>
					<td>
			   <fieldset>
				  <legend>CAP *</legend>
				   <input type="text" style="width:150px" value="25125">
			   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
			   <fieldset>
				  <legend>Provincia *</legend>
				   <input type="text" style="width:150px" value="Brescia">
			   </fieldset>
				</td>
			
				<td>
			   <fieldset>
				  <legend>Nazione *</legend>
				   <input type="text" style="width:150px" value="Italia">
			   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
					<fieldset>
					<table style="float:left;clear:both">
					<tr>
					<td>
					<legend>Forzato</legend>
					</td>
					<td>
					<input style ="margin-top: 13px; margin-left: 5px;"type="checkbox" name="check_f" value="f" />
					</td>
					</tr>
					</table>
					</fieldset>
				</td>
				<td>
					<fieldset>
					<legend>Approssimato  <i class="fa fa-times"></i></legend>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td>
			   <fieldset>
			   <legend>Prefisso Int.</legend>
				<input type="text" class="input" style="width:58px" value="+39" disabled />
				</fieldset>
				
				<fieldset>
				<legend>Prefisso Naz.</legend>
						<input type="text" class="input" style="width:60px" value="030" disabled />
						</fieldset>
						</td>
						<td>
						<fieldset>
				  <legend>Numero Principale</legend>
				   <input type="text" style="width:150px" value="7867145">
			   </fieldset>
				</td>
				</tr>
				<tr>
				<td>
			   <fieldset>
				  <legend>E-Mail Principale</legend>
				   <input type="text" style="width:150px" value="mario.rossi@gmail.com">
			   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
					<fieldset>
					  <legend>Tipo Account Principale</legend>
					   <select style="width:150px">
						 <option value="">---</option>
						 <option value="">Facebook</option>
						 <option value="">Twitter</option>
						 <option value="">LinkedIn</option>
						 <option value="">Skype</option>
					  </select>
				   </fieldset>
				</td>
				<td>
			   <fieldset>
				  <legend>Social ID</legend>
				   <input type="text" style="width:150px">
			   </fieldset>
				</td>
			</tr>
			
		</table>
		<div class="searchinput" style="margin-right:43px;">
		<input type="search" placeholder="Cerca Indirizzo" style="width:350px;margin-top:54px; border-radius:5px; color:#000; background-color: #ffffff; background-position: 316px 4px; background-image: url(./Assets/img/IcoSearchBlack.svg);"></input>
		</div>
	   <img style="float:left;margin-left:75px; margin-top:2px; border-radius:5px;"
		  width="350"
		  height="320"
		  frameborder="0" style="border:0"
		  src="Assets/img/maps/map_viaCarloCattaneo.png" allowfullscreen>
		</img>
		
		<hr/>
		
		<table style="float:left; clear:both;">
	
			<tr>
				<td>
				   <fieldset>
					  <legend>SAE *</legend>
					  <select style="width:300px">
						 <option value="">---</option>
						  <option value="">276 - Old-Agenti di Cambio</option>
						   <option value="">280 - Mediatori/Agenti e Consul.assic</option>
						    <option value="">284 - Altri Ausiliari Finanziari</option>
							<option value="" selected>600 - Famiglie Consumatrici</option>
							 <option value="">615 - Altre Famiglie Produttrici</option>
					  </select>
				   </fieldset>
				</td>
			
				<td>
				   <fieldset>
					  <legend>ATECO *</legend>
					  <select style="width:300px">
						 <option value="">---</option>
						 <option value="">01 - Coltivazioni Agricole e Produzione</option>
						 <option value="">0111 - Coltivazione di Colture Agricole</option>
						 <option value="">01112 - Coltivazione di Semi Oleosi</option>
						 <option value="">01112 - Coltivazioni Miste di Cereali</option>
						 <option value="">01120 - Coltivazione di Riso</option>
						 <option value="">011310 - Coltiv. Ortaggi in Piena Aria</option>
					  </select>
				   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
				   <fieldset>
					  <legend>Professione *</legend>
					  <select style="width:300px">
						<option value="">---</option>
						<option value="">Studente</option>
						<option value="">Pensionato</option>
						<option value="">Casalinga</option>
						<option value="">Redditiero</option>
						<option value="">Disoccupato</option>
						<option value="">Insegnante Scuola Privata/Pubb</option>
						<option value="">Operaio o Assimilato</option>
						<option value="" selected>Impiegato</option>
						<option value="">Funzionario/Quadro</option>
						<option value="">Magistrato</option>
						<option value="">Militare o Forze Armate</option>
						<option value="">Agente di Commercio</option>
						<option value="">Sport e Spettacolo</option>
						<option value="">Coltiv. Diretti/Imprend. Agric</option>
						<option value="">Medico</option>
						<option value="">Avvocato e Procuratore Legale</option>
					  </select>
				   </fieldset>
				</td>
			</tr>
		</table>
		
		<legend style="margin-left:22px;">I campi contrassegnati con * sono obbligatori.</legend>
			<hr/>
			 
		
	
	   <strong>Normativa Privacy</strong>
	   
	   <table style="float:left;clear:both;width:320px;margin-left:20px;">
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Erogazione di servizi bancari e finanziari</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso1" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso1"/></td><td class="label">Nego il consenso</td>
			<td class="label">Data  </td><td><input type="date" class="input"/></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Indagini di mercato e offerta prodotti finanziari</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso2" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso2" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Offerta prodotti gruppo in base al profilo personale    </td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso3" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso3" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Indagini di mercato e offerta prodotti di terzi</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso4" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso4" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Dati sensibili</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso5" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso5" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		</table>
	   
	 
	   <hr/>
	   <div style="float:left; clear:both;">
	   <table style="float:left; clear:both;">
	   <tr>
	   <td>
		<fieldset>
         <legend>Tipo Intermediario</legend>
         <select style="width:250px">
          <option value="">---</option>
		  <option value="">08 - Angente di Cambio</option>
		  <option value="">10 - Int. Finanz. Art.107</option>
		  <option value="">11 - Int. Finanz. Art.106</option>  
		  <option value="">12 - Succ. Ital. Sogg.1-11</option>  
		  <option value="">15 - Confidi</option>
		  <option value="">16 - Cambiavalute</option> 
		  <option value="">19 - Int.Assic.Art.109/2</option> 
		  <option value="">20 - Mediatori Creditizi</option>
		  <option value="">21 - Agenti Attiv. Finanz.</option> 
		  <option value="">28 - Succ. Ital. Sogg. 23-26</option>
		  <option value="">29 - Istituti Pagamento</option>
		  <option value="">30 - Money Transfer</option>
		  <option value="">32 - Compro Oro</option>
		  <option value="">33 - Fondi Pubblici/Appalti</option>
		  <option value="">35 - Operat. in Giochi e Scommesse</option>
		  <option value="" selected>36 - Iranian Subject Approvati</option>
		  <option value="">37 - Imp. Operante Sett. Armamenti</option>
         </select>
        </fieldset>
		</td>
		<td>
		<fieldset>
			<legend>Interesse DOF</legend>
         <select style="width:250px">
          <option value="">---</option>
		  <option value="">S</option>
         </select>
		 </fieldset>
		 </td>
		 </tr>
		 <tr>
		 <td>
				   <fieldset>
						<legend>Residenza Fiscale</legend>
					  <input type="text"  style="width:180px" disabled />
					  
				   </fieldset>
				   </td>
				   <td>
				   <fieldset>
						<legend>International Tax Code (TIN)/NIF</legend>
					  <input type="text"  style="width:180px" disabled />
					  
				   </fieldset>
				   </td>
				    <td>
				   <fieldset>
						<legend>GIIN</legend>
					  <input type="text"  style="width:180px" disabled />
					  
				   </fieldset>
				   </td>
		 </tr>
        </table>
	   </div>
		<div class="buttons-box">
		   <button style="margin-top:22px" id="btn-Save" class="btn btn-add" onclick="MM_showHideLayers('RiepilogoCensimento','','show')"><i class="fa fa-chevron-right"></i>Prosegui</button>
		</div>
	</div>
	
	<div class="stepblock disabled hidden" id="ccdd_pfi">
	   <div class="stepblock-title">3. Dati Dinamici</div>
	   
			 <table style="float:left;clear:both">
			  <tr>
			<td colspan="2">
			<fieldset>
				<legend style="color:#000">Prosegui nel censimento con le informazioni principali del cliente.<br/>Eventuali aggiunte le potrai fare successivamente.</legend>
			</fieldset>
			</td>
			</tr>
			<tr>
				<td>
				   <fieldset>
					  <legend>Toponimo</legend>
					  <select style="width:120px">
						 <option value="">Via</option>
						 <option value="">Piazza</option>
						 <option value="">Vicolo</option>
					  </select>
				   </fieldset>
				</td>
				<td>
				   <fieldset>
					  <legend>Via/Piazza/Vicolo *</legend>		
					  <input value="" id ="address" type="text" style="width:150px" />
				   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
				   <fieldset>
					  <legend>Num Civico *</legend>		
					  <input type="text" style="width:50px">
				   </fieldset>
				</td>
				<td>
				<fieldset>
				  <legend>Presso</legend>		
				  <input type="text" style="width:150px">
			   </fieldset>
				</td>
			</tr>
			<tr>
			<td>
				<fieldset>
				  <legend>Comune *</legend>
				   <input type="text" style="width:150px">
			   </fieldset>
				</td>
				
					<td>
			   <fieldset>
				  <legend>CAP *</legend>
				   <input type="text" style="width:150px">
			   </fieldset>
				</td>
			</tr>
			<tr>
			<td>
			   <fieldset>
				  <legend>Provincia *</legend>
				   <input type="text" style="width:150px">
			   </fieldset>
				</td>
			
				<td>
			   <fieldset>
				  <legend>Nazione *</legend>
				   <input type="text" style="width:150px">
			   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
					<fieldset>
					<table style="float:left;clear:both">
					<tr>
					<td>
					<legend>Forzato</legend>
					</td>
					<td>
					<input style ="margin-top: 13px; margin-left: 5px;" type="checkbox" name="check_f" value="f" />
					</td>
					</tr>
					</table>
					</fieldset>
				</td>
				<td>
					<fieldset>
					<legend>Approssimato  <i class="fa fa-check"></i></legend>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td>
			   <fieldset>
			   <legend>Prefisso Int.</legend>
				<input type="text" class="input" style="width:58px" disabled />
				</fieldset>
				
				<fieldset>
				<legend>Prefisso Naz.</legend>
						<input type="text" class="input" style="width:60px" disabled />
						</fieldset>
						</td>
						<td>
						<fieldset>
				  <legend>Numero Principale</legend>
				   <input type="text" style="width:150px" >
			   </fieldset>
			   </td>
				
				</tr>
				<tr>
				<td>
			   <fieldset>
				  <legend>E-Mail Principale</legend>
				   <input type="text" style="width:150px">
			   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
					<fieldset>
					  <legend>Tipo Account</legend>
					   <select style="width:150px">
						 <option value="">---</option>
						 <option value="">Facebook</option>
						 <option value="">Twitter</option>
						 <option value="">LinkedIn</option>
						 <option value="">Skype</option>
					  </select>
				   </fieldset>
				</td>
				<td>
			   <fieldset>
				  <legend>Social ID</legend>
				   <input type="text" style="width:150px">
			   </fieldset>
				</td>
			</tr>
			
		</table>
			   
	 <div class="searchinput" style="margin-right:43px;">
		<input type="search" placeholder="Cerca Indirizzo" style="width:350px;margin-top:54px; border-radius:5px; color:#000; background-color: #ffffff; background-position: 316px 4px; background-image: url(./Assets/img/IcoSearchBlack.svg);"></input>
		</div>
	  <img id="map" style="float:left;margin-left:75px; margin-top:2px; border-radius:5px;"
		  width="350"
		  height="320"
		  frameborder="0" style="border:0"
		  src="Assets/img/maps/map_italy.png" allowfullscreen>
		</img>
		
	   <hr/>
	   
	   <table style="float:left; clear:both;">
	  
			<tr>
				<td>
				   <fieldset>
					  <legend>SAE *</legend>
					  <select style="width:300px">
						 <option value="">---</option>
						  <option value="">276 - Old-Agenti di Cambio</option>
						   <option value="">280 - Mediatori/Agenti e Consul.assic</option>
						    <option value="">284 - Altri Ausiliari Finanziari</option>
							<option value="">600 - Famiglie Consumatrici</option>
							 <option value="">615 - Altre Famiglie Produttrici</option>
					  </select>
				   </fieldset>
				</td>
			
				<td>
				   <fieldset>
					  <legend>ATECO *</legend>
					  <select style="width:300px">
						 <option value="">---</option>
						 <option value="">01 - Coltivazioni Agricole e Produzione</option>
						 <option value="">0111 - Coltivazione di Colture Agricole</option>
						 <option value="">01112 - Coltivazione di Semi Oleosi</option>
						 <option value="">01112 - Coltivazioni Miste di Cereali</option>
						 <option value="">01120 - Coltivazione di Riso</option>
						 <option value="">011310 - Coltiv. Ortaggi in Piena Aria</option>
					  </select>
				   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
				   <fieldset>
					  <legend>Professione *</legend>
					  <select style="width:300px">
						<option value="">---</option>
						<option value="">Studente</option>
						<option value="">Pensionato</option>
						<option value="">Casalinga</option>
						<option value="">Redditiero</option>
						<option value="">Disoccupato</option>
						<option value="">Insegnante Scuola Privata/Pubb</option>
						<option value="">Operaio o Assimilato</option>
						<option value="">Impiegato</option>
						<option value="">Funzionario/Quadro</option>
						<option value="">Magistrato</option>
						<option value="">Militare o Forze Armate</option>
						<option value="">Agente di Commercio</option>
						<option value="">Sport e Spettacolo</option>
						<option value="">Coltiv. Diretti/Imprend. Agric</option>
						<option value="">Medico</option>
						<option value="">Avvocato e Procuratore Legale</option>
					  </select>
				   </fieldset>
				</td>
			</tr>
		</table>
		<legend style="margin-left:22px;">I campi contrassegnati con * sono obbligatori.</legend>
			<hr/>
			
	   <strong>Normativa Privacy</strong>
	   
	   <table style="float:left;clear:both;width:320px;margin-left:20px;">
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Erogazione di servizi bancari e finanziari</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso1" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso1"/></td><td class="label">Nego il consenso</td>
			<td class="label">Data  </td><td><input type="date" class="input" /></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Indagini di mercato e offerta prodotti finanziari</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso2" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso2" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Offerta prodotti gruppo in base al profilo personale    </td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso3" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso3" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Indagini di mercato e offerta prodotti di terzi</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso4" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso4" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Dati sensibili</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso5" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso5" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		</table>
	   
		<hr/>
		<div style="float:left; clear:both;">
	    <table style="float:left; clear:both;">
	   <tr>
	   <td>
		<fieldset>
         <legend>Tipo Intermediario</legend>
         <select style="width:250px">
          <option value="">---</option>
		  <option value="">08 - Angente di Cambio</option>
		  <option value="">10 - Int. Finanz. Art.107</option>
		  <option value="">11 - Int. Finanz. Art.106</option>  
		  <option value="">12 - Succ. Ital. Sogg.1-11</option>  
		  <option value="">15 - Confidi</option>
		  <option value="">16 - Cambiavalute</option> 
		  <option value="">19 - Int.Assic.Art.109/2</option> 
		  <option value="">20 - Mediatori Creditizi</option>
		  <option value="">21 - Agenti Attiv. Finanz.</option> 
		  <option value="">28 - Succ. Ital. Sogg. 23-26</option>
		  <option value="">29 - Istituti Pagamento</option>
		  <option value="">30 - Money Transfer</option>
		  <option value="">32 - Compro Oro</option>
		  <option value="">33 - Fondi Pubblici/Appalti</option>
		  <option value="">35 - Operat. in Giochi e Scommesse</option>
		  <option value="">36 - Iranian Subject Approvati</option>
		  <option value="">37 - Imp. Operante Sett. Armamenti</option>
         </select>
        </fieldset>
		</td>
		<td>
		<fieldset>
			<legend>Interesse DOF</legend>
         <select style="width:250px">
          <option value="">---</option>
		  <option value="">S</option>
         </select>
		 </fieldset>
		 </td>
		 </tr>
		 <tr>
		 <td>
				   <fieldset>
						<legend>Residenza Fiscale</legend>
					  <input type="text"  style="width:180px" disabled />
					  
				   </fieldset>
				   </td>
				   <td>
				   <fieldset>
						<legend>International Tax Code (TIN)/NIF</legend>
					  <input type="text"  style="width:180px" disabled />
					  
				   </fieldset>
				   </td>
				    <td>
				   <fieldset>
						<legend>GIIN</legend>
					  <input type="text"  style="width:180px" disabled />
					  
				   </fieldset>
				   </td>
		 </tr>
        </table>
		</div>
		
		<div class="buttons-box">
		   <button style = "margin-top:22px" class="btn btn-add" onclick="MM_showHideLayers('RiepilogoCensimento','','show')"><i class="fa fa-chevron-right"></i>Prosegui</button>
		</div>
	</div>
	
</div>
<div style="width:65px; float:left;">
	<ul class="section-list clearfix">
		<li id="dm_tab" class="active" style="font-family:'LatoWeb';font-size:12px" onclick="scrollPage('dm',116)">1. Dati Anagrafici</li>
		<li id="da_tab" class="disabled" style="font-family:'LatoWeb';font-size:12px" onclick="scrollPage2('da',116)">2. Dati Anagrafici Aggiuntivi</li>
		<li id="ccdd_tab" class="disabled" style="font-family:'LatoWeb';font-size:12px" onclick="scrollPage2('ccdd',116)">3. Dati Dinamici</li>
	</ul>
	<br/>
</div>

</div>

<?php include_once("include/footer.php"); ?>