<?php include_once("include/header.php"); ?>

    <div style="height:50px;">
		<div class="col-md-12" style="position:fixed;background:white;">
			<h1 class="page-header" style="width:970px">GESTIONE CONTATTO - TELEFONO <button class="btn ricercasemplice" onclick="MM_showHideLayers('ManageContacts','','show')"><i class="fa fa-bullseye"></i> Ricerca Semplice</button></h1>			
		</div>
	</div>
   
<div class="appcontainer">

<div style="width:970px;margin-top:8px;">

			<img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/1.jpg">
				<div style="padding-left:15px;margin-top:2px;float:left;font-size:13px"><i>Persona Fisica</i><br/><h3 style="margin:0">Mario Rossi</h3><div style="font-family:LatoWeb;weight:normal;font-size:12px;margin-top:2px;">Cod. Azienda: <b>1025</b>  CDN: <b>12365477</b></div></div>
							
				<div class="managecontact tel">
					
					<label>
						<legend>Tipo</legend>
						<input type="text" class="input" style="width:120px" value="Cellulare personale" disabled />
					</label>
					<label>
						<legend>Stato*</legend>
						<select class="input" style="width:104px">
							<option>Attivo</option>
							<option selected>Non Attivo</option>
						</select>
					</label>
					<label>
						<legend>Certificato*</legend>
						<select class="input" style="width:70px">
							<option selected>Si</option>
							<option>No</option>
						</select>
					</label>
					
					<label style="clear:both">
						<legend>Prefisso Int.</legend>
						<input type="text" class="input" style="width:58px" value="+39" disabled />
					</label>
					<label>
						<legend>Prefisso Naz.</legend>
						<input type="text" class="input" style="width:60px" value="331" disabled />
					</label>
					<label>
						<legend>Numero</legend>
						<input type="text" class="input" style="width:104px" value="4187871" disabled />
					</label>
					<label>
						<legend>Raggiungibile da*</legend>
						<input type="time" class="input" style="width:80px" value="00:00" />
					</label>
					<label>
						<legend>Raggiungibile a*</legend>
						<input type="time" class="input" style="width:80px" value="00:00" />
					</label>
					<label style="clear:both">
						<legend>Consenso utilizzo*</legend>
						<select class="input" style="width:66px">
							<option selected>Si</option>
							<option>No</option>
						</select>
					</label>
					<label>
						<legend>Data consenso*</legend>
						<input type="date" class="input" style="width:140px" value="2016-10-02" />
					</label>
					<label>
						<legend>Nota*</legend>
						<input type="text" class="input" style="width:195px" />
					</label>
					
					<table style="margin-bottom:5px;">
						<tr class="header2">
							<td></td>
							<td style="width:160px;">Utilizzato per</td>
						</tr>
						<tr>
							<td><input type="checkbox"></td>
							<td>Promozione</td>
						</tr>
						<tr>
							<td><input type="checkbox"></td>
							<td>Residenza</td>
						</tr>		
					</table>
						
					<button style="clear:both;margin-top:-14px;"><i class="fa fa-save"></i> Salva</button>
					
						<hr />
						<strong style="float:left; clear:both;">Rapporti già associati al contatto</strong>
						<legend class="spiegazione">Se vuoi trasferire il rapporto su un altro contatto selezionalo e poi premi il tasto trasferisci.</legend>
						
						<table id="rapporti_associati" style="margin-bottom:5px;">
							<tr class="header2">
								<td></td>
								<td style="width:160px;">Utilizzato per</td>
								<td style="width:210px;">Rapporti associati al contatto</td>
								<td>Altri contatti</td>
							</tr>
							<tr>
								<td><input type="checkbox"></td>
								<td>Invio SMS</td>
								<td style="cursor:pointer;text-decoration:underline;">01025  00003 0200 00002437624</td>
								<td></td>
							</tr>
							<tr>
								<td><input type="checkbox"></td>
								<td>Invio SMS</td>
								<td style="cursor:pointer;text-decoration:underline;" onclick="location.href='managecontact_rpp.php';">01025  13966 5401 00028288686</td>
								<td><i class="fa fa-check"></i></td>
							</tr>		
						</table>
						
						<div style="width: 630px;">
						<label id="nuova_associazione" style="visibility:hidden;">
							<legend style="padding-top:3px">Nuova associazione</legend>
							<select class="input" style="width:200px;float: left;">
								<option>---</option>
								<option>Abitazione | +39 0200000000</option>
								<option>Abitazione | +39 0200000000</option>
								<option>Abitazione | +39 0200000000</option>
							</select>
						</label>						
						<button id="trasferisci" class="disabled" style="margin-top: 27px;"><i class="fa fa-arrow-right"></i> Trasferisci</button>
						</div>
						
						<hr />
						<strong style="float:left; clear:both;">Aggiungi rapporto al contatto</strong>
								
						<a href="#" style="text-decoration:underline;float:left;margin-left:22px;" 
							onclick="document.getElementById('aggiungi_rapporto').style.display='block';this.style.display='none';scrollPage('aggiungi_rapporto',161);">clicca qui</a>
						
						<div id="aggiungi_rapporto" style="float:left;display:none">
							<legend class="spiegazione">Seleziona dalla seguente lista i rapporti che vuoi associare al contatto.</legend>
							
							<table style="margin-bottom:5px;">
								<tr class="header2">
									<td></td>
									<td style="width:160px;">Utilizzato per</td>
									<td style="width:210px;">Rapporti associati al contatto</td>
									<td style="width:160px;">Altro contatto della stessa categoria</td>
									<td>Altri contatti</td>
								</tr>
								<tr>
									<td><input type="checkbox"></td>
									<td>Invio SMS</td>
									<td style="cursor:pointer;text-decoration:underline;">01025  00003 0200 00002437624</td>
									<td></td>
									<td><i class="fa fa-check"></i></td>
								</tr>
								<tr>
									<td><input type="checkbox"></td>
									<td>Invio SMS</td>
									<td style="cursor:pointer;text-decoration:underline;">01025  13966 5401 00028288686</td>
									<td>+39 331 4187871</td>
								</tr>	
								<tr>
									<td><input type="checkbox"></td>
									<td></td>
									<td style="cursor:pointer;text-decoration:underline;">01025  13966 5401 00028288686</td>
									<td></td>
								</tr>	
								<tr>
									<td><input type="checkbox"></td>
									<td></td>
									<td style="cursor:pointer;text-decoration:underline;">01025  13966 5401 00028288686</td>
									<td></td>
								</tr>
							</table>
							
							<button style="clear:both;margin-top: 8px;" onclick="MM_showHideLayers('AggiungiRapporto','','show')"><i class="fa fa-plus"></i> Aggiungi</button>
						</div>
											
				</div>
					
				<div style="float:left;margin-top:5px;">
					<div class="maininfo details">
						<ul>Highlights
						<li>Ruoli: Cliente</li>
						<li>Collegato a: Gruppo Ferrero S.p.A. (CDN 1234567)</li>
						</ul>

						<ul>
						  Ultimi aggiornamenti
						  <li>25/04/2016: aggiornamento documento d’identità</li>
						<li>25/04/2016: compilazione MiFid</li>
						<li>25/04/2016: censimento delega</li>
						</ul>

						<ul>Ultimi contatti
						<li>25/04/2016: rinnovato Titoli</li>
						<li>225/04/2016: proposto nuova assicurazione</li>
						<li>26/04/2016: invio mail preventivo assicurazione</li>
						</ul>
					</div>
					
					<div class="latestinsert" style="clear:both;margin:8px 15px;margin-right:0;width:260px;">
						<div class="latestinsert-title" style="width:260px;">Ultime Controparti elaborate</div>
						<ul>
							<li><i class="fa fa-plug"></i>CC <a href="#" onclick="copy2clipboard(this)">4152677</a> Mario Rossi</li>
							<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">52618276</a> Mario Rossi</li>
							<li><i class="fa fa-plug"></i>CDN <a href="#" onclick="copy2clipboard(this)">5514332</a> Gruppo Siemens</li>
							<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">98126</a> Ferrandi srl</li>
						</ul>
					</div>
				</div>
    
</div>

    </div>

<?php include_once("include/footer.php"); ?>