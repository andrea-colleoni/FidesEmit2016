function finestra(sUrl) 
{
	var now = new Date;
	var sFeatures = "dialogWidth:600px; dialogHeight:400px; center:1; scroll:0; help:0; status:0;";
	sUrl = sUrl + "&i="+now.getTime();
	document.getElementById("txtCodiceFunz").setAttribute("value", showModalDialog(sUrl, null, sFeatures));
	document.forms[0].submit();
}
function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
	if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
	obj.visibility=v; }
}		
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}

function showSelect(name) {
	$(function() {
		$("#key_select select").hide();			
		$("#key_select select[name='"+name+"']").show();
	});
}

function scrollPage(id,diff) {
	$("html, body").animate({
		scrollTop: $("#"+id).offset().top - diff
	}, 400);
}

function scrollPage2(id,diff){
	if( $("select#tipo_ndg").val() == "PF" ){
		$("html, body").animate({
		scrollTop: $("#"+id+"_pf").offset().top - diff
	}, 400);
	}
	else {
		$("html, body").animate({
		scrollTop: $("#"+id+"_pfi").offset().top - diff
	}, 400);
	}

}

function changeStepBlock2(b1,b2, id,next,diff) {
	$("#"+id+"_tab").removeClass("active");
	$("#"+next+"_tab").removeClass("disabled").addClass("active");
	$("#"+id).addClass("disabled").find("input,select,textarea").attr("disabled","disabled");
	if( $("select#tipo_ndg").val() == "PF" ) {
		$("#"+next+"_pf").removeClass("disabled").removeClass("hidden");
		scrollPage(next+"_pf",diff);
	} else {
		$("#"+next+"_pfi").removeClass("disabled").removeClass("hidden");
		scrollPage(next+"_pfi",diff);
	}
	
	b1.style.display = "none";
	b2.style.display = "inline-block";
}

function resetStepBlock(b1,b2, id,next,diff) {
	$("#"+next+"_tab").removeClass("active");
	$("#"+id+"_tab").removeClass("disabled").addClass("active");			
	if( $("select#tipo_ndg").val() == "PF" )
		$("#"+next+"_pf").addClass("hidden");
	else
		$("#"+next+"_pfi").addClass("hidden");
	$("#"+id).removeClass("disabled").find("input,select,textarea").removeAttr("disabled");
	scrollPage(id,diff);
	
	b1.style.display = "none";
	b2.style.display = "inline-block";
}

function resetStepBlock2(b1,b2, id,next,diff) {
	$("#"+next+"_tab").removeClass("active");
	$("#"+id+"_tab").removeClass("disabled").addClass("active");			
	$("#"+next).addClass("hidden");
	$("#"+id).removeClass("disabled").find("input,select,textarea").removeAttr("disabled");
	scrollPage(id,diff);
	
	b1.style.display = "none";
	b2.style.display = "inline-block";
}

function changeStepBlock(prev,id,next,diff) {
	$("#"+prev+"_tab").removeClass("active");
	$("#"+id.replace("_pfi","").replace("_pf","")+"_tab").removeClass("active");
	$("#"+next.replace("_pfi","").replace("_pf","")+"_tab").removeClass("disabled").addClass("active");
	$("#"+prev).addClass("disabled").find("input,select,textarea").attr("disabled","disabled");
	$("#"+id).addClass("disabled").find("input,select,textarea").attr("disabled","disabled");
	$("#"+prev+" .buttons-box button").removeAttr("onclick").addClass("disabled");
	$("#"+id+" .buttons-box button").removeAttr("onclick").addClass("disabled");			
	$("#"+next).removeClass("disabled").removeClass("hidden");
	scrollPage(next,diff);
}
	
function changeStepBlock3(b1,b2, id,next,diff) {
	$("#"+id+"_tab").removeClass("active");
	$("#"+next+"_tab").removeClass("disabled").addClass("active");
	$("#"+id).addClass("disabled").find("input,select,textarea").attr("disabled","disabled");
	
	$("#"+next).removeClass("disabled").removeClass("hidden");
	scrollPage(next,diff);
	
	b1.style.display = "none";
	b2.style.display = "inline-block";
}
	
function showListaOmonimi(id) {
	$("#"+id).removeClass("hidden");
}
function hideListaOmonimi(id) {
	$("#"+id).addClass("hidden");
}

function newCittadinanza(plus, minus, textfield){
									  plus.style.visibility="hidden";
									  document.getElementById(textfield).style.display="block";
									  document.getElementById(minus).style.display="block";
									   
					   }
					   
 function lessCittadinanza (minus, plus, textfield){
									   minus.style.display="none";
									   document.getElementById(plus).style.visibility="visible";
									   document.getElementById(textfield).value='';
									   document.getElementById(textfield).style.display="none";
									   
					   }
function showAmministratore(idLocale, name){
	if(document.getElementById(idLocale).value != ''){
		document.getElementById(name).style.display="block";
	}
}

function change_map(map){
	document.getElementById(map).src="Assets/img/maps/map_viaCarloCattaneo.png";
}

function show_ultimi_cdn(id){
	if(document.getElementById(id).style.display == "none")
		document.getElementById(id).style.display = "block";
	
	else
		document.getElementById(id).style.display = "none";

}

function changeLabelCap(value,id_label) {
	if(value==1)
		document.getElementById(id_label).innerHTML = "Comune";
	else if(value==2)
		document.getElementById(id_label).innerHTML = "Provincia";
	else if(value==3)
		document.getElementById(id_label).innerHTML = "Regione";
}
	
function copy2clipboard(elem) {
				
	var range = document.createRange();
	range.selectNodeContents(elem);
	var sel = window.getSelection();
	sel.removeAllRanges();
	sel.addRange(range);
	
	var succeed;
	try {
		succeed = document.execCommand("copy");
	} catch(e) {
		succeed = false;
	}
	
	return succeed;
}

	
function switchLegamiDetail(elem) {
	
	$button = $(elem);
	if($button.hasClass("controparte")) {
		$li = $button.closest("li");
		$li.removeClass("mod1").addClass("mod2");
	} else if($button.hasClass("legame")) {
		$li = $button.closest("li");
		$li.removeClass("mod2").addClass("mod1");
	}
	
}

function toggleAccordionSection(snum) {
	$("#accordion h3:nth-child("+(snum*2-1)+")").trigger("click");
}

$( function() {
	
	// Ricerca Anagrafica
	$(".slidingopen").accordion({
		heightStyle: "content",
		collapsible: true
	});

	// Lista Legami
	$(".legami-list").accordion({
		header: ".legame-header",
		heightStyle: "content",
		collapsible: true,
		active: false
	});
	
	// Tutto il resto
	$("#accordion").accordion({
		heightStyle: "content",
		collapsible: true
	});
	
	$('a.culture').click(function (e) {
		e.preventDefault();

		$('#currentCultureName').val($(this).attr('class'));
		$('#swCultureForm').submit(); // post form
	});

	$("ul.results-list li.selectable").mouseup(function (e) {
		e.preventDefault();
		$target = $(e.target);
		
		if($target.is("button") || $target.parent().is("button")) return;
		if($target.is("a") || $target.parent().is("a")) return;
		
		if($target.parent().is("li"))
			$target = $target.parent();
		else if($target.parent().parent().is("li"))
			$target = $target.parent().parent();
				
		if($target.hasClass("active"))
			$target.parent().children().removeClass("active");
		else {
			$target.parent().children().removeClass("active");
			$target.addClass("active");
		}
	});

	$("div.filters select[name='tipo_id']").change(function (e) {
		e.preventDefault();
		$("ul.results-list li.selectable").removeClass("hidden active");
		$list = $("ul.results-list li.selectable").each(function(index,element) {
			selected = $(e.target).val();
			value = $(element).find("input[type='hidden'][name='tipo_id']").val();
			if(selected.trim() != "" && selected.trim() != value.trim())
				$(element).addClass("hidden");
		});
		if($("ul.results-list li.selectable.hidden").size() == $("ul.results-list li.selectable").size())
			$("ul.results-list li.empty").show();
		else
			$("ul.results-list li.empty").hide();
	});
	
	$("#rapporti_associati input:checkbox").change(function (e) {
		var ok = false;
		$("#rapporti_associati input:checkbox").each(function(index,elem) {
			if(elem.checked)
				ok = true;
		});
		if(ok) {
			$("#nuova_associazione").css('visibility', 'visible');
			$("#trasferisci").removeClass("disabled");
		} else {
			$("#nuova_associazione").css('visibility', 'hidden');
			$("#trasferisci").addClass("disabled");
		}
	});
	
	$("div.cbox > h3").mouseup(function (e) {
		e.preventDefault();
		$target = $(e.target);
		if($target.is("span") || $target.is("h3")) {
			$box = $target.closest("div");
			if($box.hasClass("collapsed"))
				$box.removeClass("collapsed");
			else
				$box.addClass("collapsed");			
		}
	});
	
	$("ul.legami-list li").mouseup(function (e) {
		e.preventDefault();
		$target = $(e.target);
		
		if($target.is("button") || $target.parent().is("button")) return;
		if($target.is("a") || $target.parent().is("a")) return;
		
		if($target.parent().is("li"))
			$target = $target.parent();
		else if($target.parent().parent().is("li"))
			$target = $target.parent().parent();
				
		if($target.hasClass("active mod1") || $target.hasClass("active mod2"))
			$target.parent().children().removeClass("active mod1 mod2");
		else {
			$target.parent().children().removeClass("active mod1 mod2");
			$target.addClass("active mod1");
		}
	});
	
	// Context Menu [TEST]
	
	$.contextMenu({
		selector: '.context-menu', 
		callback: function(key, options) {
			var m = "clicked: " + key;
			window.console && console.log(m) || alert(m); 
		},
		items: {
			"edit": {name: "Apri Qui"},
			"cut": {name: "Apri in Nuovo Tab"}
		}
	});

	$('.context-menu').on('click', function(e){
		console.log('clicked', this);
	});

} );