<?php include_once("include/header.php"); ?>

    <div style="height:50px;">
		<div class="col-md-12" style="position:fixed;background:white;">
			<h1 class="page-header" style="width:970px">GESTISCI CONTROPARTE</h1>
		</div>
	</div>
   
<div class="appcontainer">

<div style="width:970px;margin-top:8px;">
			<img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/anonimo.jpg">
				<div style="padding-left:15px;margin-top:5px;float:left;font-size:13px"><i>Persona Fisica Interdetta</i><br/><h3 style="margin:0">Mario Rossi</h3><div style="font-family:LatoWeb;weight:normal;font-size:12px;margin-top:2px;">Cod. Azienda: <b>1025</b>    CDN: <b>12365477</b></div></div>
				<div style="float:left;clear:both; color:red;margin-left:385px;">Controparte insufficiente: <a style="cursor:pointer"><u><b>Carica un documento</b></u></a></div>
				</div>
				<div id="accordion" class="customerdetails">
				<h3><span style="height:26px;margin-left:35px;float:left"><b>Dati Anagrafici</b></span></h3>
						<div style="overflow-x: hidden;">
							<a onclick="toggleAccordionSection(2)" 
								style="cursor:pointer;weight:normal;padding:12px;width:310px;margin-right:20px;" > Cliente della tua banca e presente in altre banche del Territorio </a>
						<hr style="margin: 10px 15px 10px 15px">
						<div class="dettagliocliente" style="margin: 0 0 15px 25px">
						
								<label>
									<legend>Nome</legend>
									<input name="nome" type="text" id="nome" class="input" value="Mario"/>
								</label>
								
								<label>
									<legend>Cognome</legend>
									<input name="cognome" type="text" id="cognome" class="input" value="Rossi"/>
								</label>
								
								<label>
									<legend>Tipo ID Locale</legend>
									<select name="idlocale" id="idlocale" class="input" style="width:220px">
									  <option value="PF">PF - Persona fisica</option>
									  <option value="PFBAS">PFBAS - Persona fisica benef.ammin.sost.</option>
									  <option value="PFE">PFE - Persona fisica estera</option>
									  <option value="PFI" selected>PFI - Persona fisica interdetta</option>
									  <option value="PFIE">PFIE - Persona fisica interdetta estera</option>
									  <option value="PFINB">PFINB - Persona fisica inabilitata</option>
									</select>
								</label>
								
								<label style="clear:both">
									<legend>Codice Fiscale</legend>
									<input name="codicefiscale" type="text" id="codicefiscale" class="input" value="MRARSS59G09H871J" />
                                </label>
								
								<label>
									<legend>Data di Nascita</legend>
									<input type="date"  style="width:130px" class="input" value="1959-07-09">
								</label>
								
								<label>
									<legend>Luogo di nascita</legend>
									<select name="provincianascita" style="width:200px" id="provincianascita" class="input">
									<option>Agrigento</option>
									<option>Alessandria</option>
									<option>Ancona</option>
									<option>Aosta</option>
									<option>Arezzo</option>
									<option>Ascoli Piceno</option>
									<option>Asti</option>
									<option>Avellino</option>
									<option>Bari</option>
									<option>Barletta-Andria-Trani</option>
									<option>Belluno</option>
									<option>Benevento</option>
									<option>Bergamo</option>
									<option>Biella</option>
									<option>Bologna</option>
									<option>Bolzano</option>
									<option selected>Brescia</option>
									<option>Brindisi</option>
									<option>Cagliari</option>
									<option>Caltanissetta</option>
									<option>Campobasso</option>
									<option>Carbonia-Iglesias</option>
									<option>Caserta</option>
									<option>Catania</option>
									<option>Catanzaro</option>
									<option>Chieti</option>
									<option>Como</option>
									<option>Cosenza</option>
									<option>Cremona</option>
									<option>Crotone</option>
									<option>Cuneo</option>
									<option>Enna</option>
									<option>Fermo</option>
									<option>Ferrara</option>
									<option>Firenze</option>
									<option>Foggia</option>
									<option>Forlì-Cesena</option>
									<option>Frosinone</option>
									<option>Genova</option>
									<option>Gorizia</option>
									<option>Grosseto</option>
									<option>Imperia</option>
									<option>Isernia</option>
									<option>La Spezia</option>
									<option>L'Aquila</option>
									<option>Latina</option>
									<option>Lecce</option>
									<option>Lecco</option>
									<option>Livorno</option>
									<option>Lodi</option>
									<option>Lucca</option>
									<option>Macerata</option>
									<option>Mantova</option>
									<option>Massa-Carrara</option>
									<option>Matera</option>
									<option>Messina</option>
									<option>Milano</option>
									<option>Modena</option>
									<option>Monza e della Brianza</option>
									<option>Napoli</option>
									<option>Novara</option>
									<option>Nuoro</option>
									<option>Olbia-Tempio</option>
									<option>Oristano</option>
									<option>Padova</option>
									<option>Palermo</option>
									<option>Parma</option>
									<option>Pavia</option>
									<option>Perugia</option>
									<option>Pesaro e Urbino</option>
									<option>Pescara</option>
									<option>Piacenza</option>
									<option>Pisa</option>
									<option>Pistoia</option>
									<option>Pordenone</option>
									<option>Potenza</option>
									<option>Prato</option>
									<option>Ragusa</option>
									<option>Ravenna</option>
									<option>Reggio Calabria</option>
									<option>Reggio Emilia</option>
									<option>Rieti</option>
									<option>Rimini</option>
									<option>Roma</option>
									<option>Rovigo</option>
									<option>Salerno</option>
									<option>Medio Campidano</option>
									<option>Sassari</option>
									<option>Savona</option>
									<option>Siena</option>
									<option>Siracusa</option>
									<option>Sondrio</option>
									<option>Taranto</option>
									<option>Teramo</option>
									<option>Terni</option>
									<option>Torino</option>
									<option>Ogliastra</option>
									<option>Trapani</option>
									<option>Trento</option>
									<option>Treviso</option>
									<option>Trieste</option>
									<option>Udine</option>
									<option>Varese</option>
									<option>Venezia</option>
									<option>Verbano-Cusio-Ossola</option>
									<option>Vercelli</option>
									<option>Verona</option>
									<option>Vibo Valentia</option>
									<option>Vicenza</option>
									<option>Viterbo</option>
									</select>
									</label>
									
								<label>
									<legend>Genere</legend>
									<select class="input" style="width:50px">
									<option selected="selected">M</option>
									<option>F</option>
									</select>
								</label>
								
								<label>
									<legend>Nazionalità</legend>
									<input name="nazionalità" type="text" class="input" value="Italiana"/>
								</label>
								
								<label>
									<legend>Cittadinanza</legend>
									<input name="cittadinanza" type="text" style="width:200px" class="input" value="Italiana"/>
								</label>
								
								<label>
									<legend>Ruolo</legend>
									<input name="ruolo" type="text" style="width:190px" class="input" value="Cliente"/>
								</label>
								
								<label>
									<legend>SAE</legend>
									<select name="sae" id="sae" class="input" style="width:200px">
									 <option value="">---</option>
									 <option value="">276 - Old-Agenti di Cambio</option>
									 <option value="">280 - Mediatori/Agenti e Consul.assic</option>
									 <option value="">284 - Altri Ausiliari Finanziari</option>
									 <option value="" selected>600 - Famiglie Consumatrici</option>
									 <option value="">615 - Altre Famiglie Produttrici</option>
									</select>
								</label>
								
								<label>
									<legend>ATECO</legend>
									<select name="ateco" id="ateco" class="input" style="width:200px">
									  <option value="">01 - Coltivazioni Agricole e Produzione</option>
									  <option value="">0111 - Coltivazione di Colture Agricole</option>
									  <option value="">01112 - Coltivazione di Semi Oleosi</option>
									  <option value="">01112 - Coltivazioni Miste di Cereali</option>
									  <option value="" selected>01120 - Coltivazione di Riso</option>
									  <option value="">011310 - Coltiv. Ortaggi in Piena Aria</option>
									</select>
								</label>
								
								<label>
									<legend>Professione</legend>
									<select name="professione" id="professione" class="input" style="width:160px">
									  <option value="">---</option>
									  <option value="">Studente</option>
									  <option value="">Pensionato</option>
									  <option value="">Casalinga</option>
									  <option value="">Redditiero</option>
									  <option value="">Disoccupato</option>
									  <option value="">Insegnante Scuola Privata/Pubb</option>
									  <option value="">Operaio o Assimilato</option>
									  <option value="" selected>Impiegato</option>
									  <option value="">Funzionario/Quadro</option>
									  <option value="">Magistrato</option>
									  <option value="">Militare o Forze Armate</option>
									  <option value="">Agente di Commercio</option>
									  <option value="">Sport e Spettacolo</option>
									  <option value="">Coltiv. Diretti/Imprend. Agric</option>
									  <option value="">Medico</option>
									  <option value="">Avvocato e Procuratore Legale</option>

									</select>
								</label>
					<div class="ricercabutton" ><button class="btn btn-search" style="float:right;clear:both;margin:20px 100px 0 0;"><i class="fa fa-floppy-o"></i> SALVA</button></div>
					</div>					
					</div>
						
				<h3><span style="height:3px;margin-left:35px;float:left"><b>Presenza in Intesa San Paolo</b></span></h3>
					  <div>
					</div>
				
				<h3><span style="height:26px;margin-left:35px;float:left"><b>Contatti</b></span></h3>
					  <div style="overflow-x: hidden;">
						<div class="dettagliocliente" style="margin: 15px 0 15px 25px">
								<label>
									<legend>Telefono Principale</legend>
									<input name="tel" type="text" style="width:240px" class="input" value="0307867145" disabled />
								</label>
								
								<label>
									<legend>E-Mail Principale</legend>
									<input name="mail" type="text" style="width:240px" class="input" value="mario.rossi@gmail.com" disabled />
								</label>
								
								
								<label style="float:left;clear:both;">
									<legend >Tipo Account Principale</legend>
									<select class="input" style="width:240px" disabled >
									<option selected="selected">Facebook</option>
									<option>Twitter</option>
									<option>LinkedIn</option>
									<option>Skype</option>
									</select>
								</label>
								
								<label>
									<legend>Social ID</legend>
									<input name="socialid" type="text" style="width:240px" class="input" value="/m.rossi" disabled />
								</label>
								
								<label style="float:left;clear:both">
								<legend style="font-family:Arial;font-size:14px; margin-top:10px">Se vuoi impostare come principale un altro contatto diverso<br>da questo vai nella sezione <b><a target="_blank" href="managecontacts.php"><u>Gestisci Contatti</u></a></b></legend>
								</label>
								
					</div>					
					</div>
				
				<h3><span style="height:26px;margin-left:35px;float:left"><b>Privacy</b></span></h3>
					  <div>
						<ul style="clear:both;float:left;list-style:none;padding:5px;width:385px;margin-right:0px;margin-bottom:0;">
							<li><b>C1)</b> Erogazione di servizi bancari e finanziari</li>
							<li><b>C2)</b> Indagini di mercato e offerta prodotti finanziari</li>
							<li><b>C3)</b> Offerta prodotti gruppo in base al profilo personale</li>
							<li><b>C4)</b> Indagini di mercato e offerta prodotti di terzi</li>
							<li><b>C6)</b> Dati sensibili</li>
							<br/>
							<li>Invio Informativa:</li>
							<br/>
											
						</ul>
									
						<ul style="float:left;list-style:none;padding:5px;margin-bottom:0;width:288px;">
							<li><i class="fa fa-check"></i>  il : 13/10/2016</li>
							<li><i class="fa fa-check"></i>  il : 13/10/2016</li>
							<li><i class="fa fa-check"></i>  il : 13/10/2016</li>
							<li><i class="fa fa-times"></i>  il : 13/10/2016</li>
							<li><i class="fa fa-check"></i>  il : 13/10/2016</li>
							<br/>
							<li>Uff./Archivio: 06006 VENEZIA MESTRE 01</li>	
							<br/>
							<li><a style="cursor:pointer;font-family:Arial;font-size:14px;"><u><b>Gestisci Consenso Privacy</b></u></a></li>
								
						</ul>
					</div>
					
					
					  
					  <h3><span style="height:26px;margin-left:35px;float:left"><b>Rapporti</b></span></h3>
					  <div>
						<ul style="clear:both;float:left;list-style:none;padding:5px;width:385px;margin-right:0px;margin-bottom:0;">
							<i style="margin-left:35px">Nessun rapporto presente</i>
							<br/>
							
						</ul>
						<ul style="float:left;list-style:none;padding:5px;margin-bottom:0;width:288px;">
							<br/>
							<li><a style="cursor:pointer;font-family:Arial;font-size:14px;"><u><b>Gestisci Rapporti</b></u></a></li>
						</ul>
						</div>
					  
						
					  
					  
					  <h3><span style="height:26px;margin-left:35px;float:left"><b>Collegamenti</b></span></h3>
					  <div style="overflow-x: hidden;">
						<div class="dettagliocliente" style="margin: 15px 0 15px 25px">
								<label>
									<legend>Codice Collegamento</legend>
									<input name="codcolle" type="text" style="width:220px" class="input" value="AMS - Amministratore di Sostegno" disabled />
								</label>
								
								<label>
									<legend>Intestazione Amministratore di Sostegno</legend>
									<input name="mail" type="text" style="width:190px" class="input" value="Giovanni Bianchi"/>
								</label>
								
								<label>
									<legend>CDN Amministratore di Sostegno</legend>
									<input name="socialid" type="text" style="width:150px" class="input" value="12445899"/>
								</label>
								
								<label style="float:left;clear:both">
								</label>
								
								<div>
								<ul style="clear:both;float:left;list-style:none;padding:5px;width:385px;margin-right:0px;margin-bottom:0;">
									<br/>
									
								</ul>
								<ul style="float:left;list-style:none;padding:5px;margin-bottom:0;width:288px;">
									<br/>
									<li><a href="managelegami.php" target="_blank" style="cursor:pointer;font-family:Arial;font-size:14px;"><u><b>Gestisci Collegamenti</b></u></a></li>
								</ul>
								</div>
								
								</div>
						</div>
					  
					 <h3><span style="height:26px;margin-left:35px;float:left"><b>Altro</b></span></h3>
						<div style="overflow-x: hidden;">
						<div class="dettagliocliente" style="margin: 15px 0 15px 25px">
								<label>
									<legend>Tipo Intermediario</legend>
									<select name="tipointermediario"  class="input" style="width:220px">
									<option value="">08 - Angente di Cambio</option>
									<option value="">10 - Int. Finanz. Art.107</option>
									<option value="">11 - Int. Finanz. Art.106</option>  
									<option value="">12 - Succ. Ital. Sogg.1-11</option>  
									<option value="">15 - Confidi</option>
									<option value="">16 - Cambiavalute</option> 
									<option value="">19 - Int.Assic.Art.109/2</option> 
									<option value="">20 - Mediatori Creditizi</option>
									<option value="">21 - Agenti Attiv. Finanz.</option> 
									<option value="">28 - Succ. Ital. Sogg. 23-26</option>
									<option value="">29 - Istituti Pagamento</option>
									<option value="">30 - Money Transfer</option>
									<option value="">32 - Compro Oro</option>
									<option value="">33 - Fondi Pubblici/Appalti</option>
									<option value="">35 - Operat. in Giochi e Scommesse</option>
									<option value="" selected>36 - Iranian Subject Approvati</option>
									<option value="">37 - Imp. Operante Sett. Armamenti</option>
								</select>
								</label>
								
								<label>
									<legend>Interesse DOF</legend>
									<select name="interesseDOF" style="width:100px" id="provincianascita" class="input">
								<option value="">---</option>
                                 <option value="" selected>S</option>
									</select>
								</label>
								
								<label style="clear:both">
									<legend>Residenza Fiscale</legend>
									<input name="residenzaf" type="text" class="input" style="width:220px" />
								</label>
								
								<label >
									<legend>International Tax Code (TIN)/NIF</legend>
									<input name="TIN" type="text" class="input" style="width:200px"/>
								</label>
								
								<label>
									<legend>GIIN</legend>
									<input name="GIIN" type="text" class="input" value="" style="width:100px"/>
								</label>
									
					<div class="ricercabutton" ><button class="btn btn-search" style="float:right;clear:both;margin:20px 100px 0 0;"><i class="fa fa-floppy-o"></i> SALVA</button></div>
					</div>					
					</div>  
				</div>
				
				<div class="maininfo details">
					<ul>Highlights
					<li>Ruoli: Cliente</li>
					</ul>

					<ul>
					  Ultimi aggiornamenti
					<li>13/10/2016: Censita in data odierna</li>
					</ul>

					<ul>Ultimi contatti
					<li>13/10/2016: Presentato in filiale</li>
					</ul>
					   </div>
				
				</div>
				
<?php include_once("include/footer.php"); ?>