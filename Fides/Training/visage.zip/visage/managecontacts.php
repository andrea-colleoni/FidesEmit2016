<?php include_once("include/header.php"); ?>

    <div style="height:50px;">
		<div class="col-md-12" style="position:fixed;background:white;">
			<h1 class="page-header" style="width:970px">GESTIONE CONTATTI <button class="btn ricercasemplice" onclick="MM_showHideLayers('ManageContacts','','show')"><i class="fa fa-bullseye"></i> Ricerca Semplice</button></h1>			
		</div>
	</div>
   
<div class="appcontainer">

<div style="width:970px;margin-top:8px;">
			<img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/1.jpg">
				<div style="padding-left:15px;margin-top:2px;float:left;font-size:13px"><i>Persona Fisica</i><br/><h3 style="margin:0">Mario Rossi</h3><div style="font-family:LatoWeb;weight:normal;font-size:12px;margin-top:2px;">Cod. Azienda: <b>1025</b>  CDN: <b>12365477</b></div></div>
				
				<div class="managecontacts">

					<div class="cbox">
					   <h3><span>Telefoni</span>
						  <button onclick="location.href='managecontact_tel_add.php';">
						  <i class="fa fa-plus-circle"></i> AGGIUNGI</button>
					   </h3>
					   <div>
						  <table>
							 <tr>
								<th>Tipo</th>
								<th>Numero</th>
								<th>Utilizzato per</th>
								<th>Rapporti</th>
								<th></th>
							 </tr>
							 <tr>
								<td>Cellulare Personale</td>
								<td>+39 331 4187871</td>
								<td>Multiplo</td>
								<td><i class="fa fa-check"></i></td>
								<td>
								   <button onclick="window.open('managecontact_tel.php','_blank');"><i class="fa fa-gear"></i> GESTISCI</button>
								</td>
							 </tr>
							 <tr>
								<td>Abitazione</td>
								<td>+39 0200000000</td>
								<td>Tutte le comunicazioni</td>
								<td></td>
								<td>
								   <button><i class="fa fa-gear"></i> GESTISCI</button>
								</td>
							 </tr>
							 <tr>
								<td>Ufficio</td>
								<td>+39 0110000000</td>
								<td>Promozionali e offerte</td>
								<td></td>
								<td>
								   <button><i class="fa fa-gear"></i> GESTISCI</button>
								</td>
							 </tr>
							 <tr>
								<td>FAX</td>
								<td>+39 0211100000</td>
								<td>Comunicazioni sull'operatività</td>
								<td><i class="fa fa-check"></i></td>
								<td>
								   <button><i class="fa fa-gear"></i> GESTISCI</button>
								</td>
							 </tr>
						  </table>
					   </div>
					</div>
					
					<div class="cbox">
					   <h3><span>Indirizzi</span>
						  <button>
						  <i class="fa fa-plus-circle"></i> AGGIUNGI</button>
					   </h3>
					   <div>
						  <table>
							 <tr>
								<th>Tipo</th>
								<th style="width:280px">Indirizzo</th>
								<th>Utilizzato per</th>
								<th>Rapporti</th>
								<th></th>
							 </tr>
							 <tr>
								<td>Residenza</td>
								<td>Via Carlo Cattaneo 6 - 25125 Brescia (BS)</td>
								<td>Tutte le comunicazioni</td>
								<td><i class="fa fa-check"></i></td>
								<td>
								   <button><i class="fa fa-gear"></i> GESTISCI</button>
								</td>
							 </tr>
						  </table>
					   </div>
					</div>
					
					<div class="cbox">
					   <h3><span>E-Mail</span>
						  <button>
						  <i class="fa fa-plus-circle"></i> AGGIUNGI</button>
					   </h3>
					   <div>
						  <table>
							 <tr>
								<th>Tipo</th>
								<th>E-Mail</th>
								<th>Utilizzato per</th>
								<th>Rapporti</th>
								<th></th>
							 </tr>
							 <tr>
								<td>E-Mail</td>
								<td>mario.rossi@gmail.com</td>
								<td>Tutte le comunicazioni</td>
								<td><i class="fa fa-check"></i></td>
								<td>
								   <button><i class="fa fa-gear"></i> GESTISCI</button>
								</td>
							 </tr>
						  </table>
					   </div>
					</div>
					
					<div class="cbox">
					   <h3><span>Account</span>
						  <button>
						  <i class="fa fa-plus-circle"></i> AGGIUNGI</button>
					   </h3>
					   <div>
						  <table>
							 <tr>
								<th>Tipo</th>
								<th>Social-ID</th>
								<th>Utilizzato per</th>
								<th>Rapporti</th>
								<th></th>
							 </tr>
							 <tr>
								<td>Facebook</td>
								<td>/m.rossi</td>
								<td>Promozionali e offerte</td>
								<td></td>
								<td>
								   <button><i class="fa fa-gear"></i> GESTISCI</button>
								</td>
							 </tr>
						  </table>
					   </div>
					</div>
					
				</div>
				
				<div style="float:left;">
					<div class="maininfo details">
						<ul>Highlights
						<li>Ruoli: Cliente</li>
						<li>Collegato a: Gruppo Ferrero S.p.A. (CDN 1234567)</li>
						</ul>

						<ul>
						  Ultimi aggiornamenti
						  <li>25/04/2016: aggiornamento documento d’identità</li>
						<li>25/04/2016: compilazione MiFid</li>
						<li>25/04/2016: censimento delega</li>
						</ul>

						<ul>Ultimi contatti
						<li>25/04/2016: rinnovato Titoli</li>
						<li>225/04/2016: proposto nuova assicurazione</li>
						<li>26/04/2016: invio mail preventivo assicurazione</li>
						</ul>
					</div>
					
					<div class="latestinsert" style="clear:both;margin:8px 15px;margin-right:0;width:260px;">
						<div class="latestinsert-title" style="width:260px;">Ultime Controparti elaborate</div>
						<ul>
							<li><i class="fa fa-plug"></i>CC <a href="#" onclick="copy2clipboard(this)">4152677</a> Mario Rossi</li>
							<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">52618276</a> Mario Rossi</li>
							<li><i class="fa fa-plug"></i>CDN <a href="#" onclick="copy2clipboard(this)">5514332</a> Gruppo Siemens</li>
							<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">98126</a> Ferrandi srl</li>
						</ul>
					</div>
				</div>
    
</div>

    </div>
	
<?php include_once("include/footer.php"); ?>