<?php include_once("include/header.php"); ?>

    <div style="height:50px;">
		<div class="col-md-12" style="position:fixed;background:white;">
			<h1 class="page-header" style="width:970px">Dashboard</h1>
		</div>
	</div>
   
<div class="maindashboard">
<div style="width:360px; height:400px; float:left;">
		<div class="ricercanagrafica">
    					<div class="slidingopen">
						
      						<h3 class="IcoSlideSearch">Ricerca Libera</h3>
                                  <div>
                                    <div class="selectsearch">
                                    <div>
                                          <label>
                                          <legend>+ PRECISA</legend>
                                            <input type="checkbox" name="RadioGroup1" value="pulsante di scelta" id="RadioGroup1_0">
                                           </label>
                                    </div>                                   
                                    </div>
                                    <div style="margin-bottom:3px;">
										<label style="margin-top:-20px;">
										<legend>Azienda</legend>
										  <select name="select" class="input">
											<option>1010  Banco di Napoli</option>
											<option selected>1025 Intesa Sanpaolo S.p.A.</option>
											<option>3059 Banca di Credito Sardo</option>
											<option>3099 Neos Banca</option>
											<option>3110 Farbanca S.p.A.</option>
											<option>3163 State Street Bank</option>
											<option>3239 I.S. Private Banking</option>
											<option>3240 Banca di Trento e Bolzano</option>
											<option>3249 Banca IMI</option>
											<option>3296 Banca Fideuram</option>
											<option>3309 BIIS</option>
											<option>3359 Banca Prossima</option>
											<option>5748 Banca dell'Adriatico</option>
											<option>6010 C.R. Forlì e della Romagna</option>
											<option>6030 Banca C.R Spezia</option>
											<option>6065 C.R. Provincia di Viterbo</option>
										  </select>
										  </label>
                                        <label style="margin-top:-20px;">
                                        <legend>Tipo Controparte</legend>
                                        <select class="input type">
                                        <option>F – Fisica</option>
                                        <option>G – Giuridica</option>
                                        <option>C – Cointestazione</option>
                                        </select>
                                        </label> 
                                        <label>
                                        <legend>Cognome/Ragione Sociale</legend>
                                        <input name="Intestazione" type="search" id="Intestazione" class="input intestazione" style="width:170px" value="" />
                                        </label>
                                        <label>
                                        <legend>Nome</legend>
                                        <input name="Intestazione" type="search" id="Intestazione" class="input intestazione" style="width:170px" value="" />
                                        </label>
                                        <label style="clear:both">
                                        <legend>Data di nascita</legend>
                                        <input name="giornonascita" type="text" id="giornonascita" class="input date" value="" />
                                        <input name="mesenascita" type="text" id="mesenascita" class="input date" value=""/>
                                        <input name="annonascita" type="text" id="annonascita" class="input year" value=""/>
                                        </label>
                                        <label>
                                        <legend>Luogo di nascita</legend>
                                        <input name="luogonascita" type="text" id="luogonascita" class="input birthplace" value="" />
                                        </label>
                                        <label>
                                        <legend>CAP</legend>
                                        <input type="text" value="" class="input cap">
                                        </label>
                                        <label>
                                        <legend>Residenza</legend>
                                        <input name="residenza" type="search" id="residenza" class="input address" value="" placeholder="Comune/Provincia/Nazione" 
											onkeyup="if(this.value == '') this.style.color = '#AAA'; else this.style.color = '#323232';" style="color:#AAA" />
                                        </label>
                                        <label>
                                        <legend>CAP</legend>
                                        <input type="text" value="" class="input cap">
                                        </label>
										<label>
										<legend>Filtra per altro valore</legend>
										<select class="input type">
                                        <option>---</option>
                                        <option>Cittadinanza</option>
                                        <option>Segmento creditizio</option>
                                        <option>Classificazione economica</option>
                                        </select>
										</label>
										<label>
										<input type="text" value="" id="Intestazione" class="input intestazione" />
										</label>
                                 </div>
								 
								 <strong>Filtri Aggiuntivi</strong>
								 <hr/>
								<div>
								<table>
				
				
				<tr>
					<legend>Ruolo<legend>
					<td style="padding-bottom:3px"><select name="ruolo" class="input type">
						<option value="">---</option>
						<option value="C">Cliente</option>
						<option value="D">Fornitore</option>
						<option value="E">Parte Correlata</option>
						<option value="P">Prospect</option>
						<option value="G">Gruppo</option>
					</select></td>
				</tr>
				
				
				
				<tr>
					<td colspan="2"  class="radioname">
						<input type="checkbox" name="check_mc" value="mc" /> Miei clienti<br/>
						<input type="checkbox" name="check_g" value="g" /> Gruppi<br/>
						<input type="checkbox" name="check_c" value="c" /> Cointestazioni
					</td>
				</tr>
			</table>
		</div>
								 
     							 </div>
                              <h3 class="IcoSlideFilter">Ricerca per Codici</h3>
                                  <div>
                                        <label>
                                        <legend>Azienda</legend>
                                        <select class="input">
										<option>Tutte</option>
                                        <option>1010  Banco di Napoli</option>
                                        <option selected>1025 Intesa Sanpaolo S.p.A.</option>
                                        <option>3059 Banca di Credito Sardo</option>
                                        <option>3099 Neos Banca</option>
                                        <option>3110 Farbanca S.p.A.</option>
                                        <option>3163 State Street Bank</option>
                                        <option>3239 I.S. Private Banking</option>
                                        <option>3240 Banca di Trento e Bolzano</option>
                                        <option>3249 Banca IMI</option>
                                        <option>3296 Banca Fideuram</option>
                                        <option>3309 BIIS</option>
                                        <option>3359 Banca Prossima</option>
                                        <option>5748 Banca dell'Adriatico</option>
                                        <option>6010 C.R. Forlì e della Romagna</option>
                                        <option>6030 Banca C.R Spezia</option>
                                        <option>6065 C.R. Provincia di Viterbo</option>
                                        </select>
                                        </label> 
                                        <label>
                                        <legend>Filiale</legend>
                                        <select class="input">
											<option value="">---</option>
											<option value="A2300">A2300 - Gest. Clienti privat</option>
											<option value="A2400">A2400 - Segm.priv./serv./con</option>
											<option value="A2600">A2600 - Serv.supporto privato</option>
											<option value="A3000">A3000 - Marketing</option>   
											<option value="A3050">A3050 - Coordinamento filiale</option>
											<option value="A3051">A3051 - Crediti</option>       
											<option value="A3310">A3310 - Contenz.e cons.legal</option>
											<option value="A3311">A3311 - Legale</option>        
											<option value="A3320">A3320 - Istruttoria legale</option>
											<option value="A3322">A3322 - Recupero crediti</option>
											<option value="A3330">A3330 - Istruttoria tecnica</option>
											<option value="A4010">A4010 - Special prodotto inv</option>
											<option value="A4015">A4015 - Special prodotto est</option>
											<option value="A4050">A4050 - Prodotto fondiario</option>
											<option value="A4060">A4060 - Prod. crediti specia</option>
											<option value="A4065">A4065 - Funz. commerc. di ar</option>
											<option value="A4066">A4066 - Svil.commerciale</option>
											<option value="A4070">A4070 - Prod. telematici</option>
                                        </select>                                        
                                        </label>
                                        <label>
                                        <legend>Tipo Rapporto</legend>
                                        <input name="Rapporto" type="text" id="inputRapporto" class="input rapporto" value="" />
                                        </label>
                                        <label>
                                        <legend>Numero Rapporto</legend>
                                        <input name="CC" type="text" id="inputCC" class="input CC" value="" />
                                        </label>
                                        <label>
                                        <legend>ID Locale</legend>
                                        <input name="ID Locale" type="text" id="inputID Locale" class="input ID Locale" value="" />
                                        </label>
										
									<div style="margin-top:3px;margin-bottom:8px;padding:3px 8px;background-color:#F2F2F2;border-radius:8px;border:1px solid #ccc!important;" >
									
                                        <label>
                                        <legend>Cerca Valore</legend>
                                        <input name="Chiavi" type="search" id="inputChiavi" class="input chiavi" />
                                        </label>
                                        <table>
										<legend>Su</legend>
                                        <tr>
                                        <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroupA1" checked="checked" onclick="showSelect('chiavi')"></td>
                                        <td class="radioname">Chiavi</td>
                                        <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroupA2" onclick="showSelect('contatti')"></td>
                                        <td class="radioname">Contatti</td>
                                        <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroupA3" onclick="showSelect('documenti')"></td>
                                        <td class="radioname">Documenti</td>
                                        </tr>
                                        <tr>
                                        <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroupA4" onclick="showSelect('')"></td>
                                        <td class="radioname">CDN</td>
                                        <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroupA5" onclick="showSelect('raccordoeventi')"></td>
                                        <td class="radioname">Raccordo Eventi</td>
                                        <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroupA6" onclick="showSelect('altro')"></td>
                                        <td class="radioname">Altro</td>
                                        </tr>
                                        <tr>
                                        <td colspan="6" id="key_select">
										<legend>Come</legend>
											<select class="input radioselect" name="chiavi" style="display:block;">
												<option value="">Codice Fiscale</option>
												<option value="">Partita IVA</option>
												<option value="">Codice Operatore Estero</option>
											</select>
											<select class="input radioselect" name="contatti">
												<option value="">Telefono</option>
												<option value="">Email</option>
												<option value="">Account</option>
											</select>
											<select class="input radioselect" name="documenti">
												<option value="">Carta d’identità</option>
												<option value="">Passaporto</option>
												<option value="">Patente</option>
												<option value="">Certificato d’identità per minori</option>
												<option value="">Permesso di soggiorno</option>
												<option value="">Tessera dipendenti statali</option>
												<option value="">Porto d’armi</option>
												<option value="">Tessera militare</option>
												<option value="">Patente nautica</option>
												<option value="">Certificato identità per minori</option>
											</select>
											<select class="input radioselect" name="raccordoeventi">
												<option>1010 Banco di Napoli</option>
												<option>1025 Intesa Sanpaolo S.p.A.</option>
												<option>3059 Banca di Credito Sardo</option>
												<option>3099 Neos Banca</option>
												<option>3110 Farbanca S.p.A.</option>
												<option>3163 State Street Bank</option>
												<option>3239 I.S. Private Banking</option>
												<option>3240 Banca di Trento e Bolzano</option>
												<option>3249 Banca IMI</option>
												<option>3296 Banca Fideuram</option>
												<option>3309 BIIS</option>
												<option>3359 Banca Prossima</option>
												<option>5748 Banca dell'Adriatico</option>
												<option>6010 C.R. Forlì e della Romagna</option>
												<option>6030 Banca C.R Spezia</option>
												<option>6065 C.R. Provincia di Viterbo</option>
											</select>
											<select class="input radioselect" name="altro">
												<option value="">Identita' digitale</option>
											</select>
                                        </td>
                                        <td></td>
                                        <td></td>
                                        </tr>
                                        </table> 
										
									</div>
								 <strong>Filtri Aggiuntivi</strong>
								 <hr/>
								<div>
								<table>
				
				
				<tr>
					<legend>Ruolo<legend>
					<td style="padding-bottom:3px"><select name="ruolo" class="input type">
						<option value="">---</option>
						<option value="C">Cliente</option>
						<option value="D">Fornitore</option>
						<option value="E">Parte Correlata</option>
						<option value="P">Prospect</option>
						<option value="G">Gruppo</option>
					</select></td>
				</tr>
				
				
				
				<tr>
					<td colspan="2" class="radioname">
						<input type="checkbox" name="check_g" value="g" /> Gruppi<br/>
						<input type="checkbox" name="check_c" value="c" /> Cointestazioni
					</td>
				</tr>
			</table>
		</div>

     							 </div>
    				</div>
					
					
					
  					<div class="ricercabutton"><a href="./results.php" target="_blank"><button id="btnFilter" class="btn btn-search"><i class="fa fa-search"></i> CERCA</button></a></div>
					  </div>

</div>

<div style="width:610px; float:left; padding-left:31px;">
    <div class="appdashboard">
        <div id="CustomerManage" class="context-menu" title="Gestisci Controparte" onclick="MM_showHideLayers('ManageCustomer','','show')"></div>
        <div id="CustomerNew" title="Nuova Controparte"><a href="newcustomer.php" target="_blank"></a></div>
        <div id="CustomerRelationship" title="Gestisci Legami" onclick="MM_showHideLayers('ManageLegami','','show')"></div>
        <div id="GroupsManage" title="Gestisci Gruppi"></div>
        <div id="AcquireDocuments" title="Rapporti"></div>
    </div>
</div>



<div style="width:265px; height:170px; float:left; margin:2px 16px 0 10px;">
    <div class="latestinsert">
    	<div class="latestinsert-title">Ultime Funzioni usate</div>
                <ul>
                <li><i class="fa fa-wrench"></i><a href="#">Documenti</a></li>
                <li><i class="fa fa-wrench"></i><a href="#">Gestione Contatti</a></li>
                <li><i class="fa fa-wrench"></i><a href="#">Dati Rapporto</a></li>
                <li><i class="fa fa-wrench"></i><a href="#">Dati Anagrafici</a></li>
                </ul>
		</div>
</div>
<div style="width:265px; height:170px; float:left; margin:2px 0 0 5px;">
    <div class="latestinsert">
    	<div class="latestinsert-title">Ultime Controparti elaborate</div>
                <ul>
					<li><i class="fa fa-plug"></i>CC <a href="#" onclick="copy2clipboard(this)">4152677</a> Mario Rossi</li>
					<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">52618276</a> Mario Rossi</li>
					<li><i class="fa fa-plug"></i>CDN <a href="#" onclick="copy2clipboard(this)">5514332</a> Gruppo Siemens</li>
					<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">98126</a> Ferrandi srl</li>
				</ul>
		</div>
</div>
<div class="latestlist">
    	<div class="latestlist-title">Avvisi e Notifiche</div>
        <div class="latestlistmain">
        <table>
			<tr>
				<th class="sorticon"><i class="fa fa-chevron-up"><span style="padding-left:5px">Tipo</span></i></th>
				<th class="sortdate"><i class="fa fa-chevron-down"><span style="padding-left:5px">Data</span></i></th>
				<th class="sortitem"><i class="fa fa-chevron-down"><span style="padding-left:5px">Descrizione</span></i></th>
			</tr>
			<tr>
				<td><i class="fa fa-bell-o"></i></td>
				<td>08/09/2016</td>
				<td><a href="#">Aggiornato documento Rosa Marti 33324</a></td>
			</tr>
			<tr>
				<td><i class="fa fa-bell-o"></i></td>
				<td>08/09/2016</td>
				<td><a href="#">Aggiornato Gruppo De Cecco 618927</a></td>
			</tr>
			<tr>
				<td><i class="fa fa-bell-o"></i></td>
				<td>07/09/2016</td>
				<td><a href="#">Aggiornato Gruppo IntesaSanPaolo</a></td>
			</tr>
			<tr>
				<td><i class="fa fa-bolt"></i></td>
				<td>07/09/2016</td>
				<td><a href="#">Completa censimento Mario Rossi 44152</a></td>
			</tr>
			<tr>
				<td><i class="fa fa-bolt"></i></td>
				<td>07/09/2016</td>
				<td><a href="#">Verifica composizione Allegri group 231448</a></td>
			</tr>
			<tr>
				<td colspan="3"><div class="latestlistbutton"><a href="#"><i class="fa fa-eye"></i> Vedi Tutti</a></div></td>
			</tr>
		</table>        
		</div>
	</div>
</div>

<?php include_once("include/footer.php"); ?>