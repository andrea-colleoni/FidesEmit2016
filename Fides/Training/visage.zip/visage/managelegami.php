<?php include_once( "include/header.php"); ?>

<div style="height:50px;">
    <div class="col-md-12" style="position:fixed;background:white;">
        <h1 class="page-header" style="width:970px">GESTIONE LEGAMI <button class="btn ricercasemplice" onclick="MM_showHideLayers('ManageLegami','','show')"><i class="fa fa-bullseye"></i> Ricerca Semplice</button></h1>
    </div>
</div>

<div class="appcontainer">

    <div style="width:970px;margin-top:8px;">
	<img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/azienda.png">
        <div style="padding-left:15px;margin-top:2px;float:left;font-size:13px"><i>Società Responsabilità Limitata</i>
            <br/>
            <h3 style="margin:0">Boschi Paolo e Figlio</h3>
            <div style="font-family:LatoWeb;weight:normal;font-size:12px;margin-top:2px;">Cod. Azienda: <b>1025</b>  CDN: <b>251388000</b>
            </div>
        </div>

        <button class="btn newlegame" style="margin-right:280px;margin-top:40px" onclick="MM_showHideLayers('AggiungiLegame','','show')"><i class="fa fa-plus-circle"></i> Aggiungi Legame</button>

        <div class="managelegami">
            <h2>SOCI</h2>
            <div class="legami-list">
                <div class="legame-header">
                    <span style="height:26px;width:226px;float:left">CDN Collegato: 56987635</span>
                    <span style="height:26px;width:226px;float:left">Gian Franco Villari</span>
                    <span style="height:26px;width:226px;float:left">Amministratore Delegato</span>
                </div>

                <div class="clearfix legame-content">

                    <img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/2.jpg">
                    <div style="float:left;margin-left:8px; margin-top:16px; font-size:18px;"><i>Socio di</i><br/>Boschi Paolo e Figlio</div>
                    <div style="float:left;clear:both;width: 369px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Legame</div>
						<ul style="padding:0;line-height:18px">
                            <li>Tipo collegamento: <b>SOC - Socio</b></li>
							<li>Specifica di collegamento: <b>AD - Amministratore Delegato</b></li>
                            <li>Quota di partecipazione: <b>60%</b></li>
                            <li>Data inizio carica: <b>01/01/2010</b></li>
                            <li>Data fine carica: <b>01/01/2016</b></li>
                        </ul>
                        <button class="btn" style="width:138px;margin-top:97px;height:26px!important;" onclick="MM_showHideLayers('ModificaLegame','','show')"><i style="display:inline-block!important" class="fa fa-gear"></i> MODIFICA LEGAME</button>
                        <button class="btn" style="width:138px;margin-right:8px;margin-top:97px;height:26px!important;" onclick="MM_showHideLayers('RimuoviLegame','','show')"><i style="display:inline-block!important" class="fa fa-trash"></i> RIMUOVI LEGAME</button>
                    </div>

                    <div style="border-left: 1px solid #ccc;padding-left: 42px;float:left;width: 292px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Controparte</div>
                        <ul style="padding:0;line-height:18px">
                            <li>Tipo ID Locale: <b>PF</b></li>
                            <li>Codice Fiscale: <b>VLLGFR78R10B157P</b></li>
                            <li>Genere: <b>Maschio</b></li>
                            <li>Nazionalità: <b>Italiana</b></li>
                            <li>Cittadinanza: <b>Italiana</b></li>
                            <li>Ruolo: <b>Cliente</b></li>
                            <li>Luogo di nascita: <b>Brescia</b></li>
                            <li>Data di nascita: <b>10/10/1978</b></li>
                            <li>Professione: <b>Impiegato</b></li>
                            <li>SAE: <b>Famiglie Consumatrici</b></li>
                            <li>ATECO: <b>---</b></li>
                        </ul>
                        
						<a href="./managelegami2.php"><u>Visualizza collegamenti controparte</u></a>

                    </div>
                </div>
				
				
				 <div class="legame-header">
                    <span style="height:26px;width:226px;float:left">CDN Collegato: 34876194</span>
                    <span style="height:26px;width:226px;float:left">Sergio Bruni</span>
                    
                </div>

                <div class="clearfix legame-content">

                    <img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/3.jpg">
                    <div style="float:left;margin-left:8px; margin-top:16px; font-size:18px;"><i>Socio di</i><br/>Boschi Paolo e Figlio</div>
                    <div style="float:left;clear:both;width: 369px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Legame</div>
						<ul style="padding:0;line-height:18px">
							<li>Tipo collegamento: <b>SOC - Socio</b></li>
                            <li>Quota di partecipazione: <b>30%</b></li>
                            
                        </ul>
                        <button class="btn" style="width:138px;margin-top:150px;height:26px!important;" onclick="MM_showHideLayers('ModificaLegame2','','show')"><i style="display:inline-block!important" class="fa fa-gear"></i> MODIFICA LEGAME</button>
                        <button class="btn" style="width:138px;margin-right:8px;margin-top:150px;height:26px!important;" onclick="MM_showHideLayers('RimuoviLegame','','show')"><i style="display:inline-block!important" class="fa fa-trash"></i> RIMUOVI LEGAME</button>
                    </div>

                    <div style="border-left: 1px solid #ccc;padding-left: 42px;float:left;width: 292px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Controparte</div>
                        <ul style="padding:0;line-height:18px">
                             <li>Tipo ID Locale: <b>PF</b></li>
                            <li>Codice Fiscale: <b>BRNSRG84B03B1257S</b></li>
                            <li>Genere: <b>Maschio</b></li>
                            <li>Nazionalità: <b>Italiana</b></li>
                            <li>Cittadinanza: <b>Italiana</b></li>
                            <li>Ruolo: <b>Cliente</b></li>
                            <li>Luogo di nascita: <b>Brescia</b></li>
                            <li>Data di nascita: <b>03/02/1984</b></li>
                            <li>Professione: <b>Impiegato</b></li>
                            <li>SAE: <b>Famiglie Consumatrici</b></li>
                            <li>ATECO: <b>---</b></li>
                        </ul>
                        
						<a><u>Visualizza collegamenti controparte</u></a>

                    </div>
                </div>
				
				
				 <div class="legame-header">
                    <span style="height:26px;width:226px;float:left">CDN Collegato: 84625173</span>
                    <span style="height:26px;width:226px;float:left">Aileen De Villa</span>
                   
                </div>

                <div class="clearfix legame-content">

                    <img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/4.jpg">
                    <div style="float:left;margin-left:8px; margin-top:16px; font-size:18px;"><i>Socio di</i><br/>Boschi Paolo e Figlio</div>
                    <div style="float:left;clear:both;width: 369px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Legame</div>
						<ul style="padding:0;line-height:18px">
                            <li>Tipo collegamento: <b>SOC - Socio</b></li>
                            <li>Quota di partecipazione: <b>10%</b></li>

                        </ul>
                        <button class="btn" style="width:138px;margin-top:150px;height:26px!important;" onclick="MM_showHideLayers('ModificaLegame','','show')"><i style="display:inline-block!important" class="fa fa-gear"></i> MODIFICA LEGAME</button>
                        <button class="btn" style="width:138px;margin-right:8px;margin-top:150px;height:26px!important;" onclick="MM_showHideLayers('RimuoviLegame','','show')"><i style="display:inline-block!important" class="fa fa-trash"></i> RIMUOVI LEGAME</button>
                    </div>

                    <div style="border-left: 1px solid #ccc;padding-left: 42px;float:left;width: 292px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Controparte</div>
                        <ul style="padding:0;line-height:18px">
                            <li>Tipo ID Locale: <b>PF</b></li>
                            <li>Codice Fiscale: <b>DVLLNA69T08B157N</b></li>
                            <li>Genere: <b>Maschio</b></li>
                            <li>Nazionalità: <b>Italiana</b></li>
                            <li>Cittadinanza: <b>Italiana</b></li>
                            <li>Ruolo: <b>Cliente</b></li>
                            <li>Luogo di nascita: <b>Brescia</b></li>
                            <li>Data di nascita: <b>08/12/1969</b></li>
                            <li>Professione: <b>Impiegato</b></li>
                            <li>SAE: <b>Famiglie Consumatrici</b></li>
                            <li>ATECO: <b>---</b></li>
                        </ul>
                        
						<a><u>Visualizza collegamenti controparte</u></a>

                    </div>
                </div>

            </div>
			
			<div class="legami-list">
			<h2>GRUPPI</h2>
			<div class="legame-header">
                    <span style="height:26px;width:226px;float:left">CDN Collegato: 16243578</span>
                    <span style="height:26px;width:226px;float:left">Gruppo Fiat</span>
                    
                </div>

                <div class="clearfix legame-content">

                    <img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/fiat.png">
                    <div style="float:left;margin-left:8px; margin-top:16px; font-size:18px;"><i>Gruppo a cui partecipa</i><br/>Boschi Paolo e Figlio</div>
                    <div style="float:left;clear:both;width: 369px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Legame</div>
						<ul style="padding:0;line-height:18px">
						    <li>Tipo collegamento: <b>???</b></li>
                            <li>Specifica di collegamento: <b>???</b></li>
                            <li>Quota di partecipazione: <b>30%</b></li>

                            
                        </ul>
                        <button class="btn" style="width:138px;margin-top:132px;height:26px!important;" onclick="MM_showHideLayers('ModificaLegame','','show')"><i style="display:inline-block!important" class="fa fa-gear"></i> MODIFICA LEGAME</button>
                        <button class="btn" style="width:138px;margin-right:8px;margin-top:132px;height:26px!important;" onclick="MM_showHideLayers('RimuoviLegame','','show')"><i style="display:inline-block!important" class="fa fa-trash"></i> RIMUOVI LEGAME</button>
                    </div>

                    <div style="border-left: 1px solid #ccc;padding-left: 42px;float:left;width: 292px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Controparte</div>
                        <ul style="padding:0;line-height:18px">
                             <li>Tipo ID Locale: <b>PF</b></li>
                            <li>Codice Fiscale: <b>---</b></li>
                            <li>Genere: <b>Maschio</b></li>
                            <li>Nazionalità: <b>Italiana</b></li>
                            <li>Cittadinanza: <b>Italiana</b></li>
                            <li>Ruolo: <b>Cliente</b></li>
                            <li>Luogo di nascita: <b>Brescia</b></li>
                            <li>Data di nascita: <b>10/10/1978</b></li>
                            <li>Professione: <b>Impiegato</b></li>
                            <li>SAE: <b>Famiglie Consumatrici</b></li>
                            <li>ATECO: <b>---</b></li>
                        </ul>
                        
						<a><u>Visualizza collegamenti controparte</u></a>

                    </div>
                </div>
			</div>
			
			
		<div class="legami-list">
			<h2>LEGAMI PRESUNTI</h2>
			<div class="legame-header">
                    <span style="height:26px;width:226px;float:left">CDN Collegato: 84521637</span>
                    <span style="height:26px;width:226px;float:left">Giorgio Prevalle</span>
                    <span style="height:26px;width:127px;float:right; "><i>molto affidabile   </i><img style="margin-top:-4px; margin-right:10px; width:20px" src="Assets/img/circle-green.svg"/></span>
                </div>

                <div class="clearfix legame-content">

                    <img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/1.jpg">
                    <div style="float:left;margin-left:8px; margin-top:16px; font-size:18px;"><i>Legame presunto di</i><br/>Boschi Paolo e Figlio</div>
                    <div style="float:left;clear:both;width: 369px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Legame</div>
						<ul style="padding:0;line-height:18px">
						    <li>Descrizione: <b>in base ai movimenti della carta</b></li>
                            <li>Data Latenza: <b>12/10/2015</b></li>
                            <li>Condizione di legame: <b>Certificato</b></li>
							<br/>
							<br/>
							<li>Grado di affidabilità: <span><b>molto affidabile</b><img style="width:45px" src="Assets/img/green-sem.svg"/></span></li>
                            
                        </ul>
                        <button class="btn" style="width:138px;margin-top:52px;height:26px!important;" onclick="MM_showHideLayers('ModificaLegame','','show')"><i style="display:inline-block!important" class="fa fa-gear"></i> MODIFICA LEGAME</button>
                        <button class="btn" style="width:138px;margin-right:8px;margin-top:52px;height:26px!important;" onclick="MM_showHideLayers('RimuoviLegame','','show')"><i style="display:inline-block!important" class="fa fa-trash"></i> RIMUOVI LEGAME</button>
                    </div>

                    <div style="border-left: 1px solid #ccc;padding-left: 42px;float:left;width: 292px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Controparte</div>
                        <ul style="padding:0;line-height:18px">
                             <li>Tipo ID Locale: <b>PF</b></li>
                            <li>Codice Fiscale: <b>---</b></li>
                            <li>Genere: <b>Maschio</b></li>
                            <li>Nazionalità: <b>Italiana</b></li>
                            <li>Cittadinanza: <b>Italiana</b></li>
                            <li>Ruolo: <b>Cliente</b></li>
                            <li>Luogo di nascita: <b>Brescia</b></li>
                            <li>Data di nascita: <b>10/10/1978</b></li>
                            <li>Professione: <b>Impiegato</b></li>
                            <li>SAE: <b>Famiglie Consumatrici</b></li>
                            <li>ATECO: <b>---</b></li>
                        </ul>
                        
						<a><u>Visualizza collegamenti controparte</u></a>

                    </div>
                </div>
				
					<div class="legame-header">
                    <span style="height:26px;width:226px;float:left">CDN Collegato: 65741289</span>
                    <span style="height:26px;width:226px;float:left">Simone Faretti</span>
					<span style="height:26px;width:95px;float:right; "><i>affidabile   </i><img style="margin-top:-4px; margin-right:10px; width:20px" src="Assets/img/circle-yellow.svg"/></span>
                </div>

                <div class="clearfix legame-content">

                    <img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/5.jpg">
                    <div style="float:left;margin-left:8px; margin-top:16px; font-size:18px;"><i>Legame presunto di</i><br/>Boschi Paolo e Figlio</div>
                    <div style="float:left;clear:both;width: 369px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Legame</div>
						<ul style="padding:0;line-height:18px">
						    <li>Descrizione: <b>in base ai movimenti dei bonifici</b></li>
                            <li>Data Latenza: <b>12/10/2015</b></li>
                            <li>Condizione di legame: <b>Certificato</b></li>
							<br/>
							<br/>
							<li>Grado di affidabilità: <span><b>affidabile</b><img style="width:45px" src="Assets/img/yellow-sem.svg"/></span></li>
                            
                        </ul>
                        <button class="btn" style="width:138px;margin-top:52px;height:26px!important;" onclick="MM_showHideLayers('ModificaLegame','','show')"><i style="display:inline-block!important" class="fa fa-gear"></i> MODIFICA LEGAME</button>
                        <button class="btn" style="width:138px;margin-right:8px;margin-top:52px;height:26px!important;" onclick="MM_showHideLayers('RimuoviLegame','','show')"><i style="display:inline-block!important" class="fa fa-trash"></i> RIMUOVI LEGAME</button>
						</div>

                    <div style="border-left: 1px solid #ccc;padding-left: 42px;float:left;width: 292px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Controparte</div>
                        <ul style="padding:0;line-height:18px">
                             <li>Tipo ID Locale: <b>PF</b></li>
                            <li>Codice Fiscale: <b>---</b></li>
                            <li>Genere: <b>Maschio</b></li>
                            <li>Nazionalità: <b>Italiana</b></li>
                            <li>Cittadinanza: <b>Italiana</b></li>
                            <li>Ruolo: <b>Cliente</b></li>
                            <li>Luogo di nascita: <b>Brescia</b></li>
                            <li>Data di nascita: <b>10/10/1978</b></li>
                            <li>Professione: <b>Impiegato</b></li>
                            <li>SAE: <b>Famiglie Consumatrici</b></li>
                            <li>ATECO: <b>---</b></li>
                        </ul>
                        
						<a><u>Visualizza collegamenti controparte</u></a>

                    </div>
                </div>
				
					<div class="legame-header">
                    <span style="height:26px;width:226px;float:left">CDN Collegato: 68741258</span>
                    <span style="height:26px;width:226px;float:left">Antonio Riccardi</span>
					<span style="height:26px;width:125px;float:right; "><i>poco affidabile   </i><img style="margin-top:-4px; margin-right:10px; width:20px" src="Assets/img/circle-red.svg"/></span>

                </div>

                <div class="clearfix legame-content">

                    <img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/6.jpg">
                    <div style="float:left;margin-left:8px; margin-top:16px; font-size:18px;"><i>Legame presunto di</i><br/>Boschi Paolo e Figlio</div>
                    <div style="float:left;clear:both;width: 369px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Legame</div>
						<ul style="padding:0;line-height:18px">
						    <li>Descrizione: <b>in base ai movimenti della carta</b></li>
                            <li>Data Latenza: <b>12/10/2015</b></li>
                            <li>Condizione di legame: <b>Non Certificato</b></li>
							<br/>
							<br/>
							<li>Grado di affidabilità: <span><b>poco affidabile</b><img style="width:45px" src="Assets/img/red-sem.svg"/></span></li>
                            
                        </ul>
                        <button class="btn" style="width:138px;margin-top:52px;height:26px!important;" onclick="MM_showHideLayers('ModificaLegame','','show')"><i style="display:inline-block!important" class="fa fa-gear"></i> MODIFICA LEGAME</button>
                        <button class="btn" style="width:138px;margin-right:8px;margin-top:52px;height:26px!important;" onclick="MM_showHideLayers('RimuoviLegame','','show')"><i style="display:inline-block!important" class="fa fa-trash"></i> RIMUOVI LEGAME</button>
                    </div>

                    <div style="border-left: 1px solid #ccc;padding-left: 42px;float:left;width: 292px;">
						<div style="color: #258900;margin-top: 12px;font-size: 16px;margin-bottom: 5px;">Dettaglio Controparte</div>
                        <ul style="padding:0;line-height:18px">
                             <li>Tipo ID Locale: <b>PF</b></li>
                            <li>Codice Fiscale: <b>---</b></li>
                            <li>Genere: <b>Maschio</b></li>
                            <li>Nazionalità: <b>Italiana</b></li>
                            <li>Cittadinanza: <b>Italiana</b></li>
                            <li>Ruolo: <b>Cliente</b></li>
                            <li>Luogo di nascita: <b>Brescia</b></li>
                            <li>Data di nascita: <b>10/10/1978</b></li>
                            <li>Professione: <b>Impiegato</b></li>
                            <li>SAE: <b>Famiglie Consumatrici</b></li>
                            <li>ATECO: <b>---</b></li>
                        </ul>
                        
						<a><u>Visualizza collegamenti controparte</u></a>

                    </div>
                </div>
				
		</div>
    </div>

        <div style="float:left;">
            <div class="maininfo details">
                <ul>Highlights
                    <li>Ruoli: Cliente</li>
                    <li>Collegato a: Gruppo Ferrero S.p.A. (CDN 1234567)</li>
                </ul>

                <ul>
                    Ultimi aggiornamenti
                    <li>25/04/2016: aggiornamento documento d’identità</li>
                    <li>25/04/2016: compilazione MiFid</li>
                    <li>25/04/2016: censimento delega</li>
                </ul>

                <ul>Ultimi contatti
                    <li>25/04/2016: rinnovato Titoli</li>
                    <li>225/04/2016: proposto nuova assicurazione</li>
                    <li>26/04/2016: invio mail preventivo assicurazione</li>
                </ul>
            </div>

            <div class="latestinsert" style="clear:both;margin:8px 15px;margin-right:0;width:260px;">
                <div class="latestinsert-title" style="width:260px;">Ultime Controparti elaborate</div>
                <ul>
                    <li><i class="fa fa-plug"></i>CC <a href="#" onclick="copy2clipboard(this)">4152677</a> Mario Rossi</li>
                    <li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">52618276</a> Mario Rossi</li>
                    <li><i class="fa fa-plug"></i>CDN <a href="#" onclick="copy2clipboard(this)">5514332</a> Gruppo Siemens</li>
                    <li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">98126</a> Ferrandi srl</li>
                </ul>

            </div>
        </div>



    </div>
</div>

<?php include_once( "include/footer.php"); ?>