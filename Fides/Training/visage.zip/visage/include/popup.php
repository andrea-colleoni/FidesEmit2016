<div id="ManageCustomer">
<form>
    <div class="findbox">
        <div class="TitleBox">Cerca Cliente</div>
        <div class="TextBox">


<table>
<tr>
  <td colspan="2">
<label>
<legend>Azienda</legend>
  <select name="select" class="input">
    <option>1010 Banco di Napoli</option>
    <option>1025 Intesa Sanpaolo S.p.A.</option>
    <option>3059 Banca di Credito Sardo</option>
    <option>3099 Neos Banca</option>
    <option>3110 Farbanca S.p.A.</option>
    <option>3163 State Street Bank</option>
    <option>3239 I.S. Private Banking</option>
    <option>3240 Banca di Trento e Bolzano</option>
    <option>3249 Banca IMI</option>
    <option>3296 Banca Fideuram</option>
    <option>3309 BIIS</option>
    <option>3359 Banca Prossima</option>
    <option>5748 Banca dell'Adriatico</option>
    <option>6010 C.R. Forlì e della Romagna</option>
    <option>6030 Banca C.R Spezia</option>
    <option>6065 C.R. Provincia di Viterbo</option>
  </select>
  </label>
  </td>
  <td>
<label>
<legend>Sportello</legend>
<select class="input">
	<option value="">---</option>
	<option value="A2300">A2300 - Gest. Clienti privat</option>
	<option value="A2400">A2400 - Segm.priv./serv./con</option>
	<option value="A2600">A2600 - Serv.supporto privato</option>
	<option value="A3000">A3000 - Marketing</option>   
	<option value="A3050">A3050 - Coordinamento filiale</option>
	<option value="A3051">A3051 - Crediti</option>       
	<option value="A3310">A3310 - Contenz.e cons.legal</option>
	<option value="A3311">A3311 - Legale</option>        
	<option value="A3320">A3320 - Istruttoria legale</option>
	<option value="A3322">A3322 - Recupero crediti</option>
	<option value="A3330">A3330 - Istruttoria tecnica</option>
	<option value="A4010">A4010 - Special prodotto inv</option>
	<option value="A4015">A4015 - Special prodotto est</option>
	<option value="A4050">A4050 - Prodotto fondiario</option>
	<option value="A4060">A4060 - Prod. crediti specia</option>
	<option value="A4065">A4065 - Funz. commerc. di ar</option>
	<option value="A4066">A4066 - Svil.commerciale</option>
	<option value="A4070">A4070 - Prod. telematici</option>
</select>                                        
</label>
  </td>
  </tr>
  <tr>
  <td colspan="2">
<label>
<legend>Tipo Rapporto</legend>
<input name="CC" type="text" id="CC" class="input CC" value="" />
</label>
  </td>
  <td>
<label>
<legend>Numero Rapporto</legend>
<input name="CC" type="text" id="Rapporto" class="input CC" value="" />
</label>
  </td>  
  </tr>
    <tr>
  <td colspan="2">
<label>
<legend>ID Locale</legend>
<input name="CC" type="text" id="ID Locale" class="input CC" value="" />
</label>
  </td>
  <td>
  </td>  
  </tr>
<tr>
  <td colspan="3"><hr></td>
</tr>
  <tr>
  <td colspan="3">
<label>
<legend>Chiavi</legend>
<input name="CC" type="text" id="Chiavi" class="input chiavi" value=""/>
</label>
  </td>
  </tr>
  <tr>
  <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroup2" checked="checked" onclick="document.getElementById('keyspop1').style.display='block'"></td>
  <td>Chiavi</td>
  <td rowspan="2">
    <select class="input radioselect" id="keyspop1">
		<option value="">Codice Fiscale</option>
		<option value="">Partita IVA</option>
		<option value="">Codice Operatore Estero</option>
	</select>
</td>
  </tr>
  <tr>
  <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroup3" onclick="document.getElementById('keyspop1').style.display='none'"></td>
  <td>CDN</td>
  </tr>
<tr>
  <td colspan="3"><hr></td>
</tr>
</table>
<div style="float:right;">
<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('ManageCustomer','','hide')" type="button"><i class="fa fa-reply"></i> ANNULLA</button>
<button id="conferma1" class="btn btn-app" onclick="MM_showHideLayers('ManageCustomer','','hide'); window.open('customerdetails.php', '_blank')" type="button"><i class="fa fa-floppy-o"></i> CONFERMA</button>
</div>
</div>
    </div></form>
</div>

<div id="ManageLegami">
<form>
    <div class="findbox">
        <div class="TitleBox">Cerca Cliente</div>
        <div class="TextBox">


<table>
<tr>
  <td colspan="2">
<label>
<legend>Azienda</legend>
  <select name="select" class="input">
    <option>1010 Banco di Napoli</option>
    <option>1025 Intesa Sanpaolo S.p.A.</option>
    <option>3059 Banca di Credito Sardo</option>
    <option>3099 Neos Banca</option>
    <option>3110 Farbanca S.p.A.</option>
    <option>3163 State Street Bank</option>
    <option>3239 I.S. Private Banking</option>
    <option>3240 Banca di Trento e Bolzano</option>
    <option>3249 Banca IMI</option>
    <option>3296 Banca Fideuram</option>
    <option>3309 BIIS</option>
    <option>3359 Banca Prossima</option>
    <option>5748 Banca dell'Adriatico</option>
    <option>6010 C.R. Forlì e della Romagna</option>
    <option>6030 Banca C.R Spezia</option>
    <option>6065 C.R. Provincia di Viterbo</option>
  </select>
  </label>
  </td>
  <td>
<label>
<legend>Sportello</legend>
<select class="input">
	<option value="">---</option>
	<option value="A2300">A2300 - Gest. Clienti privat</option>
	<option value="A2400">A2400 - Segm.priv./serv./con</option>
	<option value="A2600">A2600 - Serv.supporto privato</option>
	<option value="A3000">A3000 - Marketing</option>   
	<option value="A3050">A3050 - Coordinamento filiale</option>
	<option value="A3051">A3051 - Crediti</option>       
	<option value="A3310">A3310 - Contenz.e cons.legal</option>
	<option value="A3311">A3311 - Legale</option>        
	<option value="A3320">A3320 - Istruttoria legale</option>
	<option value="A3322">A3322 - Recupero crediti</option>
	<option value="A3330">A3330 - Istruttoria tecnica</option>
	<option value="A4010">A4010 - Special prodotto inv</option>
	<option value="A4015">A4015 - Special prodotto est</option>
	<option value="A4050">A4050 - Prodotto fondiario</option>
	<option value="A4060">A4060 - Prod. crediti specia</option>
	<option value="A4065">A4065 - Funz. commerc. di ar</option>
	<option value="A4066">A4066 - Svil.commerciale</option>
	<option value="A4070">A4070 - Prod. telematici</option>
</select>                                        
</label>
  </td>
  </tr>
  <tr>
  <td colspan="2">
<label>
<legend>Tipo Rapporto</legend>
<input name="CC" type="text" id="CC" class="input CC" value="" />
</label>
  </td>
  <td>
<label>
<legend>Numero Rapporto</legend>
<input name="CC" type="text" id="Rapporto" class="input CC" value="" />
</label>
  </td>  
  </tr>
    <tr>
  <td colspan="2">
<label>
<legend>ID Locale</legend>
<input name="CC" type="text" id="ID Locale" class="input CC" value="" />
</label>
  </td>
  <td>
  </td>  
  </tr>
<tr>
  <td colspan="3"><hr></td>
</tr>
  <tr>
  <td colspan="3">
<label>
<legend>Chiavi</legend>
<input name="CC" type="text" id="Chiavi" class="input chiavi" value=""/>
</label>
  </td>
  </tr>
  <tr>
  <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroup2" checked="checked" onclick="document.getElementById('keyspop2').style.display='block'"></td>
  <td>Chiavi</td>
  <td rowspan="2">
    <select class="input radioselect" id="keyspop2">
		<option value="">Codice Fiscale</option>
		<option value="">Partita IVA</option>
		<option value="">Codice Operatore Estero</option>
	</select>
</td>
  </tr>
  <tr>
  <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroup3" onclick="document.getElementById('keyspop2').style.display='none'"></td>
  <td>CDN</td>
  </tr>
<tr>
  <td colspan="3"><hr></td>
</tr>
</table>
<div style="float:right;">
<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('ManageLegami','','hide')" type="button"><i class="fa fa-reply"></i> ANNULLA</button>
<button id="conferma1" class="btn btn-app" onclick="MM_showHideLayers('ManageLegami','','hide'); window.open('managelegami.php', '_blank');" type="button"><i class="fa fa-floppy-o"></i> CONFERMA</button>
</div>
</div>
    </div></form>
</div>

<div id="ManageContacts">
<form>
    <div class="findbox">
        <div class="TitleBox">Cerca Cliente</div>
        <div class="TextBox">


<table>
<tr>
  <td colspan="2">
<label>
<legend>Azienda</legend>
  <select name="select" class="input">
    <option>1010 Banco di Napoli</option>
    <option>1025 Intesa Sanpaolo S.p.A.</option>
    <option>3059 Banca di Credito Sardo</option>
    <option>3099 Neos Banca</option>
    <option>3110 Farbanca S.p.A.</option>
    <option>3163 State Street Bank</option>
    <option>3239 I.S. Private Banking</option>
    <option>3240 Banca di Trento e Bolzano</option>
    <option>3249 Banca IMI</option>
    <option>3296 Banca Fideuram</option>
    <option>3309 BIIS</option>
    <option>3359 Banca Prossima</option>
    <option>5748 Banca dell'Adriatico</option>
    <option>6010 C.R. Forlì e della Romagna</option>
    <option>6030 Banca C.R Spezia</option>
    <option>6065 C.R. Provincia di Viterbo</option>
  </select>
  </label>
  </td>
  <td>
<label>
<legend>Sportello</legend>
<select class="input">
	<option value="">---</option>
	<option value="A2300">A2300 - Gest. Clienti privat</option>
	<option value="A2400">A2400 - Segm.priv./serv./con</option>
	<option value="A2600">A2600 - Serv.supporto privato</option>
	<option value="A3000">A3000 - Marketing</option>   
	<option value="A3050">A3050 - Coordinamento filiale</option>
	<option value="A3051">A3051 - Crediti</option>       
	<option value="A3310">A3310 - Contenz.e cons.legal</option>
	<option value="A3311">A3311 - Legale</option>        
	<option value="A3320">A3320 - Istruttoria legale</option>
	<option value="A3322">A3322 - Recupero crediti</option>
	<option value="A3330">A3330 - Istruttoria tecnica</option>
	<option value="A4010">A4010 - Special prodotto inv</option>
	<option value="A4015">A4015 - Special prodotto est</option>
	<option value="A4050">A4050 - Prodotto fondiario</option>
	<option value="A4060">A4060 - Prod. crediti specia</option>
	<option value="A4065">A4065 - Funz. commerc. di ar</option>
	<option value="A4066">A4066 - Svil.commerciale</option>
	<option value="A4070">A4070 - Prod. telematici</option>
</select>                                        
</label>
  </td>
  </tr>
  <tr>
  <td colspan="2">
<label>
<legend>Tipo Rapporto</legend>
<input name="CC" type="text" id="CC" class="input CC" value="" />
</label>
  </td>
  <td>
<label>
<legend>Numero Rapporto</legend>
<input name="CC" type="text" id="Rapporto" class="input CC" value="" />
</label>
  </td>  
  </tr>
    <tr>
  <td colspan="2">
<label>
<legend>ID Locale</legend>
<input name="CC" type="text" id="ID Locale" class="input CC" value="" />
</label>
  </td>
  <td>
  </td>  
  </tr>
<tr>
  <td colspan="3"><hr></td>
</tr>
  <tr>
  <td colspan="3">
<label>
<legend>Chiavi</legend>
<input name="CC" type="text" id="Chiavi" class="input chiavi" value=""/>
</label>
  </td>
  </tr>
  <tr>
  <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroup2" checked="checked" onclick="document.getElementById('keyspop3').style.display='block'"></td>
  <td>Chiavi</td>
  <td rowspan="2">
    <select class="input radioselect" id="keyspop3">
		<option value="">Codice Fiscale</option>
		<option value="">Partita IVA</option>
		<option value="">Codice Operatore Estero</option>
	</select>
</td>
  </tr>
  <tr>
  <td class="radiosearch"><input type="radio" name="RadioGroup" value="pulsante di scelta" id="RadioGroup3" onclick="document.getElementById('keyspop3').style.display='none'"></td>
  <td>CDN</td>
  </tr>
<tr>
  <td colspan="3"><hr></td>
</tr>
</table>
<div style="float:right;">
<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('ManageContacts','','hide')" type="button"><i class="fa fa-reply"></i> ANNULLA</button>
<button id="conferma1" class="btn btn-app" onclick="MM_showHideLayers('ManageContacts','','hide'); window.open('managecontacts.php', '_blank');" type="button"><i class="fa fa-floppy-o"></i> CONFERMA</button>
</div>
</div>
    </div></form>
</div>

<div id="ModificaRicerca">
	<div class="box">
		<div class="title">Modifica Ricerca Libera</div>
		<div class="content">						
			<div style="width: 350px;margin-bottom:15px;">
				<div class="selectsearch">
					<div>
						<label>
							<legend>+ PRECISA</legend>
							<input type="checkbox" name="RadioGroup1" value="pulsante di scelta" id="RadioGroup1_0" />
						</label>
					</div>
				</div>
				<div>
					<label>
						<legend>Tipo Cliente</legend>
						<select class="input type">
							<option selected>F - Fisica</option>
							<option>G - Giuridica</option>
							<option>C - Cointestazione</option>
						</select>
					</label>
					<label>
						<legend>Intestazione</legend>
						<input name="Intestazione" type="search" id="Intestazione" class="input intestazione" value="Mario Rossi" />
					</label>
					<label>
						<legend>Data di nascita</legend>
						<input name="giornonascita" type="text" id="giornonascita" class="input date" value="" />
						<input name="mesenascita" type="text" id="mesenascita" class="input date" value=""/>
						<input name="annonascita" type="text" id="annonascita" class="input year" value=""/>
					</label>
					<label>
						<legend>Luogo di nascita</legend>
						<input name="luogonascita" type="text" id="luogonascita" class="input birthplace" value="Brescia" />
					</label>
					<label>
						<legend>CAP</legend>
						<input type="text" class="input cap" value="25125" />
					</label>
					<label>
						<legend>Indirizzo di residenza</legend>
						<input name="residenza" type="search" id="residenza" class="input address" value="Brescia" />
					</label>
					<label>
						<legend>CAP</legend>
						<input type="text" class="input cap" value="25125" />
					</label>
				</div>
				<hr/>
			</div>
			<div style="float:right;">
				<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('ModificaRicerca','','hide')" type="button">
					<i class="fa fa-reply"></i> ANNULLA		
				</button>
				<button id="conferma1" class="btn btn-app" onclick="MM_goToURL('parent','results.php');return document.MM_returnValue" type="button">
					<i class="fa fa-pencil"></i> MODIFICA
				</button>
			</div>
		</div>
	</div>
</div>

<div id="RiepilogoCensimento">
	<div class="box">
	
		<div class="content">						
			<div style="width: 350px; margin-bottom:15px;">
				<h5>Premi Conferma per eseguire l'inserimento dei dati del cliente e/o per accedere alla sua scheda.</h5>
				<hr/>
			</div>
			<div style="float:right;">
				<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('RiepilogoCensimento','','hide')" type="button">
					<i class="fa fa-reply"></i> ANNULLA
						
				</button>
				<button id="conferma1" class="btn btn-app" onclick="if(document.getElementById('tipo_ndg').value=='PF')location.href='customerdetails.php'; else location.href='newcustomerdetails.php';" type="button">
					<i class="fa fa-save"></i> CONFERMA
						
				</button>
			</div>
		</div>
	</div>
</div>

<div id="RiepilogoCensimentoCointestazione">
	<div class="box">
		<div class="content">						
			<div style="width: 350px;margin-bottom:15px;">
				<h5>Premi Conferma per eseguire l'inserimento dei dati della cointestazione e/o per accedere alla sua scheda.</h5>
				<hr/>
			</div>
			<div style="float:right;">
				<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('RiepilogoCensimentoCointestazione','','hide')" type="button">
					<i class="fa fa-reply"></i> ANNULLA
						
				</button>
				<button id="conferma1" class="btn btn-app" onclick="location.href='#';" type="button">
					<i class="fa fa-save"></i> CONFERMA
						
				</button>
			</div>
		</div>
	</div>
</div>

<div id="ConfermaOmonimo">
	<div class="box">
		<div class="title">Conferma Omonimo</div>
		<div class="content">						
			<div style="width: 350px;margin-bottom:15px;">
				<h5>La controparte è già presente in archivio. Se prosegui i suoi dati verranno recuperati e mostrati in pagina.</h5>
				
				<hr/>
			</div>
			<div style="float:right;">
				<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('ConfermaOmonimo','','hide')" type="button">
					<i class="fa fa-reply"></i> ANNULLA
						
				</button>
				<button id="conferma1" class="btn btn-app" onclick="changeStepBlock('dm','da_pf','ccdd_pf',116);MM_showHideLayers('ConfermaOmonimo','','hide')" type="button">
					<i class="fa fa-check"></i> CONFERMA
						
				</button>
			</div>
		</div>
	</div>
</div>

<div id="ConfermaOmonimoCointestazione">
	<div class="box">
		<div class="title">Conferma Cointestazione Esistente</div>
		<div class="content">						
			<div style="width: 350px;margin-bottom:15px;">
				<h5>La cointestazione è già presente in archivio. Se prosegui, i dati verranno recuperati e mostrati in pagina, mantenendo l'ordinamento già esistente.<br/>Nel caso di ordinamento personalizzato, dovrai entrare in <i>Gestisci cointestazione</i></h5>
				
				<hr/>
			</div>
			<div style="float:right;">
				<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('ConfermaOmonimoCointestazione','','hide')" type="button">
					<i class="fa fa-reply"></i> ANNULLA
						
				</button>
				<button id="conferma1" class="btn btn-app" onclick="changeStepBlock('dm','da','ccdd',116);MM_showHideLayers('ConfermaOmonimoCointestazione','','hide')" type="button">
					<i class="fa fa-check"></i> CONFERMA
						
				</button>
			</div>
		</div>
	</div>
</div>

<div id="AssociaContatto">
	<div class="box">
		<div class="title">Associa Contatto</div>
		<div class="content">						
			<div style="width: 485px;margin-bottom:15px;">
				<h5>Seleziona dalla seguente lista un utilizzo e il relativo contatto*:</h5>
				<div class="clearfix">
					<label>
						<legend>Utilizzato per</legend>
						<select style="width:160px">
							<option>---</option>
							<option>Invio SMS</option>
							<option>Urgenze</option>
						</select>
					</label>
					<label style="clear:both">
						<legend>Contatto</legend>
						<select style="width:245px">
							<option>----</option>
							<option>Cellulare Personale | +39 333 598422</option>
						</select>
					</label>
				</div>
				<h6 style="margin-top: 25px;">*Il contatto selezionato sostituirà eventuali altri contatti della stessa categoria</h6>
				<hr/>
			</div>
			<div style="float:right;">
				<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('AssociaContatto','','hide')" type="button">
					<i class="fa fa-reply"></i> ANNULLA
						
				</button>
				<button id="conferma1" class="btn btn-app" onclick="" type="button">
					<i class="fa fa-check"></i> CONFERMA
						
				</button>
			</div>
		</div>
	</div>
</div>

<div id="AggiungiRapporto">
	<div class="box">
		<div class="title">Aggiungi Rapporto</div>
		<div class="content">						
			<div style="width: 410px;margin-bottom:15px;">
				<h5>Seleziona l'utilizzo da associare al rapporto* selezionato:</h5>
				<select style="width:220px;">
					<option>---</option>
					<option>Invio SMS</option>
					<option>Urgenze</option>
				</select>				
				<h6 style="margin-top: 25px;">*Questo utilizzo verrà applicato a tutti i rapporti selezionati</h6>
				<hr>
			</div>
			<div style="float:right;">
				<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('AggiungiRapporto','','hide')" type="button">
					<i class="fa fa-reply"></i> ANNULLA
						
				</button>
				<button id="conferma1" class="btn btn-app" onclick="" type="button">
					<i class="fa fa-check"></i> CONFERMA
						
				</button>
			</div>
		</div>
	</div>
</div>

<div id="AggiungiLegame">
	<div class="box">
		<div class="title">Aggiungi Legame</div>
		<div class="content">						
			<div style="float:left; width: 500px;">
				<div><label style="margin-left:5px; margin-top:15px;">
						<legend>CDN Collegato</legend>
						<input type="text" class="input"></input>
					</label>
					<label style="margin-left:0">
						<legend>Intestazione CDN Collegato</legend>
						<input type="text" class="input" style="width:225px" onclick="this.value='Simone Verdi'"></input>
					</label>
					<label>
						<legend style="cursor:pointer; color:#fff; margin-left: 5px; " onclick="show_ultimi_cdn('ultimi_cdn1')"><u>Ultimi CDN elaborati</u></legend>
					</label>
					<table style="margin:0px 0px 5px 0px">
						<tr id = "ultimi_cdn1" style="display:none;">
						<td style="padding-left:170px">
						<fieldset>
							<legend>CDN: 4152677 Mario Rossi  -  CDN: 5514332 Luca Grilli  -  CDN: 4162523 Paolo Ferrari</legend>
						</fieldset>
						</td>
						</tr>
					</table>
					<label style="float:left;clear:both; margin-left:5px">
						<legend>Codice Collegamento</legend>
						<input name="codcolle" type="text" style="width:400px" class="input"/>
					</label>
					
						
					<label style="margin-left:5px">
						<legend>Specifica di collegamento</legend>
						<input type="text" class="input" style="width:250px"></input>
					</label>
					<label>
						<legend>Quota</legend>
						<input type="text" class="input" style="width:145px" placeholder="%"></input>
					</label>
					<br/>
					<label style="float:left; clear:both; margin-left:5px;">
						<legend>Fonte</legend>
						<input type="text" class="input" style="width:130px"></input>
					</label>
					
					<label style="margin-left:5px;">
						<legend>Data dell'Atto</legend>
						<input type="date" class="input" style="width:130px"></input>
					</label>
					
					<label style="margin-left:0px;">
						<legend>Data Revoca</legend>
						<input type="date" class="input" style="width:130px"></input>
					</label>
					
					<label style="float:left; clear:both; margin-left:5px;">
						<legend>Data Inizio Carica</legend>
						<input type="date" class="input" style="width:197px"></input>
					</label>
					<label style="margin-left:5px">
						<legend>Data Fine Carica</legend>
						<input type="date" class="input" style="width:198px" ></input>
					</label>
						
				</div>
				<hr style="width:500px"/>
			</div>
			
			
			<div style="float:right;clear:both">
				<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('AggiungiLegame','','hide')" type="button">
					<i class="fa fa-reply"></i> ANNULLA		
				</button>
				<button id="conferma1" class="btn btn-app" onclick="MM_goToURL('parent','managelegami.php');return document.MM_returnValue" type="button">
					<i class="fa fa-save"></i> SALVA
				</button>
			</div>
		</div>
	</div>
</div>

<div id="ModificaLegame">
	<div class="box">
		<div class="title">Modifica Legame</div>
		<div class="content">						
						<div style="float:left; width: 500px;">
				<div><label style="margin-left:5px; margin-top:15px;">
						<legend>CDN Collegato</legend>
						<input type="text" class="input" value="56987635"></input>
					</label>
					<label style="margin-left:0">
						<legend>Intestazione CDN Collegato</legend>
						<input type="text" class="input" style="width:225px" value='Gian Franco Villari'"></input>
					</label>
					<label>
						<legend style="cursor:pointer; color:#fff; margin-left: 5px; " onclick="show_ultimi_cdn('ultimi_cdn2')"><u>Ultimi CDN elaborati</u></legend>
					</label>
					<table style="margin:0px 0px 5px 0px">
						<tr id = "ultimi_cdn2" style="display:none;">
						<td style="padding-left:170px">
						<fieldset>
							<legend>CDN: 4152677 Mario Rossi  -  CDN: 5514332 Luca Grilli  -  CDN: 4162523 Paolo Ferrari</legend>
						</fieldset>
						</td>
						</tr>
					</table>
					<label style="float:left;clear:both; margin-left:5px">
						<legend>Codice Collegamento</legend>
						<input name="codcolle" type="text" style="width:400px" class="input" value="SOC - Socio"/>
					</label>
					
						
					<label style="margin-left:5px">
						<legend>Specifica di collegamento</legend>
						<input type="text" class="input" style="width:250px" value="AD - Amministratore Delegato"></input>
					</label>
					<label>
						<legend>Quota</legend>
						<input type="text" class="input" style="width:145px" value="60%"></input>
					</label>
					<br/>
					<label style="float:left; clear:both; margin-left:5px;">
						<legend>Fonte</legend>
						<input type="text" class="input" style="width:130px"></input>
					</label>
					
					<label style="margin-left:5px;">
						<legend>Data dell'Atto</legend>
						<input type="date" class="input" style="width:130px"></input>
					</label>
					
					<label style="margin-left:0px;">
						<legend>Data Revoca</legend>
						<input type="date" class="input" style="width:130px"></input>
					</label>
					
					<label style="float:left; clear:both; margin-left:5px;">
						<legend>Data Inizio Carica</legend>
						<input type="date" class="input" style="width:197px" value="2010-01-01"></input>
					</label>
					<label style="margin-left:5px">
						<legend>Data Fine Carica</legend>
						<input type="date" class="input" style="width:198px" value="2016-01-01"></input>
					</label>
						
				</div>
				<hr style="width:500px"/>
			</div>
			
			
			<div style="float:right;clear:both">
				<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('ModificaLegame','','hide')" type="button">
					<i class="fa fa-reply"></i> ANNULLA		
				</button>
				<button id="conferma1" class="btn btn-app" onclick="MM_goToURL('parent','managelegami.php');return document.MM_returnValue" type="button">
					<i class="fa fa-save"></i> SALVA
				</button>
			</div>
		</div>
	</div>
</div>

<div id="ModificaLegame2">
	<div class="box">
		<div class="title">Modifica Legame</div>
		<div class="content">						
						<div style="float:left; width: 500px;">
				<div><label style="margin-left:5px; margin-top:15px;">
						<legend>CDN Collegato</legend>
						<input type="text" class="input" value="34876194"></input>
					</label>
					<label style="margin-left:0">
						<legend>Intestazione CDN Collegato</legend>
						<input type="text" class="input" style="width:225px" value='Sergio Bruni'"></input>
					</label>
					<label>
						<legend style="cursor:pointer; color:#fff; margin-left: 5px; " onclick="show_ultimi_cdn('ultimi_cdn3')"><u>Ultimi CDN elaborati</u></legend>
					</label>
					<table style="margin:0px 0px 5px 0px">
						<tr id = "ultimi_cdn3" style="display:none;">
						<td style="padding-left:170px">
						<fieldset>
							<legend>CDN: 4152677 Mario Rossi  -  CDN: 5514332 Luca Grilli  -  CDN: 4162523 Paolo Ferrari</legend>
						</fieldset>
						</td>
						</tr>
					</table>
					<label style="float:left;clear:both; margin-left:5px">
						<legend>Codice Collegamento</legend>
						<input name="codcolle" type="text" style="width:400px" class="input" value="SOC - Socio"/>
					</label>
					
					
					<label style="margin-left:5px;">
						<legend>Quota</legend>
						<input type="text" class="input" style="width:145px" value="30%"></input>
					</label>
					<label style="margin-left:0px;">
						<legend>Fonte</legend>
						<input type="text" class="input" style="width:250px"></input>
					</label>
					<br/>
					<label style="margin-left:5px;">
						<legend>Data dell'Atto</legend>
						<input type="date" class="input" style="width:130px"></input>
					</label>
					
					<label style="margin-left:0px;">
						<legend>Data Revoca</legend>
						<input type="date" class="input" style="width:130px"></input>
					</label>
					
					
						
				</div>
				<hr style="width:500px"/>
			</div>
			
			
			<div style="float:right;clear:both">
				<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('ModificaLegame2','','hide')" type="button">
					<i class="fa fa-reply"></i> ANNULLA		
				</button>
				<button id="conferma1" class="btn btn-app" onclick="MM_goToURL('parent','managelegami.php');return document.MM_returnValue" type="button">
					<i class="fa fa-save"></i> SALVA
				</button>
			</div>
		</div>
	</div>
</div>


<div id="RimuoviLegame">
	<div class="box">	
		<div class="title">Rimozione Legame</div>
		<div class="content">						
			<div style="width: 350px; margin-bottom:15px;">
				<h5>Il legame verrà eliminato, sei sicuro di voler continuare?.</h5>
				<hr/>
			</div>
			<div style="float:right;">
				<button id="annulla1" class="btn btn-app" onclick="MM_showHideLayers('RimuoviLegame','','hide')" type="button">
					<i class="fa fa-reply"></i> ANNULLA
						
				</button>
				<button id="conferma1" class="btn btn-app" onclick="MM_showHideLayers('RimuoviLegame','','hide')" type="button">
					<i class="fa fa-save"></i> CONFERMA
						
				</button>
			</div>
		</div>
	</div>
</div>