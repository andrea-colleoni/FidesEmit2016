<!DOCTYPE html>
<html smiling="fake" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	
    <link href="Assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="Assets/css/font-awesome.css" rel="stylesheet">
	<link href="Assets/css/jquery.contextMenu.min.css" rel="stylesheet" />
	
    <link href="Assets/css/other.css" rel="stylesheet" />
    <link href="Assets/css/style.css" rel="stylesheet" />	
	
	<script src="Assets/js/jquery-1.12.4.min.js"></script>
    <script src="Assets/js/jquery-ui.min.js"></script>
	<script src="Assets/js/jquery.contextMenu.min.js"></script>
    <script src="Assets/js/bootstrap.min.js"></script>
	
    <script src="Assets/js/custom-scripts.js"></script>
	
<title>INTESA SANPAOLO - VISAGE</title>
</head>
<body>

	<?php include_once("popup.php"); ?>

    <div id="wrapper">
        
		<?php include_once("navbar.php"); ?>

        <div id="page-wrapper">
            <div id="page-inner">
                


<div class="row">
<div class="breadcrumb">
<i class="fa fa-map-marker"></i><span>Sei in</span> | <a href="#">Titolo</a>
</div>