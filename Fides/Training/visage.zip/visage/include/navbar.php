<nav class="navbar navbar-default top-navbar" role="navigation">
    <div class="mainsize">
        <!-- /970 -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php"><img src="Assets/img/VISAGE.svg" alt="VISAGE" class="logo" />
            </a>
        </div>
        <ul class="nav navbar-top-links navbar-right sidebar-collapse">
            <li>
                <a style="width:110px;font-weight:normal!important;" data-toggle="dropdown" href="#" title="FUNZIONI">
                    <i class="fa fa-th fa-fw"></i> Funzioni<i class="fa fa-caret-down" style="margin-left:6px;"></i>
                </a>
                <ul class="nav nav-second-level thirdmenu collapse in" style="left: -588px;">
                    <li>
                        <div class="searchinput" style="margin-left:620px;margin-top:10px;">
                            <input type="search" placeholder="Cerca Funzione" class="form-control input-sm">
                        </div>
                    </li>
                    <br/>
                    <br/>
                    <li><span><i class="fa fa-user-times"></i><strong>NUOVA CONTROPARTE</strong></span>
                        <div class="sublist">
                            <div class="list"><a href="newcustomer.php" target="_blank">Nuovo Cliente</a>
                            </div>
                            <div class="list"><a href="newcointestazione.php" target="_blank">Nuova Cointestazione</a>
                            </div>
                        </div>
                    </li>
                    <div class="line"></div>
                    <li><span><i class="fa fa-user-times"></i><strong>GESTISCI CONTROPARTE</strong></span>
                        <div class="sublist">
                            <div class="list"><a href="#">Dati anagrafici</a>
                            </div>
                            <div class="list"><a href="#" onclick="MM_showHideLayers('ManageLegami','','show')">Relazioni</a>
                            </div>
                            <div class="list"><a href="#">Chiavi identificative</a>
                            </div>
                            <div class="list"><a href="#" onclick="MM_showHideLayers('ManageContacts','','show')">Gestione contatti</a>
                            </div>
                            <div class="list"><a href="#">Informazioni varie</a>
                            </div>
                            <div class="list"><a href="#">Privacy</a>
                            </div>
                            <div class="list"><a href="#">Documenti e normativa</a>
                            </div>
                        </div>
                    </li>
                    <div class="line"></div>
                    <li><span><i class="fa fa-cubes"></i><strong>RAPPORTI</strong></span>
                        <div class="sublist">
                            <div class="list"><a href="#">Dati</a>
                            </div>
                            <div class="list"><a href="#">Operazioni</a>
                            </div>
                        </div>
                    </li>
                    <div class="line"></div>
                    <li><span><i class="fa fa-share-alt"></i><strong>RELAZIONI</strong></span>
                        <div class="sublist">
                            <div class="list"><a href="#">Censimento</a>
                            </div>
                            <div class="list"><a href="#">Gestione</a>
                            </div>
                        </div>
                    </li>
                    <div class="line"></div>
                    <li><span><i class="fa fa-users"></i><strong>GRUPPI</strong></span>
                        <div class="sublist">
                            <div class="list"><a href="#">Censimento</a>
                            </div>
                            <div class="list"><a href="#">Gestione</a>
                            </div>
                        </div>
                    </li>
                    <div class="line"></div>
                    <li><span><i class="fa fa-flag-checkered"></i><strong>OPERAZIONI SPECIALI</strong></span>
                        <div class="sublist">
                            <div class="list"><a href="#">Variazione tipo ID Locale</a>
                            </div>
                            <div class="list"><a href="#">Estinzione controparte</a>
                            </div>
                            <div class="list"><a href="#">Ripristino controparte</a>
                            </div>
                            <div class="list"><a href="#">Fusione controparte</a>
                            </div>
                            <div class="list"><a href="#">Cumulo</a>
                            </div>
                        </div>
                    </li>
                    <div class="line"></div>
                </ul>
                <!-- /.dropdown-functions -->
            </li>

            <!-- /.dropdown -->
            <li>
                <a href="#" title="NOTIFICHE">
                    <i class="fa fa-bell-o fa-fw"></i>4
                </a>
            </li>
            <!-- /.dropdown -->
            <li>
                <a class="dropdown-toggle" href="#" title="AVVISI">
                    <i class="fa fa-bolt fa-fw"></i>3
                </a>
                <!-- /.dropdown-alerts -->
            </li>
            <!-- /.dropdown -->
            <li>
                <a href="#" title="UTENTE">
                    <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                </a>
                <ul class="dropdown-menu dropdown-user">
                    <li><a href="#"><i class="fa fa-user fa-fw"></i> Profilo Utente</a>
                    </li>
                    <li><a href="#"><i class="fa fa-gear fa-fw"></i> Impostazioni</a>
                    </li>
                    <li><a href="#"><i class="fa fa-globe fa-fw"></i> Lingua (IT)</a>
                    </li>
                    <li class="divider"></li>
                    <li><a href="#"><i class="fa fa-sign-out fa-fw"></i> Esci</a>
                    </li>
                </ul>
                <!-- /.dropdown-user -->
            </li>
            <!-- /.dropdown -->
            <li>
                <a href="#" title="HELP" style="padding:17px 0">
                    <i class="fa fa-question help"></i>
                </a>
            </li>
            <form action="/Culture/SwitchCulture" id="swCultureForm" method="post">
                <input id="currentCultureName" name="currentCultureName" type="hidden">
            </form>
            <script>
                $(document).ready(function() {
                    $('a.culture').click(function(e) {

                        e.preventDefault();

                        $('#currentCultureName').val($(this).attr('class'));
                        $('#swCultureForm').submit(); // post form
                    });
                });
            </script>

        </ul>
        <div class="userinfo">UI061572 <span>|</span> Emidio Caladonato <span>|</span> BCKO (01025 - 02300)</div>
    </div>
    <!-- /970 -->
</nav>