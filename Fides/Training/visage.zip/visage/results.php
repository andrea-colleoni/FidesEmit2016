<?php include_once("include/header.php"); ?>

	<div style="height:50px;">
		<div class="col-md-12" style="position:fixed;background:white;">
			<h1 class="page-header" style="width:970px">RISULTATI RICERCA</h1>
		</div>
	</div>
<div class="appcontainer">

<div style="width:330px; float:left;">
	<div class="filters" style="position: fixed;">
    	<div class="filters-title">Filtri Aggiuntivi</div>
		<div>
			<table>
				<tr>
					<td>Tipo ID Locale</td>
					<td><select name="tipo_id">
						<option value="">---</option>
						<option value="PF">PF - Persona fisica</option>
						<option value="PFBAS">PFBAS - Persona fisica benef.ammin.sost.</option>
						<option value="PFE">PFE - Persona fisica estera</option>
						<option value="PFI">PFI - Persona fisica interdetta</option>
						<option value="PFIE">PFIE - Persona fisica interdetta estera</option>
						<option value="PFINB">PFINB - Persona fisica inabilitata</option>
					</select></td>
				</tr>
				<tr>
					<td>Status</td>
					<td><select name="status">
						<option value="">---</option>
						<option value="10">10 - Blocco indirizzo</option>
						<option value="13">13 - Altro intermedio</option>
						<option value="14">14 - Int. abilitato</option>
						<option value="15">15 - Notizie negative</option>
						<option value="16">16 - Sanction list</option>
						<option value="18">18 - Blocco dof</option>
						<option value="20">20 - Dipendente</option>
						<option value="21">21 - Pensionato</option>
						<option value="24">24 - Soggetti terzi</option>
						<option value="25">25 - Mancanza privacy</option>
						<option value="28">28 - Id Locale spimi-bdn</option>
						<option value="29">29 - Blocco rapporti</option>
						<option value="30">30 - Cf non congruo</option>
						<option value="32">32 - Cf forzato</option>
						<option value="33">33 - Cumulato</option>
					</select></td>
				</tr>
				<tr>
					<td>Filiale</td>
					<td><select name="filiale">
						<option value="">---</option>
						<option value="A2300">A2300 - Gest. Clienti privat</option>
						<option value="A2400">A2400 - Segm.priv./serv./con</option>
						<option value="A2600">A2600 - Serv.supporto privato</option>
						<option value="A3000">A3000 - Marketing</option>   
						<option value="A3050">A3050 - Coordinamento filiale</option>
						<option value="A3051">A3051 - Crediti</option>       
						<option value="A3310">A3310 - Contenz.e cons.legal</option>
						<option value="A3311">A3311 - Legale</option>        
						<option value="A3320">A3320 - Istruttoria legale</option>
						<option value="A3322">A3322 - Recupero crediti</option>
						<option value="A3330">A3330 - Istruttoria tecnica</option>
						<option value="A4010">A4010 - Special prodotto inv</option>
						<option value="A4015">A4015 - Special prodotto est</option>
						<option value="A4050">A4050 - Prodotto fondiario</option>
						<option value="A4060">A4060 - Prod. crediti specia</option>
						<option value="A4065">A4065 - Funz. commerc. di ar</option>
						<option value="A4066">A4066 - Svil.commerciale</option>
						<option value="A4070">A4070 - Prod. telematici</option> 
					</select></td>
				</tr>
				<tr>
					<td>Codici Colleg</td>
					<td><select>
						<option value="">---</option>
						<option value="">ACD - E' inc. nell'accordo di n</option>
						<option value="">AFC - Altra figura collegata</option>
						<option value="">AMC - Amministratore di condomini</option>
						<option value="">AMS - Da ammin.sost.a benef.</option>
						<option value="">BDE - E' banca depositaria di</option>
						<option value="">CSO - Collegato a societa'</option>
						<option value="">CUM - Incorporato da</option>
						<option value="">CUR - Curatore fallimentare</option>
						<option value="">FAL - Fallito</option>
						<option value="">FCM - Filiale casa madre</option>
						<option value="">FES - Fondo estero</option>
						<option value="">FGD - Gestisce</option>
						<option value="">FPP - Fondo pensione</option>
						<option value="">FSG - Istituisce</option>
						<option value="">GCO - Da componente a cointesta</option>
						<option value="">GRE - Da componente a gruppo</option>
						<option value="">LIQ - Liquidatore/curatore</option>
						<option value="">PRC - Procuratore</option>
						<option value="">SAC - Da socio accomandatario a</option>
						<option value="">SOC - Da socio a societa'</option>
						<option value="">ERE - Erede</option>
						<option value="">TIE - Da titolare effettivo a s</option>
						<option value="">TIT - Da titolare a ditta</option>
						<option value="">TUT - Da tutore a tutelato</option>
					</select></td>
				</tr>
				<tr>
					<td>CAP</td>
					<td><span id="label_cap" style="display:block;margin-top:12px;">Comune</span>
						<input type="range" min="1" value="1" max="3" step="1" style="margin-left:30px;width:120px;" oninput="changeLabelCap(this.value,'label_cap')" onchange="changeLabelCap(this.value,'label_cap')" /><br/></td>
				</tr>
			</table>
		</div>
	</div>
	<br/>
</div>

<div style="width:630px; float:left; margin-left:10px;">
	<ul class="results-list">
		<li style="height:110px;padding:0;">
			<div style="position:fixed;background:white;padding:12px 32px; margin-top:-6px;">
				<div class="clearfix">
					<strong style="float:left;">Ricerca Libera (+Precisa)</strong>
					
					<ul style="clear:both;float:left;list-style:none;padding:0;margin:12px 0;width:256px;margin-right:55px;">
						<li>Tipo Controparte: Persona Fisica</li>
						<li>Intestazione: Mario Rossi</li>
						<li>Data di nascita: ---</li>
					</ul>
								
					<ul style="float:left;list-style:none;padding:0;margin:12px 0;width:256px;">
						<li>Luogo di nascita: 25125 - Brescia</li>			
						<li>Comune di residenza: 25125 Brescia BS</li>
					</ul>
					
					<a href="#" style="clear:both;float:left;" onclick="MM_showHideLayers('ModificaRicerca','','show')"><u>Modifica Ricerca</u></a>
				</div>
			</div>
		</li>
		
		<li class="empty">Nessuna corrispondenza trovata</li>
		
		<li class="selectable">
			<div class="clearfix">
				<div style="float:left;width:178px;margin-right:30px;">
					ID Locale: 12365477<br/>
					Tipo: PF
				</div>
				<div style="float:left;width:158px;margin-right:30px;">
					Mario Rossi<br/>
					09/07/1959
				</div>
				<div style="float:left;width:168px;">
					Via Carlo Cattaneo 6<br/>
					25125 Brescia (BS)
				</div>
				<input type="hidden" name="tipo_id" value="PF" />
			</div>
			<div>
			<img style="width:60px;border-radius:8px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/1.jpg" />
				<div style="padding-left:15px;float:left;margin-top:8px;">ID Locale: 12365477   CDN: 12365477<br/><h3 style="margin:0">Mario Rossi</h3>Persona Fisica</div>
								
				<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
					<li>Indirizzo di residenza: Via Carlo Cattaneo 6</li>
					<li>CAP/Comune: 25125 Brescia</li>
					<li>Provincia: Brescia</li>
					<li>Codice Fiscale: MRARSS59G09H871J</li>
					<li>Sesso: M</li>
					<br/>
					<li>C.A.B.: 02000 8</li>
					<li>Sorveglianza: - - -</li>
					
				</ul>
							
				<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
					<li>Luogo di nascita: Brescia</li>
					<li>Data di nascita: 09/07/1959</li>
					<li>Telefono: +39 0307867145</li>
					<li>Cellulare: +39 3334022678</li>
					<li>E-Mail: mario.rossi@gmail.com</li>
					<br/>
					<li>Professione: Impiegato</li>
					<li>Settore: Famiglie Consumatrici</li>
					<li>P.I: - - -</li>					
				</ul>
				<div class="link-box">
					<a href="./customerdetails.php" target="_blank"><u>Mostra tutti i dati della controparte</u></a>
				</div>
			</div>
		</li>
		<li class="selectable">
			<div class="clearfix">
				<div style="float:left;width:178px;margin-right:30px;">
					ID Locale: 88623478<br/>
					Tipo: PF
				</div>
				<div style="float:left;width:158px;margin-right:30px;">
					Mario Rossi<br/>
					10/01/1971
				</div>
				<div style="float:left;width:168px;">
					Via Tito Speri 18A<br/>
					25125 Brescia (BS)
				</div>
				<input type="hidden" name="tipo_id" value="PF" />
			</div>
			<div>
			<img style="width:60px;border-radius:8px;float:left;" src="Assets/img/customers/2.jpg" />
				<div style="padding-left:15px;float:left;margin-top:8px;">ID Locale: 88623478   CDN: 88623478<br/><h3 style="margin:0">Mario Rossi</h3>Persona Fisica</div>
								
				<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
					<li>Indirizzo di residenza: Via Tito Speri 18A</li>
					<li>CAP/Comune: 25125 Brescia</li>
					<li>Provincia: Brescia</li>
					<li>Codice Fiscale: MRARSS71A010H449Q</li>
					<li>Sesso: M</li>
					<br/>
					<li>C.A.B.: 02000 8</li>
					<li>Sorveglianza: - - -</li>
					
				</ul>
							
				<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
					<li>Luogo di nascita: Brescia</li>
					<li>Data di nascita: 10/01/1971</li>
					<li>Telefono: +39 0307867145</li>
					<li>Cellulare: +39 3934022678</li>
					<li>E-Mail: mario.rossi71@gmail.com</li>
					<br/>
					<li>Segmento: Impiegato</li>
					<li>Settore: Famiglie Consumatrici</li>
					<li>P.I: - - -</li>					
				</ul>
				<div class="link-box">
					<a href="./customerdetails.php" target="_blank"><u>Mostra tutti i dati della controparte</u></a>
				</div>
			</div>
		</li>
		<li class="selectable">
			<div class="clearfix">
				<div style="float:left;width:178px;margin-right:30px;">
					ID Locale: 57665478<br/>
					Tipo: PFI
				</div>
				<div style="float:left;width:158px;margin-right:30px;">
					Mario Rossi<br/>
					21/09/1986
				</div>
				<div style="float:left;width:168px;">
					Via Servi di Maria 78A<br/>
					25125 Brescia (BS)
				</div>
				<input type="hidden" name="tipo_id" value="PFI" />
			</div>
			<div>
			<img style="width:60px;border-radius:8px;float:left;" src="Assets/img/customers/3.jpg" />
				<div style="padding-left:15px;float:left;margin-top:8px;">ID Locale: 57665478   CDN: 57665478<br/><h3 style="margin:0">Mario Rossi</h3>Persona Fisica Interdetta</div>
								
				<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
					<li>Indirizzo di residenza: Via Servi di Maria 78A</li>
					<li>CAP/Comune: 25125 Brescia</li>
					<li>Provincia: Brescia</li>
					<li>Codice Fiscale: MRARSS86H09H112M</li>
					<li>Sesso: M</li>
					<br/>
					<li>C.A.B.: 02000 8</li>
					<li>Sorveglianza: - - -</li>
					
				</ul>
							
				<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
					<li>Luogo di nascita: Brescia</li>
					<li>Data di nascita: 21/09/1986</li>
					<li>Telefono: +39 0307867145</li>
					<li>Cellulare: +39 3404022678</li>
					<li>E-Mail: m.rossi4@hotmail.com</li>
					<br/>
					<li>Segmento: Impiegato</li>
					<li>Settore: Famiglie Consumatrici</li>
					<li>P.I: - - -</li>					
				</ul>
				<div class="link-box">
					<a href="./customerdetails.php" target="_blank"><u>Mostra tutti i dati della controparte</u></a>
				</div>
			</div>
		</li>
		<li class="selectable">
			<div class="clearfix">
				<div style="float:left;width:178px;margin-right:30px;">
					ID Locale: 71243561<br/>
					Tipo: PFI
				</div>
				<div style="float:left;width:158px;margin-right:30px;">
					Mario Rossi<br/>
					03/01/1967
				</div>
				<div style="float:left;width:168px;">
					Via Codignole 13<br/>
					25125 Brescia (BS)
				</div>
				<input type="hidden" name="tipo_id" value="PFI" />
			</div>
			<div class="clearfix">
				<img style="width:60px;border-radius:8px;float:left;" src="Assets/img/customers/4.jpg" />
				<div style="padding-left:15px;float:left;margin-top:8px;">ID Locale: 71243561   CDN: 71243561<br/><h3 style="margin:0">Mario Rossi</h3>Persona Fisica Interdetta</div>
								
				<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
					<li>Indirizzo di residenza: Via Codignole 13</li>
					<li>CAP/Comune: 25125 Brescia</li>
					<li>Provincia: Brescia</li>
					<li>Codice Fiscale: MRARSS67A09H324X</li>
					<li>Sesso: M</li>
					<br/>
					<li>C.A.B.: 02000 8</li>
					<li>Sorveglianza: - - -</li>
					
				</ul>
							
				<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
					<li>Luogo di nascita: Brescia</li>
					<li>Data di nascita: 03/01/1967</li>
					<li>Telefono: +39 0307867145</li>
					<li>Cellulare: +39 3394022678</li>
					<li>E-Mail: mario.rossi01@me.com</li>
					<br/>
					<li>Segmento: Impiegato</li>
					<li>Settore: Famiglie Consumatrici</li>
					<li>P.I: - - -</li>					
				</ul>
				<div class="link-box">
					<a href="./customerdetails.php" target="_blank"><u>Mostra tutti i dati della controparte</u></a>
				</div>				
			</div>
		</li>
		<li class="selectable">
			<div class="clearfix">
				<div style="float:left;width:178px;margin-right:30px;">
					ID Locale: 50200612<br/>
					Tipo: PFE
				</div>
				<div style="float:left;width:158px;margin-right:30px;">
					Mario Rossi<br/>
					09/03/1991
				</div>
				<div style="float:left;width:168px;">
					Via Umberto I 27<br/>
					25125 Brescia (BS)
				</div>
				<input type="hidden" name="tipo_id" value="PFE" />
			</div>
			<div>
			<img style="width:60px;border-radius:8px;float:left;" src="Assets/img/customers/5.jpg" />
				<div style="padding-left:15px;float:left;margin-top:8px;">ID Locale: 50200612   CDN: 50200612<br/><h3 style="margin:0">Mario Rossi</h3>Persona Fisica Estera</div>
								
				<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
					<li>Indirizzo di residenza: Via Umberto I 27</li>
					<li>CAP/Comune: 25125 Brescia</li>
					<li>Provincia: Brescia</li>
					<li>Codice Fiscale: MRARSS64C09H765K</li>
					<li>Sesso: M</li>
					<br/>
					<li>C.A.B.: 02000 8</li>
					<li>Sorveglianza: - - -</li>
					
				</ul>
							
				<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
					<li>Luogo di nascita: Brescia</li>
					<li>Data di nascita: 09/03/1991</li>
					<li>Telefono: +39 0307867555</li>
					<li>Cellulare: +39 3354022678</li>
					<li>E-Mail: mariorossi@yahoo.com</li>
					<br/>
					<li>Segmento: Impiegato</li>
					<li>Settore: Famiglie Consumatrici</li>
					<li>P.I: - - -</li>					
				</ul>
				<div class="link-box">
					<a href="./customerdetails.php" target="_blank"><u>Mostra tutti i dati della controparte</u></a>
				</div>
			</div>
		</li>
		<li class="selectable">
			<div class="clearfix">
				<div style="float:left;width:178px;margin-right:30px;">
					ID Locale: 99675413<br/>
					Tipo: PF
				</div>
				<div style="float:left;width:158px;margin-right:30px;">
					Mario Rossi<br/>
					09/03/1990
				</div>
				<div style="float:left;width:168px;">
					Via Paolo Borsellino 7<br/>
					25125 Brescia (BS)
				</div>
				<input type="hidden" name="tipo_id" value="PF" />
			</div>
			<div>
			<img style="width:60px;border-radius:8px;float:left;" src="Assets/img/customers/6.jpg" />
				<div style="padding-left:15px;float:left;margin-top:8px;">ID Locale: 99675413   CDN: 99675413<br/><h3 style="margin:0">Mario Rossi</h3>Persona Fisica Interdetta</div>
								
				<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
					<li>Indirizzo di residenza: Via Paolo Borsellino 7</li>
					<li>CAP/Comune: 25125 Brescia</li>
					<li>Provincia: Brescia</li>
					<li>Codice Fiscale: MRARSS90C09H223Q</li>
					<li>Sesso: M</li>
					<br/>
					<li>C.A.B.: 02000 8</li>
					<li>Sorveglianza: - - -</li>
				</ul>
							
				<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
					<li>Luogo di nascita: Brescia</li>
					<li>Data di nascita: 09/03/1990</li>
					<li>Telefono: +39 0307867145</li>
					<li>Cellulare: +39 3204022678</li>
					<li>E-Mail: mr.mario-rossi@gmail.com</li>
					<br/>
					<li>Segmento: Impiegato</li>
					<li>Settore: Famiglie Consumatrici</li>
					<li>P.I: - - -</li>			
				</ul>
				<div class="link-box">
					<a href="./customerdetails.php" target="_blank"><u>Mostra tutti i dati della controparte</u></a>
				</div>
			</div>
		</li>
	</ul>
</div>

</div>

<?php include_once("include/footer.php"); ?>