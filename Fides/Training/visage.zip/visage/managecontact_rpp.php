<?php include_once("include/header.php"); ?>

    <div style="height:50px;">
		<div class="col-md-12" style="position:fixed;background:white;">
			<h1 class="page-header" style="width:970px">GESTIONE CONTATTI - RAPPORTO</h1>			
		</div>
	</div>
   
<div class="appcontainer">

<div style="width:970px;margin-top:8px;">
			
			<div style="margin-top:2px;float:left;font-size:13px"><i>Rapporto - Mario Rossi</i><br/><h3 style="margin:0">01025 13966 5401 00028288686</h3><div style="font-family:LatoWeb;weight:normal;font-size:12px;margin-top:2px;">CARTA DI DEBITO EMV SETEFI</div></div>
					
				<div class="managecontact rpp">
				
						<legend class="spiegazione">In questa funzione puoi associare ulteriori contatti al rapporto o rimuovere quelli esistenti.</legend>
						
						<table style="margin-bottom:5px;">
							<tr class="header2">
								<td style="width:150px;">Utilizzato per</td>
								<td style="width:180px;">Categoria recapito</td>
								<td>Recapito</td>
								<td></td>
							</tr>
							<tr>
								<td style="vertical-align:top;">Urgenza</td>
								<td>
									<ul class="desc_contatto">
										<li>Telefono - Cellulare Personale</li>
										<li>Mail - Personale 1</li>
									</ul>
								</td>
								<td>
									<ul class="rec_contatto">
										<li>+39 331 4187871</li>
										<li>mario.rossi@gmail.com</li>
									</ul>
								</td>
								<td>
									<ul class="funz_contatto">
										<li><i class="fa fa-times-circle"></i></li>
										<li><i class="fa fa-times-circle"></i></li>
									</ul>
								</td>
							</tr>
							<tr>
								<td style="vertical-align:top;">Corrispondenza</td>
								<td>
									<ul class="desc_contatto">
										<li>Indirizzo</li>
									</ul>
								</td>
								<td>
									<ul class="rec_contatto">
										<li>Via Carlo Cattaneo 6 - 25125 Brescia (BS)</li>
									</ul>
								</td>
								<td>
									<ul class="funz_contatto">
										<li><li>
									</ul>
								</td>
							</tr>		
						</table>
						
						<button style="clear:both;width:138px;margin-top:8px;margin-right:6px;" onclick="MM_showHideLayers('AssociaContatto','','show')"><i class="fa fa-chain"></i> Associa Contatto</button>	
						<button style="margin-top:8px;" onclick="window.history.back();"><i class="fa fa-reply"></i> Annulla</button>									
				</div>
					
				<div style="float:left;margin-top:5px;">
					<div class="maininfo details">
						<ul>Highlights
						<li>Ruoli: Cliente</li>
						<li>Collegato a: Gruppo Ferrero S.p.A. (CDN 1234567)</li>
						</ul>

						<ul>
						  Ultimi aggiornamenti
						  <li>25/04/2016: aggiornamento documento d’identità</li>
						<li>25/04/2016: compilazione MiFid</li>
						<li>25/04/2016: censimento delega</li>
						</ul>

						<ul>Ultimi contatti
						<li>25/04/2016: rinnovato Titoli</li>
						<li>225/04/2016: proposto nuova assicurazione</li>
						<li>26/04/2016: invio mail preventivo assicurazione</li>
						</ul>
					</div>
					
					<div class="latestinsert" style="clear:both;margin:8px 15px;margin-right:0;width:260px;">
						<div class="latestinsert-title" style="width:260px;">Ultime Controparti elaborate</div>
						<ul>
							<li><i class="fa fa-plug"></i>CC <a href="#" onclick="copy2clipboard(this)">4152677</a> Mario Rossi</li>
							<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">52618276</a> Mario Rossi</li>
							<li><i class="fa fa-plug"></i>CDN <a href="#" onclick="copy2clipboard(this)">5514332</a> Gruppo Siemens</li>
							<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">98126</a> Ferrandi srl</li>
						</ul>
					</div>
				</div>
    
</div>

    </div>
	
<?php include_once("include/footer.php"); ?>