<?php include_once("include/header.php"); ?>

    <div style="height:50px;">
		<div class="col-md-12" style="position:fixed;background:white;">
			<h1 class="page-header" style="width:970px">NUOVO CONTATTO - TELEFONO</h1>			
		</div>
	</div>
   
<div class="appcontainer">

<div style="width:970px;margin-top:8px;">

			<img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/1.jpg">
				<div style="padding-left:15px;margin-top:2px;float:left;font-size:13px"><i>Persona Fisica</i><br/><h3 style="margin:0">Mario Rossi</h3><div style="font-family:LatoWeb;weight:normal;font-size:12px;margin-top:2px;">Cod. Azienda: <b>1025</b>  CDN: <b>12365477</b></div></div>
							
				<div class="managecontact tel">
					
					<label>
						<legend>Tipo</legend>
						<select class="input" style="width:120px">
							<option>---</option>
							<option>Abitazione</option>
							<option>Cellulare</option>
							<option>Fax</option>
							<option>Telex</option>
							<option>Ufficio</option>
						</select>
					</label>
					<label>
						<legend>Stato*</legend>
						<select class="input" style="width:104px">
							<option>---</option>
							<option>Attivo</option>
							<option>Non Attivo</option>
						</select>
					</label>
					<label>
						<legend>Certificato*</legend>
						<select class="input" style="width:70px">
							<option>---</option>
							<option>Si</option>
							<option>No</option>
						</select>
					</label>
					
					<label style="clear:both">
						<legend>Prefisso Int.</legend>
						<input type="text" class="input" style="width:58px" value="+39" />
					</label>
					<label>
						<legend>Prefisso Naz.</legend>
						<input type="text" class="input" style="width:60px" />
					</label>
					<label>
						<legend>Numero</legend>
						<input type="text" class="input" style="width:104px" />
					</label>
					<label>
						<legend>Raggiungibile da*</legend>
						<input type="time" class="input" style="width:80px" />
					</label>
					<label>
						<legend>Raggiungibile a*</legend>
						<input type="time" class="input" style="width:80px" />
					</label>
					<label style="clear:both">
						<legend>Consenso utilizzo*</legend>
						<select class="input" style="width:66px">
							<option>---</option>
							<option>Si</option>
							<option>No</option>
						</select>
					</label>
					<label>
						<legend>Data consenso*</legend>
						<input type="date" class="input" style="width:140px" />
					</label>
					<label>
						<legend>Nota*</legend>
						<input type="text" class="input" style="width:195px" />
					</label>
					
					<table style="margin-bottom:5px;">
						<tr class="header2">
							<td></td>
							<td style="width:160px;">Utilizzato per</td>
						</tr>
						<tr>
							<td><input type="checkbox"></td>
							<td>Promozione</td>
						</tr>
						<tr>
							<td><input type="checkbox"></td>
							<td>Residenza</td>
						</tr>		
					</table>
					
					<legend class="spiegazione">Per aggiungere un rapporto al contatto premere salva ed entrare successivamente in gestione.</legend>
					
					<button style="clear:both;margin-top:-14px;" onclick="window.history.back();"><i class="fa fa-save"></i> Salva</button>
					<button style="margin-top:-14px;" onclick="window.history.back();"><i class="fa fa-reply"></i> Annulla</button>
																
				</div>
					
				<div style="float:left;margin-top:5px;">
					<div class="maininfo details">
						<ul>Highlights
						<li>Ruoli: Cliente</li>
						<li>Collegato a: Gruppo Ferrero S.p.A. (CDN 1234567)</li>
						</ul>

						<ul>
						  Ultimi aggiornamenti
						  <li>25/04/2016: aggiornamento documento d’identità</li>
						<li>25/04/2016: compilazione MiFid</li>
						<li>25/04/2016: censimento delega</li>
						</ul>

						<ul>Ultimi contatti
						<li>25/04/2016: rinnovato Titoli</li>
						<li>225/04/2016: proposto nuova assicurazione</li>
						<li>26/04/2016: invio mail preventivo assicurazione</li>
						</ul>
					</div>
					
					<div class="latestinsert" style="clear:both;margin:8px 15px;margin-right:0;width:260px;">
						<div class="latestinsert-title" style="width:260px;">Ultime Controparti elaborate</div>
						<ul>
							<li><i class="fa fa-plug"></i>CC <a href="#" onclick="copy2clipboard(this)">4152677</a> Mario Rossi</li>
							<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">52618276</a> Mario Rossi</li>
							<li><i class="fa fa-plug"></i>CDN <a href="#" onclick="copy2clipboard(this)">5514332</a> Gruppo Siemens</li>
							<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">98126</a> Ferrandi srl</li>
						</ul>
					</div>
				</div>
    
</div>

    </div>
	
<?php include_once("include/footer.php"); ?>