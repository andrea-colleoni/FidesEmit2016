<?php include_once("include/header.php"); ?>

<div style="height:60px;">
	<div class="col-md-12" style="position:fixed;background:white;">
		<h1 class="page-header" style="width:970px;">NUOVA COINTESTAZIONE</h1>
	</div>
</div>
   
<div class="appcontainer">

<div style="width:832px; float:left; margin-left:15px;">
	<div class="stepblock" id="dm">
	   <div class="stepblock-title">1. Inserimento Cointestatari</div>
	   
		<fieldset>
		<legend style="color:black">Inizia il censimento dei cointestatari inserendo tutti i dati qui di seguito. Premi il pulsante per proseguire</legend>
		</fieldset>
		
		<!-- --------- !-->	
		<fieldset style="float:left; clear:both; margin-top:35px">
			<i class="fa fa-chevron-circle-down" style="font-size:15px;cursor:pointer"></i>
		</fieldset>
		<fieldset>
		<legend>CDN Cointestatario *</legend>
		<input type="text" class="input"></input>
		</fieldset>
		<fieldset>
		<legend>Intestazione Cointestatario</legend>
		<input type="text" class="input" onclick="this.value='Simone Verdi'"></input>
		</fieldset>
			
		<div style="float:left;margin-left:15px; margin-top:33px"><i style="cursor:pointer;" class="fa fa-search" onclick="MM_showHideLayers('ManageCustomer','','show')"></i></div>
		
		<legend style="float:left; clear:both; cursor:pointer; color:#000; margin-left:425px; margin-top: -9px;" onclick="show_ultimi_cdn('ultimi_cdn1')"><u>Vedi lista ultimi CDN elaborati</u></legend>
		<table>
		<tr id = "ultimi_cdn1" style="display:none;">
		<td style="padding-left:415px">
		<fieldset>
			<legend>CDN: 4152677 Mario Rossi</legend>
			<legend>CDN: 5514332 Luca Grilli</legend>
			<legend>CDN: 4162523 Paolo Ferrari</legend>
			</fieldset>
		</td>
		</tr>
		</table>
		
		
		
		<!-- --------- !-->
		<div id="addcoint" style="display:none">
		<label style="float:left; clear:both; margin-top:35px; margin-left:12px">
			<i class="fa fa-chevron-circle-up" style="font-size:15px;cursor:pointer"></i>
			<i class="fa fa-chevron-circle-down" style="font-size:15px;cursor:pointer"></i>
			
		</label>
		<label style="float:left; margin-left:12px">
		<legend>CDN Cointestatario *</legend>
		<input type="text" class="input"></input>
		</label>
		<fieldset>
		<legend>Intestazione Cointestatario</legend>
		<input type="text" class="input" onclick="this.value='Simone Verdi'"></input>
		</fieldset>
			
		<div style="float:left;margin-left:15px; margin-top:33px"><i style="cursor:pointer;" class="fa fa-search" onclick="MM_showHideLayers('ManageCustomer','','show')"></i></div>
		
		<legend style="float:left; clear:both; cursor:pointer; color:#000; margin-left:425px; margin-top: -9px;" onclick="show_ultimi_cdn('ultimi_cdn05')"><u>Vedi lista ultimi CDN elaborati</u></legend>
		<table>
		<tr id = "ultimi_cdn05" style="display:none;">
		<td style="padding-left:415px">
		<fieldset>
			<legend>CDN: 4152677 Mario Rossi</legend>
			<legend>CDN: 5514332 Luca Grilli</legend>
			<legend>CDN: 4162523 Paolo Ferrari</legend>
			</fieldset>
		</td>
		</tr>
		</table>
		</div>
		
		<!-- --------- !-->
		<fieldset style="float:left; clear:both; margin-top:35px">
			<i class="fa fa-chevron-circle-up" style="font-size:15px;cursor:pointer"></i>
		</fieldset>
		<fieldset>
		<legend>CDN Cointestatario *</legend>
		<input type="text" class="input"></input>
		</fieldset>
		<fieldset>
		<legend>Intestazione Cointestatario</legend>
		<input type="text" class="input" onclick="this.value='Marco Gialli'; document.getElementById('intautbig').value='Simone Verdi, Marco Gialli'"></input>
		</fieldset>
		
		<div style="float:left;margin-left:15px; margin-top:33px"><i style="cursor:pointer;" class="fa fa-search" onclick="MM_showHideLayers('ManageCustomer','','show')"></i></div>
		
		<legend style="float:left; clear:both; cursor:pointer; color:#000; margin-left:425px; margin-top: -9px;" onclick="show_ultimi_cdn('ultimi_cdn2')"><u>Vedi lista ultimi CDN elaborati</u></legend>
		<table>
		<tr id = "ultimi_cdn2" style="display:none;">
		<td style="padding-left:415px">
		<fieldset>
			<legend>CDN: 4152677 Mario Rossi</legend>
			<legend>CDN: 5514332 Luca Grilli</legend>
			<legend>CDN: 4162523 Paolo Ferrari</legend>
			</fieldset>
		</td>
		</tr>
		</table>
		
		<fieldset>
		  <button id="btn-Save" class="btn btn-add" onclick="document.getElementById('addcoint').style.display='block'" style="float:left;clear:both"><i class="fa fa-plus"></i>Aggiungi Cointestatario</button>
		</fieldset>
		 
		 <fieldset style="float:left; clear:both;">
				<legend>Intestazione</legend>
				<input type="text" id="intautbig" style="width:350px;clear:both;" placeholder="Intestazione Automatica" disabled "/>			  
		</fieldset>
		<div style="float:left; margin-left:20px; clear:both">
				<table style="width:100px"><tr>
						<td class="radio-input"><input type="radio" name="intestazautoman" checked /></td><td class="label">Automatica</td>
						<td class="radio-input"><input type="radio" name="intestazautoman" style="margin-left:30px" /></td><td class="label">Manuale</td>
					  </tr></table>
		</div>
	   <hr/>
	   
	   <legend style="margin-left:22px;">I campi contrassegnati con * sono obbligatori.</legend>
	   
		<div class="buttons-box">
		   <button id="mod" class="btn btn-add mod" style="display:none;" onclick="resetStepBlock2(this, document.getElementById('next'), 'dm','da',116);"><i class="fa fa-gear"></i>MODIFICA</button>
		   <button id="next" class="btn btn-add next" onclick="changeStepBlock3(this, document.getElementById('mod'), 'dm','da',116);"><i class="fa fa-chevron-down"></i>SUCCESSIVA</button>
		</div>
	</div>
	
	<div class="stepblock disabled hidden" id="da">
	   <div class="stepblock-title">2. Dati Aggiuntivi Primo Cointestatario</div>
	   
	   <table>
	   <tr>
		<td colspan="3">
		</td>
		</tr>
			
			<tr>
			
				   <td>
				   <fieldset>
						<legend>XXX</legend>
					  <input type="text" style="width:180px"/>
					  
				   </fieldset>
				   </td>
				   <td>
				   <fieldset>
						<legend>XXX</legend>
					  <input type="text" style="width:180px"/>
					  
				   </fieldset>
				   </td>
				    <td>
				   <fieldset>
						<legend>XXX</legend>
					  <input type="text" style="width:180px" disabled />
					  
				   </fieldset>
				   </td>
				
			</tr>
			</table>

	   <hr />
		<div class="buttons-box">
		   <button id="btn-Save" class="btn btn-add" onclick="MM_showHideLayers('ConfermaOmonimoCointestazione','','show')"><i class="fa fa-chevron-down"></i>SUCCESSIVA</button>
		</div>
	</div>
	
	<div class="stepblock disabled hidden" id="ccdd">
	   <div class="stepblock-title">3. Dati Dinamici</div>
	   
			 <table style="float:left;clear:both">
			    <tr>
			<td colspan="2">
			<fieldset>
				<legend style="color:#000">Prosegui nel censimento con le informazioni principali del primo Cointestatario.<br/>Eventuali aggiunte le potrai fare successivamente.</legend>
			</fieldset>
			</td>
			</tr>
			<tr>
				<td>
				   <fieldset>
					  <legend>Toponimo</legend>
					  <select style="width:180px">
						 <option value="">Via</option>
						 <option value="">Piazza</option>
						 <option value="">Vicolo</option>
					  </select>
				   </fieldset>
				</td>
				<td>
				   <fieldset>
					  <legend>Via/Piazza/Vicolo *</legend>		
					  <input type="text" style="width:150px" value="Carlo Cattaneo"/>
				   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
				   <fieldset>
					  <legend>Num Civico *</legend>		
					  <input type="text" style="width:50px" value="6">
				   </fieldset>
				</td>
				<td>
				<fieldset>
				  <legend>Presso</legend>		
				  <input type="text" style="width:150px">
			   </fieldset>
				</td>
			</tr>
			<tr>
			
				<td>
				<fieldset>
				  <legend>Comune *</legend>
				   <input type="text" style="width:180px" value="Brescia">
			   </fieldset>
				</td>
					<td>
			   <fieldset>
				  <legend>CAP *</legend>
				   <input type="text" style="width:150px" value="25125">
			   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
			   <fieldset>
				  <legend>Provincia *</legend>
				   <input type="text" style="width:180px" value="Brescia">
			   </fieldset>
				</td>
			
				<td>
			   <fieldset>
				  <legend>Nazione *</legend>
				   <input type="text" style="width:150px" value="Italia">
			   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
					<fieldset>
					<table style="float:left;clear:both">
					<tr>
					<td>
					<legend>Forzato</legend>
					</td>
					<td>
					<input style ="margin-top: 13px; margin-left: 5px;"type="checkbox" name="check_f" value="f" />
					</td>
					</tr>
					</table>
					</fieldset>
				</td>
				<td>
					<fieldset>
					<legend>Approssimato  <i class="fa fa-times"></i></legend>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td>
				<fieldset>
				  <legend>Prefisso Int.</legend>
				   <input type="text" style="width:80px" value="+39">
			   </fieldset>
			   <fieldset>
				  <legend>Prefisso Naz.</legend>
				   <input type="text" style="width:80px" value="030">
			   </fieldset>
			   </td>
			   <td>
			   <fieldset>
				  <legend>Numero Principale</legend>
				   <input type="text" style="width:150px" value="7867145">
			   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
			   <fieldset>
				  <legend>E-Mail Principale</legend>
				   <input type="text" style="width:180px" value="mario.rossi@gmail.com">
			   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
					<fieldset>
					  <legend>Tipo Account Principale</legend>
					   <select style="width:180px">
						 <option value="">---</option>
						 <option value="">Facebook</option>
						 <option value="" selected>Twitter</option>
						 <option value="">LinkedIn</option>
						 <option value="">Skype</option>
					  </select>
				   </fieldset>
				</td>
				<td>
			   <fieldset>
				  <legend>Social ID</legend>
				   <input type="text" style="width:150px" value="@mariorossi">
			   </fieldset>
				</td>
			</tr>
			
		</table>
			   
		<div class="searchinput" style="margin-right:43px;">
		<input type="search" placeholder="Cerca Indirizzo" style="width:350px;margin-top:54px; border-radius:5px; color: #000; background-color: #ffffff; background-position: 316px 4px; background-image: url(./Assets/img/IcoSearchBlack.svg);"></input>
		</div>
	   <img style="float:left;margin-left:45px; margin-top:2px; border-radius:5px;"
		  width="350"
		  height="320"
		  frameborder="0" style="border:0"
		  src="Assets/img/maps/map_viaCarloCattaneo.png">
		</img>
		
		<hr/>
		
		<table style="float:left; clear:both;">
	
			<tr>
				<td>
				   <fieldset>
					  <legend>SAE *</legend>
					  <select style="width:300px">
						 <option value="">---</option>
						  <option value="">276 - Old-Agenti di Cambio</option>
						   <option value="">280 - Mediatori/Agenti e Consul.assic</option>
						    <option value="">284 - Altri Ausiliari Finanziari</option>
							<option value="" selected>600 - Famiglie Consumatrici</option>
							 <option value="">615 - Altre Famiglie Produttrici</option>
					  </select>
				   </fieldset>
				</td>
			
				<td>
				   <fieldset>
					  <legend>ATECO *</legend>
					  <select style="width:300px">
						 <option value="">---</option>
						 <option value="">01 - Coltivazioni Agricole e Produzione</option>
						 <option value="">0111 - Coltivazione di Colture Agricole</option>
						 <option value="">01112 - Coltivazione di Semi Oleosi</option>
						 <option value="">01112 - Coltivazioni Miste di Cereali</option>
						 <option value="">01120 - Coltivazione di Riso</option>
						 <option value="">011310 - Coltiv. Ortaggi in Piena Aria</option>
					  </select>
				   </fieldset>
				</td>
			</tr>
			<tr>
				<td>
				   <fieldset>
					  <legend>Professione *</legend>
					  <select style="width:300px">
						<option value="">---</option>
						<option value="">Studente</option>
						<option value="">Pensionato</option>
						<option value="">Casalinga</option>
						<option value="">Redditiero</option>
						<option value="">Disoccupato</option>
						<option value="">Insegnante Scuola Privata/Pubb</option>
						<option value="">Operaio o Assimilato</option>
						<option value="" selected>Impiegato</option>
						<option value="">Funzionario/Quadro</option>
						<option value="">Magistrato</option>
						<option value="">Militare o Forze Armate</option>
						<option value="">Agente di Commercio</option>
						<option value="">Sport e Spettacolo</option>
						<option value="">Coltiv. Diretti/Imprend. Agric</option>
						<option value="">Medico</option>
						<option value="">Avvocato e Procuratore Legale</option>
					  </select>
				   </fieldset>
				</td>
			</tr>
		</table>
		
		<legend style="margin-left:22px;">I campi contrassegnati con * sono obbligatori.</legend>
			<hr/>
			 
		
	
	   <strong>Normativa Privacy</strong>
	   
	   <table style="float:left;clear:both;width:320px;margin-left:20px;">
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Erogazione di servizi bancari e finanziari</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso1" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso1"/></td><td class="label">Nego il consenso</td>
			<td class="label">Data  </td><td><input type="date" class="input"/></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Indagini di mercato e offerta prodotti finanziari</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso2" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso2" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Offerta prodotti gruppo in base al profilo personale    </td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso3" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso3" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Indagini di mercato e offerta prodotti di terzi</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso4" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso4" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		<tr>
			<td colspan="4" class="label" style="color:black; font-family:arial; font-size:13px">Dati sensibili</td>
		</tr>
		<tr>
			<td class="radio-input"><input type="radio" name="consenso5" /></td><td class="label">Do il consenso</label></td>
			<td class="radio-input"><input type="radio" name="consenso5" /></td><td class="label">Nego il consenso</td>
			<td class="label">Data</td><td><input type="date" class="input" /></td>
		</tr>
		</table>
	   
	 
	   <hr/>
	   <div style="float:left; clear:both;">
	   <table style="float:left; clear:both;">
	   <tr>
	   <td>
		<fieldset>
         <legend>Tipo Intermediario</legend>
         <select style="width:250px">
          <option value="">---</option>
		  <option value="">08 - Angente di Cambio</option>
		  <option value="">10 - Int. Finanz. Art.107</option>
		  <option value="">11 - Int. Finanz. Art.106</option>  
		  <option value="">12 - Succ. Ital. Sogg.1-11</option>  
		  <option value="">15 - Confidi</option>
		  <option value="">16 - Cambiavalute</option> 
		  <option value="">19 - Int.Assic.Art.109/2</option> 
		  <option value="">20 - Mediatori Creditizi</option>
		  <option value="">21 - Agenti Attiv. Finanz.</option> 
		  <option value="">28 - Succ. Ital. Sogg. 23-26</option>
		  <option value="">29 - Istituti Pagamento</option>
		  <option value="">30 - Money Transfer</option>
		  <option value="">32 - Compro Oro</option>
		  <option value="">33 - Fondi Pubblici/Appalti</option>
		  <option value="">35 - Operat. in Giochi e Scommesse</option>
		  <option value="" selected>36 - Iranian Subject Approvati</option>
		  <option value="">37 - Imp. Operante Sett. Armamenti</option>
         </select>
        </fieldset>
		</td>
		<td>
		<fieldset>
			<legend>Interesse DOF</legend>
         <select style="width:250px">
          <option value="">---</option>
		  <option value="">S</option>
         </select>
		 </fieldset>
		 </td>
		 </tr>
		 <tr>
		 <td>
				   <fieldset>
						<legend>Residenza Fiscale</legend>
					  <input type="text"  style="width:180px" disabled />
					  
				   </fieldset>
				   </td>
				   <td>
				   <fieldset>
						<legend>International Tax Code (TIN)/NIF</legend>
					  <input type="text"  style="width:180px" disabled />
					  
				   </fieldset>
				   </td>
				    <td>
				   <fieldset>
						<legend>GIIN</legend>
					  <input type="text"  style="width:180px" disabled />
					  
				   </fieldset>
				   </td>
		 </tr>
        </table>
	   </div>
		<div class="buttons-box">
		   <button style="margin-top:22px" id="btn-Save" class="btn btn-add" onclick="MM_showHideLayers('RiepilogoCensimentoCointestazione','','show')"><i class="fa fa-chevron-right"></i>Prosegui</button>
		</div>
	</div>
	
</div>
<div style="width:65px; float:left;">
	<ul class="section-list clearfix">
		<li id="dm_tab" class="active" style="font-family:'LatoWeb';font-size:12px" onclick="scrollPage('dm',116)">1. Inserimento Cointestatari</li>
		<li id="da_tab" class="disabled" style="font-family:'LatoWeb';font-size:12px" onclick="scrollPage('da',116)">2. Dati Aggiuntivi Primo Cointestatario</li>
		<li id="ccdd_tab" class="disabled" style="font-family:'LatoWeb';font-size:12px" onclick="scrollPage('ccdd',116)">3. Dati Dinamici</li>
	</ul>
	<br/>
</div>

<?php include_once("include/footer.php"); ?>