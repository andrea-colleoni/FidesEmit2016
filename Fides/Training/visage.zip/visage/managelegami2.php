<?php include_once("include/header.php"); ?>

    <div style="height:50px;">
		<div class="col-md-12" style="position:fixed;background:white;">
			<h1 class="page-header" style="width:970px">GESTIONE LEGAMI <button class="btn ricercasemplice" onclick="MM_showHideLayers('ManageLegami','','show')"><i class="fa fa-bullseye"></i> Ricerca Semplice</button></h1>			
		</div>
	</div>
   
<div class="appcontainer">

<div style="width:970px;margin-top:8px;">
			<img style="margin-left: 0px; width:70px; border-radius:5px;float:left;user-select:none;-moz-user-select:none;-webkit-user-select:none;" src="Assets/img/customers/2.jpg">
				<div style="padding-left:15px;margin-top:2px;float:left;font-size:13px"><i>Persona Fisica</i><br/><h3 style="margin:0">Giovanni Bianchi</h3><div style="font-family:LatoWeb;weight:normal;font-size:12px;margin-top:2px;">Cod. Azienda: <b>1025</b>  CDN: <b>56987635</b></div></div>
				
				<button class="btn newlegame" style="margin-right:280px;margin-top:40px" onclick="MM_showHideLayers('AggiungiLegame','','show')"><i class="fa fa-plus-circle"></i> Aggiungi Legame</button>
				
				<div class="managelegami">
			
					<h2>Collegati alla controparte</h2>
					<ul class="legami-list">
						
						<li>
							<div class="sd clearfix">
								<div style="float:left;width:178px;margin-right:30px;">
									CDN Collegato: 12365477
								</div>
								<div style="float:left;width:158px;margin-right:30px;">
									Mario Rossi
								</div>
								<div style="float:left;width:168px;">
									CODICE COLLEGAMENTO
								</div>
								<input type="hidden" name="tipo_id" value="PF" />
							</div>
							
							<div class="ld">
								<button class="btn controparte" style="width:36px;height:36px!important;" onclick="switchLegamiDetail(this)" title="Visualizza Dettaglio Controparte"><i class="fa fa-user"></i></button>
								<div style="float:left;margin-top:8px;">CDN Collegato: 12365477<br/><h3 style="margin:0">Mario Rossi</h3>CODICE COLLEGAMENTO</div>
												
								<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
									<li>Specifica di collegamento: ---</li>
									<li>Quota di partecipazione: 30000€</li>
									<li>Nota: --- ---</li>									
								</ul>
											
								<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
									<li>Tipo collegamento: ---</li>
									<li>Data inizio: 12/10/2016</li>
									<li>Data fine: 19/10/2016</li>								
								</ul>
																
								<button class="btn" style="clear:both;width:138px;margin-top:20px;height:26px!important;" onclick="MM_showHideLayers('ModificaLegame3','','show')"><i style="display:inline-block!important" class="fa fa-gear"></i> MODIFICA LEGAME</button>
								<button class="btn" style="width:138px;margin-right:8px;margin-top:20px;height:26px!important;" onclick="MM_showHideLayers('RimuoviLegame','','show')"><i style="display:inline-block!important" class="fa fa-trash"></i> RIMUOVI LEGAME</button>
								
							</div>
							
							<div class="cd">
								<button class="btn legame" style="width:36px;height:36px!important;" title="Visualizza Dettaglio Legame" onclick="switchLegamiDetail(this)"><i class="fa fa-chain"></i></button>
								<div style="float:left;margin-top:8px;">CDN Collegato: 12365477<br/><h3 style="margin:0">Mario Rossi</h3>CODICE COLLEGAMENTO</div>
												
								<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
									<li>Tipo ID Locale: PF</li>
									<li>Codice Fiscale: ---</li>
									<li>Genere: Maschio</li>
									<li>Nazionalità: Italiana</li>
									<li>Cittadinanza: Italiana</li>
									<li>Ruolo: ---</li>
									
									
								</ul>
											
								<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
									<li>Luogo di nascita: Brescia</li>
									<li>Data di nascita: 09/07/1959</li>
									<li>Professione: Impiegato</li>
									<li>SAE: Famiglie Consumatrici</li>
									<li>ATECO: ---</li>
									
									
								</ul>
								<div class="link-box">
									<a href="./managelegami.php"><u>Visualizza collegamenti controparte</u></a>
								</div>
							</div>
						</li>
						
						<li>
							<div class="sd clearfix">
								<div style="float:left;width:178px;margin-right:30px;">
									CDN Collegato: 43816579
								</div>
								<div style="float:left;width:158px;margin-right:30px;">
									Luca Grilli
								</div>
								<div style="float:left;width:168px;">
									CODICE COLLEGAMENTO
								</div>
								<input type="hidden" name="tipo_id" value="PF" />
							</div>
							
							<div class="ld">
								<button class="btn controparte" style="width:36px;height:36px!important;" title="Visualizza Dettaglio Controparte" onclick="switchLegamiDetail(this)"><i class="fa fa-user"></i></button>
								<div style="float:left;margin-top:8px;">CDN Collegato: 43816579<br/><h3 style="margin:0">Luca Grilli</h3>CODICE COLLEGAMENTO</div>
												
								<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
									<li>Specifica di collegamento: ---</li>
									<li>Quota di partecipazione: 10000€</li>
									<li>Nota: --- ---</li>									
								</ul>
											
								<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
									<li>Tipo collegamento: ---</li>
									<li>Data inizio: 30/09/2016</li>
									<li>Data fine: 02/10/2016</li>								
								</ul>
																
								<button class="btn" style="clear:both;width:138px;margin-top:20px;height:26px!important;" onclick="MM_showHideLayers('ModificaLegame4','','show')"><i style="display:inline-block!important" class="fa fa-gear"></i> MODIFICA LEGAME</button>
								<button class="btn" style="width:138px;margin-right:8px;margin-top:20px;height:26px!important;" onclick="MM_showHideLayers('RimuoviLegame','','show')"><i style="display:inline-block!important" class="fa fa-trash"></i> RIMUOVI LEGAME</button>
								
							</div>
							
							<div class="cd">
							<button class="btn legame" style="width:36px;height:36px!important;" title="Visualizza Dettaglio Legame" onclick="switchLegamiDetail(this)"><i class="fa fa-chain"></i></button>
								<div style="float:left;margin-top:8px;">CDN Collegato: 43816579<br/><h3 style="margin:0">Luca Grilli</h3>CODICE COLLEGAMENTO</div>
												
								<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
									<li>Tipo ID Locale: PF</li>
									<li>Codice Fiscale: ---</li>
									<li>Genere: Maschio</li>
									<li>Nazionalità: Italiana</li>
									<li>Cittadinanza: Italiana</li>
									<li>Ruolo: ---</li>
									
									
								</ul>
											
								<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
									<li>Luogo di nascita: Brescia</li>
									<li>Data di nascita: 09/07/1959</li>
									<li>Professione: Impiegato</li>
									<li>SAE: Famiglie Consumatrici</li>
									<li>ATECO: ---</li>
									
									
								</ul>
								<div class="link-box">
									<a><u>Visualizza collegamenti controparte</u></a>
								</div>
							</div>
						</li>
						
					</ul>	
					<hr style="border-color: #ccc;"/>
					<h2>Controparte collegata a</h2>
					<ul class="legami-list">
						
						<li>
							<div class="sd clearfix">
								<div style="float:left;width:178px;margin-right:30px;">
									CDN Collegato: 12365477
								</div>
								<div style="float:left;width:158px;margin-right:30px;">
									Mario Rossi
								</div>
								<div style="float:left;width:168px;">
									CODICE COLLEGAMENTO
								</div>
								<input type="hidden" name="tipo_id" value="PF" />
							</div>
							
							<div class="ld">
								<button class="btn controparte" style="width:36px;height:36px!important;" onclick="switchLegamiDetail(this)" title="Visualizza Dettaglio Controparte"><i class="fa fa-user"></i></button>
								<div style="float:left;margin-top:8px;">CDN Collegato: 12365477<br/><h3 style="margin:0">Mario Rossi</h3>CODICE COLLEGAMENTO</div>
												
								<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
									<li>Specifica di collegamento: ---</li>
									<li>Quota di partecipazione: 30000€</li>
									<li>Nota: --- ---</li>									
								</ul>
											
								<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
									<li>Tipo collegamento: ---</li>
									<li>Data inizio: 12/10/2016</li>
									<li>Data fine: 19/10/2016</li>								
								</ul>
																
								<button class="btn" style="clear:both;width:138px;margin-top:20px;height:26px!important;" onclick="MM_showHideLayers('ModificaLegame3','','show')"><i style="display:inline-block!important" class="fa fa-gear"></i> MODIFICA LEGAME</button>
								<button class="btn" style="width:138px;margin-right:8px;margin-top:20px;height:26px!important;" onclick="MM_showHideLayers('RimuoviLegame','','show')"><i style="display:inline-block!important" class="fa fa-trash"></i> RIMUOVI LEGAME</button>
								
							</div>
							
							<div class="cd">
								<button class="btn legame" style="width:36px;height:36px!important;" title="Visualizza Dettaglio Legame" onclick="switchLegamiDetail(this)"><i class="fa fa-chain"></i></button>
								<div style="float:left;margin-top:8px;">CDN Collegato: 12365477<br/><h3 style="margin:0">Mario Rossi</h3>CODICE COLLEGAMENTO</div>
												
								<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
									<li>Tipo ID Locale: PF</li>
									<li>Codice Fiscale: ---</li>
									<li>Genere: Maschio</li>
									<li>Nazionalità: Italiana</li>
									<li>Cittadinanza: Italiana</li>
									<li>Ruolo: ---</li>
									
									
								</ul>
											
								<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
									<li>Luogo di nascita: Brescia</li>
									<li>Data di nascita: 09/07/1959</li>
									<li>Professione: Impiegato</li>
									<li>SAE: Famiglie Consumatrici</li>
									<li>ATECO: ---</li>
									
									
								</ul>
								<div class="link-box">
									<a href="./managelegami.php"><u>Visualizza collegamenti controparte</u></a>
								</div>
							</div>
						</li>
						
						<li>
							<div class="sd clearfix">
								<div style="float:left;width:178px;margin-right:30px;">
									CDN Collegato: 43816579
								</div>
								<div style="float:left;width:158px;margin-right:30px;">
									Luca Grilli
								</div>
								<div style="float:left;width:168px;">
									CODICE COLLEGAMENTO
								</div>
								<input type="hidden" name="tipo_id" value="PF" />
							</div>
							
							<div class="ld">
								<button class="btn controparte" style="width:36px;height:36px!important;" title="Visualizza Dettaglio Controparte" onclick="switchLegamiDetail(this)"><i class="fa fa-user"></i></button>
								<div style="float:left;margin-top:8px;">CDN Collegato: 43816579<br/><h3 style="margin:0">Luca Grilli</h3>CODICE COLLEGAMENTO</div>
												
								<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
									<li>Specifica di collegamento: ---</li>
									<li>Quota di partecipazione: 10000€</li>
									<li>Nota: --- ---</li>									
								</ul>
											
								<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
									<li>Tipo collegamento: ---</li>
									<li>Data inizio: 30/09/2016</li>
									<li>Data fine: 02/10/2016</li>								
								</ul>
																
								<button class="btn" style="clear:both;width:138px;margin-top:20px;height:26px!important;" onclick="MM_showHideLayers('ModificaLegame4','','show')"><i style="display:inline-block!important" class="fa fa-gear"></i> MODIFICA LEGAME</button>
								<button class="btn" style="width:138px;margin-right:8px;margin-top:20px;height:26px!important;" onclick="MM_showHideLayers('RimuoviLegame','','show')"><i style="display:inline-block!important" class="fa fa-trash"></i> RIMUOVI LEGAME</button>
								
							</div>
							
							<div class="cd">
							<button class="btn legame" style="width:36px;height:36px!important;" title="Visualizza Dettaglio Legame" onclick="switchLegamiDetail(this)"><i class="fa fa-chain"></i></button>
								<div style="float:left;margin-top:8px;">CDN Collegato: 43816579<br/><h3 style="margin:0">Luca Grilli</h3>CODICE COLLEGAMENTO</div>
												
								<ul style="clear:both;float:left;list-style:none;padding:0;margin-top:12px;width:256px;margin-right:55px;">
									<li>Tipo ID Locale: PF</li>
									<li>Codice Fiscale: ---</li>
									<li>Genere: Maschio</li>
									<li>Nazionalità: Italiana</li>
									<li>Cittadinanza: Italiana</li>
									<li>Ruolo: ---</li>
									
									
								</ul>
											
								<ul style="float:left;list-style:none;padding:0;margin-top:12px;width:256px;">
									<li>Luogo di nascita: Brescia</li>
									<li>Data di nascita: 09/07/1959</li>
									<li>Professione: Impiegato</li>
									<li>SAE: Famiglie Consumatrici</li>
									<li>ATECO: ---</li>
									
									
								</ul>
								<div class="link-box">
									<a><u>Visualizza collegamenti controparte</u></a>
								</div>
							</div>
						</li>
						
					</ul>	
				</div>
				
				<div style="float:left;">
					<div class="maininfo details">
						<ul>Highlights
						<li>Ruoli: Cliente</li>
						<li>Collegato a: Gruppo Ferrero S.p.A. (CDN 1234567)</li>
						</ul>

						<ul>
						  Ultimi aggiornamenti
						  <li>25/04/2016: aggiornamento documento d’identità</li>
						<li>25/04/2016: compilazione MiFid</li>
						<li>25/04/2016: censimento delega</li>
						</ul>

						<ul>Ultimi contatti
						<li>25/04/2016: rinnovato Titoli</li>
						<li>225/04/2016: proposto nuova assicurazione</li>
						<li>26/04/2016: invio mail preventivo assicurazione</li>
						</ul>
					</div>
					
					<div class="latestinsert" style="clear:both;margin:8px 15px;margin-right:0;width:260px;">
						<div class="latestinsert-title" style="width:260px;">Ultime Controparti elaborate</div>
						<ul>
							<li><i class="fa fa-plug"></i>CC <a href="#" onclick="copy2clipboard(this)">4152677</a> Mario Rossi</li>
							<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">52618276</a> Mario Rossi</li>
							<li><i class="fa fa-plug"></i>CDN <a href="#" onclick="copy2clipboard(this)">5514332</a> Gruppo Siemens</li>
							<li><i class="fa fa-plug"></i>ID Locale <a href="#" onclick="copy2clipboard(this)">98126</a> Ferrandi srl</li>
						</ul>
						
						
						
						
					</div>
				</div>
    
</div>

    </div>
	
<?php include_once("include/footer.php"); ?>