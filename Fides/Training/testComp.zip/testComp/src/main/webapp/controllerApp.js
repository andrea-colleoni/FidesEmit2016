angular
	.module('app', [])
  .component('parentComponent', {
  	transclude: true,
    template: '<div ng-transclude></div>',
  	controller: function () {
    	
      this.regioni = [ 
                      {
                          nome: 'Sicilia'
                      },
                      {
                          nome: 'Campania'
                      },
                      {
                          nome: 'Lombardia'
                  }];
      
      this.provinceSicilia = [
  	            			{name: 'Agrigento'},
  	            			{name: 'Caltanissetta'},
  	            			{name: 'Catania'},
  	            			{name: 'Enna'},
  	            			{name: 'Messina'},
  	            			{name: 'Palermo'},
  	            			{name: 'Ragusa'},
  	            			{name: 'Siracusa'},
  	            			{name: 'Trapani'}
  	            		];
  	            		
  	            		this.provinceLombardia = [
  	            			{name: 'Bergamo'},
  	            			{name: 'Brescia'},
  	            			{name: 'Como'},
  	            			{name: 'Cremona'},
  	            			{name: 'Lecco'},
  	            			{name: 'Lodi'},
  	            			{name: 'Mantova'},
  	            			{name: 'Milano'},
  	            			{name: 'Monza'},
  	            			{name: 'Pavia'},
  	            			{name: 'Sondrio'},
  	            			{name: 'Varese'}		
  	            		];
  	            		
  	            		this.provinceCampania = [
  	            			{name: 'Avellino'},
  	            			{name: 'Benevento'},
  	            			{name: 'Caserta'},
  	            			{name: 'Napoli'},
  	            			{name: 'Salerno'}		
  	            		];
  	            		this.provSic = function () {
  	                    	return (this.provinceSicilia);
  	                    };
  	                    this.provLom = function () {
  	                    	return (this.provinceLombardia);
  	                    };
  	                    this.provCam = function () {
  	                    	return (this.provinceCampania);
  	                    };
      this.foo = function () {
        	return (this.regioni);
        };
    }
  })
	.component('childComponent', {
		
	
    require: {
      parent: '^parentComponent'
    },
    controller: function () {
    	
      this.$onInit = function () {
      	this.state = this.parent.foo();
      };
    },
    template: [
"<form novalidate>",
"<fieldset>",
"<label> Seleziona una regione: </label>",
"<hr>",
'<div ng-repeat="regione in $ctrl.state">',
'<label><input type="radio" ng-model="$ctrl.myReg" name="regione" value="{{regione.nome}} " >{{regione.nome}}</label><br>',
'</div>',
"<p>{{$ctrl.myReg}}</p>",
"</fieldset>",
"</form>"
    ].join('')
  })
  
.component('superChildComponent', {
    require: {
      parent: '^parentComponent'
    },
    controller: function () {
      this.$onInit = function () {
      	this.provs = this.parent.provSic();
      	this.state = this.parent.foo();
      };
      
    },
    template: ['<h2>Elenco Province</h2>',
    	'<div ng-switch="$ctrl.state">',
//   	'<div ng-switch-when="Sicilia">',
    	'<ul><li ng-repeat="provincia in $ctrl.provs">{{ provincia.name}}</li></ul></div></div>'
].join('')

   
  });
