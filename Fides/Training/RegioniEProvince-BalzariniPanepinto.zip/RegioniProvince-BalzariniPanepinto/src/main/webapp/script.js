(function(angular) {
  'use strict';
angular.module('docsTabsExample', [])
  .component('regioni', {
    controller: 'regioniCtrl',
    templateUrl: 'regioni.html'
  })
  .component('provincia', {
    require: {
      tabsCtrl: '^regioni'
    },
    bindings: {
      title: '@',
      prov: '<'
    },
    controller: 'provinciaCtrl',
    templateUrl: 'province.html'
  })
  .controller('regioniCtrl', function($http) {
	  var self = this;
	  $http.get('json/regioni.json').then(function(response){
		  self.regioni = response.data
	  });
	  this.panels = [];
      this.select = function(panel) {
        angular.forEach(this.panels, function(panel) {
          panel.selected = false;
        });
        panel.selected = true;
      };
      this.addPanel = function(panel) {
        if (this.panels.length === 0) {
          this.select(panel);
        }
        this.panels.push(panel);
      };
  })
  .controller('provinciaCtrl', function() {
      this.$onInit = function() {
        this.tabsCtrl.addPanel(this);
      };
  })
})(window.angular);