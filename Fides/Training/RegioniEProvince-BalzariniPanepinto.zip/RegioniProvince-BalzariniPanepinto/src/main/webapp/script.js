(function(angular) {
  'use strict';
angular.module('docsTabsExample', [])
  .component('regioni', {
    controller: 'regioniCtrl',
    templateUrl: 'regioni.html'
  })
  .component('provincia', {
    require: {
      tabsCtrl: '^regioni'
    },
    bindings: {
      title: '@',
      prov: '<'
    },
    controller: 'provinciaCtrl',
    templateUrl: 'province.html'
  })
  .controller('regioniCtrl', function() {
	  this.regioni = [
		  {
			  name: 'Lombardia',
			  prov: [
    			  {
    				  name: 'Milano'
    			  },
    			  {
    				  name: 'Monza'
    			  },
    			  {
    				  name: 'Lecco'
    			  },
    			  {
    				  name: 'Sondrio'
    			  },
    			  {
    				  name: 'Varese'
    			  },
    			  {
    				  name: 'Pavia'
    			  },
    			  {
    				  name: 'Mantova'
    			  },
    			  {
    				  name: 'Lodi'
    			  },
    			  {
    				  name: 'Cremona'
    			  },
    			  {
    				  name: 'Como'
    			  },
    			  {
    				  name: 'Brescia'
    			  },
    			  {
    				  name: 'Bergamo'
    			  },
    		  ]
		  },
		  {
			  name: 'Liguria',
			  prov: [
    			  {
    				  name: 'Impera'
    			  },
    			  {
    				  name: 'Genova'
    			  },
    			  {
    				  name: 'La Spezia'
    			  },
    			  {
    				  name: 'Savona'
    			  },
    		  ]		
		  },
		  {
			  name: 'Piemonte',
			  prov: [
    			  {
    				  name: 'Torino'
    			  },
    			  {
    				  name: 'Alessandria'
    			  },
    			  {
    				  name: 'Asti'
    			  },
    			  {
    				  name: 'Biella'
    			  },
    			  {
    				  name: 'Cuneo'
    			  },
    			  {
    				  name: 'Novara'
    			  },
    			  {
    				  name: 'Verbano-Cusio-Ossola'
    			  },
    			  {
    				  name: 'Vercelli'
    			  },
    		  ]
		  }
	  ];
	  this.panels = [];
      this.select = function(panel) {
        angular.forEach(this.panels, function(panel) {
          panel.selected = false;
        });
        panel.selected = true;
      };
      this.addPanel = function(panel) {
        if (this.panels.length === 0) {
          this.select(panel);
        }
        this.panels.push(panel);
      };
  })
  .controller('provinciaCtrl', function() {
      this.$onInit = function() {
        this.tabsCtrl.addPanel(this);
      };
  })
})(window.angular);