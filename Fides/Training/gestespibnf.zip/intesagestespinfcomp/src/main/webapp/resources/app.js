angular.module('app', ['ui.router','ngStorage','ui.bootstrap','ngAnimate', 'ngSanitize'])
    .config(function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/');

        $stateProvider
            .state('home',
            {
                url: '/',
                component: 'home'
            })
            .state('espContenutoInfoRapporto', {
                url: '/gestioneEspansioneInformativaControparte?azienda&ndg',
                component: 'espContenutoInfoRapportoCmp',
                resolve: {        
                    azienda: function ($stateParams) { 
                    	console.log('Funzione che risolve azienda selezionata: Azienda Id: ', $stateParams.azienda);
                    	return $stateParams.azienda; 
                    	},
                    ndg: function ($stateParams) { 
                    	console.log('Funzione che risolve ndg: NDG ID: ', $stateParams.ndg);
                    	return $stateParams.ndg;
                    	}                 
                }
            })
    })
    .component('home', {
        templateUrl:'resources/home.html',
        controller:function($uibModal){
            var $ctrl = this;
            $ctrl.openComponentModal = function(){
               var modalInstance = $uibModal.open({
                   animation:true,
                   component:'gestEspInf',
                   backdrop:'static',
                   keyboard:false
               })
            }
        }
           
    })  
    
    .component('gestEspInf', {
        templateUrl: 'resources/gestEspInftempl.html',
        bindings:{
            /*modalInstance:'<',        istanza del modal che possiamo ricevere in bindings */
            close: '&',
            dismiss: '&'
        },
        controller: function ($http,$sessionStorage) {
            var $ctrl = this;            
            console.log('Controller Component gestEspInf', $ctrl);           
            $ctrl.header = 'Gestione Espansione Informativa';
            $ctrl.banche = '';
            $ctrl.bancaSelezionata = '';
            $ctrl.ndg = '';
            $ctrl.cerca = function () {
                  $ctrl.close();
             };

            $ctrl.annulla = function () {
                 $ctrl.dismiss();
           };
        
            $http.get('resources/banche.json').then(function (response) {
                $ctrl.banche = response.data;
            })
         /*   $ctrl.request = function(){            	
            	$http.get('http://localhost:8080/intesa/gestespinf/' + $ctrl.ndg).then(function (response) {            		
            		$sessionStorage.contenuto = response.data;  
            
                },
                function (error) {
                    alert('Problema con il DB');
                    console.log('KO');
                })
            }*/
            
       
        }
    })
    .component('espContenutoInfoRapportoCmp', {
        templateUrl: 'resources/espContenutoInfoRapporto.html',
        bindings: {
            azienda: '<',
            ndg: '<'            
        },
        controller: function ($http,$uibModal) {     	
        	
            var $ctrl = this;         
            $ctrl.$onInit = function(){ 
                 $ctrl.cmpCrea = 'creaDettaglioEspContenutoInf';
                 $http.get('http://localhost:8080/intesa/gestespinf/' + $ctrl.ndg).then(function (response) {            		
            		$ctrl.contenuto = response.data;     
                },
                function (error) {
                    alert('Problema con il DB');
                    console.log('KO');
                })             
             
            };           
           /* $ctrl.contenuto = $sessionStorage.contenuto;*/
            $ctrl.gestEspInf = {};
                      
            $ctrl.openComponentModal = function(cmp){
               var modalInstance = $uibModal.open({
                   animation:true,
                   component:cmp,
                   backdrop:'static',
                   keyboard:false,
                   resolve:{
                       ndg:function(){
                           return $ctrl.ndg;
                       }
                   }              
                  })
            }           
            
            $http.get('resources/espContenutoInfoRapporto.json').then(function (response) {
                $ctrl.ragg = response.data;
                console.log($ctrl.ragg);

            });
      
           
        }
    })

    .component('raggruppDettaglioEspContInfoCmp', {
        templateUrl: 'resources/raggrdettaglioEspContInfo.html',
        bindings: {
            dettaglio: '<',
            ndg: '<'
        },
        controller: function ($uibModal) {        
                var $ctrl = this;
                $ctrl.$onInit = function(){  
                              
                $ctrl.elimina = function(idgest){  
                    var exit = true; 
                    console.log('dentro funzione elimina', idgest); 
                                                      
                         angular.forEach($ctrl.dettaglio, function(value, key , dettaglio){
                             if (exit){
                              console.log('Dentro forEach', value.idGestioneEI);                        
                                 if(value.idGestioneEI === idgest){
                                    dettaglio.splice(key, 1);
                                    exit = false;
                                 }
                             }
                         })
                     
                };               
              
                $ctrl.cmpDettaglio = 'dettaglioEspContInfoCmp';
                };
                $ctrl.openComponentModal = function(cmp,dett,elimina){
                    var modalInstance = $uibModal.open({
                        animation:true,
                        component:cmp,                        
                        keyboard:false,
                        resolve:{ 
                            dett: function(){
                                return dett;
                            } ,
                            elimina:function(){
                                return elimina;
                            }                           
                        }
                    })
                };
               
            $ctrl.annulla = function () {
                 $ctrl.dismiss();
           };

             console.log('Controller raggruppDettaglioEspContInfoCmp', $ctrl);
        }
    })
    .component('dettaglioEspContInfoCmp',{
        templateUrl:'resources/dettaglioEspContInfoCmp.html',
        bindings:{
             resolve:'=',
             close:'&',
             dismiss:'&'
        },
        controller:function($uibModal,$http){
            var $ctrl = this;
            $ctrl.$onInit = function(){
                $ctrl.cmpCrea = 'creaDettaglioEspContenutoInf';
                $ctrl.dett = $ctrl.resolve.dett;
                $ctrl.del = $ctrl.resolve.elimina;
                $ctrl.reset = {};
                $ctrl.supp = {};
                angular.copy($ctrl.dett, $ctrl.supp);
                console.log('Dentro OnInit DettaglioCmp Var Supporto Copia di Dettaglio', $ctrl.supp);
            }
             $ctrl.aggiorna= function(item){
                console.log('Dentro Funzione Aggiorna: ', item);
                if(angular.equals(item, $ctrl.dett )){
                        alert('Nessun aggiornamento Effettuato');                        
                } else {
                angular.copy(item, $ctrl.dett);                           
                
                $http.put('http://localhost:8080/intesa/gestespinf', item).then(function (success) {
                    alert('Record Aggiornato con successo');
                    console.log('OK');
                }, function (error) {
                    alert('Attenzione Record Non Aggiornato con successo!!!')
                    console.log('KO');
                });
                $ctrl.close();
                }
                

            };
            $ctrl.elimina = function(iditem){
                console.log('Dentro funzione Elimina, Id da eliminare : ',iditem ); 
                /*angular.copy($ctrl.reset,  $ctrl.dett);*/               
                $http.delete('http://localhost:8080/intesa/gestespinf/' + iditem).then(function (success) {
                    alert('Record Cancellato con successo');
                    console.log('OK');
                }, function (error) {
                    alert('Attenzione Record Non Cancellato con successo!!!')
                    console.log('KO');
                })
                
                $ctrl.del(iditem);
                $ctrl.close();    

            };
            $ctrl.openComponentModal = function(cmp){
                    var modalInstance = $uibModal.open({
                        animation:true,
                        component:cmp,  
                        backdrop:'static',
                        keyboard:false                     
                    })
                    $ctrl.dismiss();
                };

        }

    })
    .component('creaDettaglioEspContenutoInf',{
         templateUrl:'resources/creaDettaglioEspContenutoInf.html',  
          bindings:{ 
            resolve:'<',           
            close: '&',
            dismiss: '&'
        },     
         controller:function($http,$sessionStorage){             
             var $ctrl = this; 
             $ctrl.$onInit = function () {
                     $ctrl.ndg = $ctrl.resolve.ndg;  
                     console.log('$ctrl.ndg Dentro $onInit', $ctrl.ndg)                   
                         }; 
             console.log('Dentro Controller modal Crea Dettaglio ', $ctrl);
            
             $ctrl.submit = function (gestEspInf) {
                 console.log('Dentro funzione submit', $ctrl.ndg);
                gestEspInf.idndg = $ctrl.ndg;
                console.log('Oggetto salvato in DB ', gestEspInf);
                $http.post('http://localhost:8080/intesa/gestespinf', gestEspInf).then(function (success) {
                    alert('Record Inserito con successo');
                    console.log('OK');
                }, function (error) {
                    alert('Attenzione Record Non Inserito con successo!!!')
                    console.log('KO');
                });
                $ctrl.close();
            }
             $ctrl.annulla = function () {
                 $ctrl.dismiss();
           };

         }
    })