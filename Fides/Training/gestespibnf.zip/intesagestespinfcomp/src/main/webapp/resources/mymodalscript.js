function dism (){
                console.log('Dentro la funzione Dism')
                $('#myModal').modal('hide');
            };