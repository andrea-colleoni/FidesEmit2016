package it.fides.intesa.dao;

import java.util.List;

import javax.sql.DataSource;

import it.fides.intesa.model.GestioneEspansioneInformativa;


public interface GestioneEspansioneInformativaDao {
	
	public void setDataSource(DataSource ds);
	
	public void create (GestioneEspansioneInformativa gestEspInf);

	public GestioneEspansioneInformativa read(int idGestioneEI);

	public void update(GestioneEspansioneInformativa gestEspInf);

	public void delete(int idGestioneEI);

	public List<GestioneEspansioneInformativa> selectAll();
}
