package it.fides.intesa.dao.namedParameter;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import it.fides.intesa.dao.GestioneEspansioneInformativaDao;
import it.fides.intesa.mapper.GestEspInfMapper;
import it.fides.intesa.model.GestioneEspansioneInformativa;


@Component
public class JdbcGestioneEspansioneInformativaDAO implements GestioneEspansioneInformativaDao{
	
	private NamedParameterJdbcTemplate jdbcTemplateObject;
	
	public void setDataSource(DataSource dataSource) {
        this.jdbcTemplateObject = new NamedParameterJdbcTemplate(dataSource);
    }

	public void create (GestioneEspansioneInformativa gestEspInf) {
		String SQL1 = "insert into gestioneespansioneinformativa ( CodiceDato, DescrizioneCodice, ValoreDato, DescrizioneValoreDato, DataCensimento, DataOra, id_ndg_ei) "
				+ "values ( :codiceDato,:descrizioneCodici,:valoreDato,:descrizioneValoreDato,:dataCensimento,  :dataOra, :idndg)";
		
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestEspInf);
        // Esegue la query passandogli anche i valori effettivi da inserire:
        jdbcTemplateObject.update(SQL1, namedParameters);
	}

	public GestioneEspansioneInformativa read(int idGestEspInf) {
		 String SQL = "SELECT * FROM gestioneespansioneinformativa WHERE idGestioneEI = :idGestioneEI";

		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestioneEI", idGestEspInf);

		return jdbcTemplateObject.queryForObject(SQL, namedParameters, new GestEspInfMapper());
	}

	public void update(GestioneEspansioneInformativa gestEspInf) {
		 String SQL = "UPDATE gestioneespansioneinformativa SET " + 
						   "CodiceDato = :codiceDato, DescrizioneCodice = :descrizioneCodici, " +
						   "ValoreDato = :valoreDato, DescrizioneValoreDato = :descrizioneValoreDato, DataCensimento = :dataCensimento, " +
						   "DataOra = :dataOra, id_ndg_ei = :idndg " +
						   "WHERE idGestioneEI = :idGestioneEI";
		
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestEspInf);
		
		jdbcTemplateObject.update(SQL, namedParameters);
	}

	public void delete(int idGestEspInf) {
		String SQL = "DELETE FROM gestioneespansioneinformativa WHERE idGestioneEI = :idGestioneEI";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestioneEI", idGestEspInf);
		
		jdbcTemplateObject.update(SQL, namedParameters);
		
		System.out.println(String.format("Record ID=%d eliminato", idGestEspInf));
	}

	public List<GestioneEspansioneInformativa> selectAll() {
		String SQL = "select * from gestioneespansioneinformativa";
		
		List<GestioneEspansioneInformativa> gestEspInf = jdbcTemplateObject.query(SQL, new GestEspInfMapper());
			return gestEspInf;
	}
	
	public List<GestioneEspansioneInformativa> selectAllByNdg(int idndg) { 
		String SQL = "SELECT * FROM gestioneespansioneinformativa WHERE id_ndg_ei = :idndg";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("idndg", idndg);

		return jdbcTemplateObject.query(SQL, namedParameters, new GestEspInfMapper());
	}

}
