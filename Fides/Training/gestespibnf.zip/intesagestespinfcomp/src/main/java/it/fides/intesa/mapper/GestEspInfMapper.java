package it.fides.intesa.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import it.fides.intesa.model.GestioneEspansioneInformativa;

public class GestEspInfMapper implements RowMapper<GestioneEspansioneInformativa>{
	public GestioneEspansioneInformativa mapRow(ResultSet rs, int rowNum) throws SQLException {
		 
		GestioneEspansioneInformativa gestEspInf = new GestioneEspansioneInformativa();
 
        gestEspInf.setCodiceDato(rs.getInt("CodiceDato"));
        gestEspInf.setValoreDato(rs.getInt("ValoreDato"));
        gestEspInf.setDataCensimento(rs.getDate("DataCensimento"));
        gestEspInf.setDataOra(rs.getDate("DataOra"));
        gestEspInf.setDescrizioneCodici(rs.getString("DescrizioneCodice"));
        gestEspInf.setDescrizioneValoreDato(rs.getString("DescrizioneValoreDato"));
        gestEspInf.setIdGestioneEI(rs.getInt("idGestioneEI"));
        gestEspInf.setIdndg(rs.getInt("id_ndg_ei"));
 
        return gestEspInf;
    }

}
