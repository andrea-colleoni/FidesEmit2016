package it.fides.intesa.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import it.fides.intesa.dao.namedParameter.JdbcGestioneEspansioneInformativaDAO;
import it.fides.intesa.model.GestioneEspansioneInformativa;


@RestController
public class RestControllerJson {
	
	@RequestMapping(value="/", method = RequestMethod.GET)
	public ModelAndView index(ModelAndView model) {
		model.setViewName("prova");
		return model;
	}
	
	@RequestMapping(value="/gestespinf/{id}", method = RequestMethod.GET )
	public List<GestioneEspansioneInformativa> gestEspInfByNdg(@PathVariable int id) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneEspansioneInformativaDAO jdbcGestEspInfDAO = (JdbcGestioneEspansioneInformativaDAO) context
				.getBean("gestEspInf");
		List<GestioneEspansioneInformativa> gestEsp = jdbcGestEspInfDAO.selectAllByNdg(id);
		System.out.println(id);
		
		return gestEsp;
	}	
	
	@RequestMapping(value="/gestespinf", method = RequestMethod.GET)
	public List<GestioneEspansioneInformativa> listgestEspInf() {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		
		JdbcGestioneEspansioneInformativaDAO jdbcGestEspInfDAO = (JdbcGestioneEspansioneInformativaDAO) context
				.getBean("gestEspInf");
		List<GestioneEspansioneInformativa> gestEsp = jdbcGestEspInfDAO.selectAll();

		
		return gestEsp;
	}

	@RequestMapping(value="/gestespinf", method = RequestMethod.POST )
	public void createGestEspInf(@RequestBody GestioneEspansioneInformativa input) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneEspansioneInformativaDAO jdbcGestEspInfDAO = (JdbcGestioneEspansioneInformativaDAO) context
				.getBean("gestEspInf");
		jdbcGestEspInfDAO.create(input);		
		
	}

	@RequestMapping(value="/gestespinf", method = RequestMethod.PUT )
	public void updateGestEspInf(@RequestBody GestioneEspansioneInformativa input) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneEspansioneInformativaDAO jdbcGestEspInfDAO = (JdbcGestioneEspansioneInformativaDAO) context
				.getBean("gestEspInf");
		jdbcGestEspInfDAO.update(input);	
		System.out.println("Aggiornato record con : " + input);	
		
	}


	@RequestMapping(value="/gestespinf/{id}", method = RequestMethod.DELETE )
	public void gestEspInfDel(@PathVariable int id) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneEspansioneInformativaDAO jdbcGestEspInfDAO = (JdbcGestioneEspansioneInformativaDAO) context
				.getBean("gestEspInf");
		jdbcGestEspInfDAO.delete(id);
		System.out.println("Cancellato record con id : " + id);
		
		
	}
}

