angular.module('app',[])
.controller('mainController', function($http){
    var self = this;
   $http.get('json/regioni.json').then(function(response){
       
       self.regioni = response.data;
       console.log(self.regioni);
   });

   /*this.regioni = [
       {
           nome:'sicilia'
        },
        {
           nome:'lombardia'
        }
   ];*/
   this.regione = '';
   this.updateRegione = function(reg){
       console.log('Regione Scelta', reg);
        this.regione = reg;
    
   };
})
/* creo component regioni che riceve in input le regioni ed ha in output un riferimento(onRadioClick) alla funzione esterna che mi aggiorna il valore
della regione scelta  */
.component('regioni',{
     bindings:{
         regioni:'<',
         onRadioClick:'&'
     },
     templateUrl:'template/templateRegioni.html',
     /* all'interno del controller ho la funzione che verrà richiamata al click dell'input radio che riceve come parametro la regione scelta e richiama 
     la funzione esterna al componente tramite il suo riferimento che abbiamo in bindings(onRadioClick) passandogli come output il parametro tramite key-value
     dove la key ha prefisso $ x identificare che è un valore di output al quale è assegnato il parametro ricevuto dal radio */
     controller: function(){
         this.regHandler = function(reg){             
             this.onRadioClick({$reg:reg});
         };
     }
})
.component('province',{
    bindings:{
        regione: '<'
    },
    templateUrl:'template/templateProvince.html',
    controller: function($http){
        var self =this;
        $http.get('json/provinceJson/provinceSicilia.json').then(function(response){
         self.sicilia = response.data;
         console.log(self.sicilia);
        })
        $http.get('json/provinceJson/provinceLombardia.json').then(function(response){
         self.lombardia = response.data;
         console.log(self.lombardia);
        })
        $http.get('json/provinceJson/provinceCampania.json').then(function(response){
         self.campania = response.data;
         console.log(self.campania);
        })

        
      /*  this.sicilia = [
            {nome:'Catania'},
            {nome:'Palermo'},
            {nome:'Messina'}
             ];
        this.lombardia = [
            {nome:'Milano'},
            {nome:'Brescia'},
            {nome:'Mantova'}
             ]; */

    }
})