var app = angular.module('myApp', []);
app.controller('controllerApp', function($scope) {
	$scope.provinceSicilia = [
		{name: 'Agrigento'},
		{name: 'Caltanissetta'},
		{name: 'Catania'},
		{name: 'Enna'},
		{name: 'Messina'},
		{name: 'Palermo'},
		{name: 'Ragusa'},
		{name: 'Siracusa'},
		{name: 'Trapani'}
	];
	
	$scope.provinceLombardia = [
		{name: 'Bergamo'},
		{name: 'Brescia'},
		{name: 'Como'},
		{name: 'Cremona'},
		{name: 'Lecco'},
		{name: 'Lodi'},
		{name: 'Mantova'},
		{name: 'Milano'},
		{name: 'Monza'},
		{name: 'Pavia'},
		{name: 'Sondrio'},
		{name: 'Varese'}		
	];
	
	$scope.provinceCampania = [
		{name: 'Avellino'},
		{name: 'Benevento'},
		{name: 'Caserta'},
		{name: 'Napoli'},
		{name: 'Salerno'}		
	];
	
	
})

.component('province',{
	templateUrl:'templateProvince.html',
	controller:'controllerApp'
})