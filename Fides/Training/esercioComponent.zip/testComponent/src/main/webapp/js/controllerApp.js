angular.module('myApp', [])
.component('regioni', {
	transclude: true,
	require: {
		regCtrl: '^provincia'
	},
    templateUrl: 'template/templateRegioni.html',
    controller: function (){
    	
    	this.regioni = [ 
            {
                nome: 'Sicilia'
            },
            {
                nome: 'Campania'
            },
            {
                nome: 'Lombardia'
        }];
    	this.myReg = '';
    	this.getReg = function(reg){
    		this.regCtrl.getRegione(reg);
    	};
        
    }
})
.component('province',{
	transclude: true,
	
	templateUrl:'template/templateProvince.html',
	controller: function(){
		this.provinceSicilia = [
			{name: 'Agrigento'},
			{name: 'Caltanissetta'},
			{name: 'Catania'},
			{name: 'Enna'},
			{name: 'Messina'},
			{name: 'Palermo'},
			{name: 'Ragusa'},
			{name: 'Siracusa'},
			{name: 'Trapani'}
		];
		
		this.provinceLombardia = [
			{name: 'Bergamo'},
			{name: 'Brescia'},
			{name: 'Como'},
			{name: 'Cremona'},
			{name: 'Lecco'},
			{name: 'Lodi'},
			{name: 'Mantova'},
			{name: 'Milano'},
			{name: 'Monza'},
			{name: 'Pavia'},
			{name: 'Sondrio'},
			{name: 'Varese'}		
		];
		
		this.provinceCampania = [
			{name: 'Avellino'},
			{name: 'Benevento'},
			{name: 'Caserta'},
			{name: 'Napoli'},
			{name: 'Salerno'}		
		];
		this.myReg = '';
		this.getRegione = function(reg){
			this.myReg = (reg);
		}
		
	}
})