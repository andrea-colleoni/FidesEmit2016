
package converter;


/**
 * This is the remote interface for Converter enterprise bean.
 */
public interface ConverterRemote extends javax.ejb.EJBObject, converter.ConverterRemoteBusiness {
    
    
}
