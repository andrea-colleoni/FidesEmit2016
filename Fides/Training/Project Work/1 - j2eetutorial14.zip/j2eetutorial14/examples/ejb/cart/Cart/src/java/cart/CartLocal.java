
package cart;

import javax.ejb.EJBLocalObject;


/**
 * This is the local interface for Cart enterprise bean.
 */
public interface CartLocal extends EJBLocalObject, CartLocalBusiness {
    
    
}
