
package team;

import javax.ejb.EJBLocalObject;


/**
 * This is the local interface for Player enterprise bean.
 */
public interface PlayerLocal extends EJBLocalObject, PlayerLocalBusiness {
    
    
}
