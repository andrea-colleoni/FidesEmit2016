
package roster;

import javax.ejb.EJBLocalObject;


/**
 * This is the local interface for Roster enterprise bean.
 */
public interface RosterLocal extends EJBLocalObject, RosterLocalBusiness {
    
    
}
