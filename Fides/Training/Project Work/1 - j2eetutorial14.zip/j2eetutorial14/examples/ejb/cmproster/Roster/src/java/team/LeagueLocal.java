
package team;

import javax.ejb.EJBLocalObject;


/**
 * This is the local interface for League enterprise bean.
 */
public interface LeagueLocal extends EJBLocalObject, LeagueLocalBusiness {
    
    
}
