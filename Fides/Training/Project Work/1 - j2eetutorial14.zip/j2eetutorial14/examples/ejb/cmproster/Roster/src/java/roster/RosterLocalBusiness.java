
package roster;


/**
 * This is the business interface for Roster enterprise bean.
 */
public interface RosterLocalBusiness {
    
}
