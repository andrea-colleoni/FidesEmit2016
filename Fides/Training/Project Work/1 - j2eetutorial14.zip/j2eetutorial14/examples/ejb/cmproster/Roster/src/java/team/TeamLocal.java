
package team;

import javax.ejb.EJBLocalObject;


/**
 * This is the local interface for Team enterprise bean.
 */
public interface TeamLocal extends EJBLocalObject, TeamLocalBusiness {
    
    
}
