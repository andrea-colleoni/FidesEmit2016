
package roster;

import javax.ejb.EJBObject;


/**
 * This is the remote interface for RosterBean enterprise bean.
 */
public interface RosterRemote extends EJBObject, RosterRemoteBusiness {
    
}
